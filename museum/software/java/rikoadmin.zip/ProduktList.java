import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;

class ProduktList extends ArrayList implements Serializable
{

  NOBSBoolean changed;

  ProduktList(NOBSBoolean nb)
  {
    changed=nb;
  }

  String addProdukt(Produkt p)
  {
    changed.bool=true;
    String result=new String();
    add(p);
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Produkt toegevoegd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/produkten.html>";
result+="			<input type=submit value=Produkten>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String editProdukt(int i)
  {
    Produkt p = (Produkt) get(i);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Produkt Wijzigen";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/saveprodukt.html>";
result+="<input type=hidden name=produkt value="+i+">";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+="							BTW:";
result+="						</td>";
result+="						<td>";
/*
result+="							<input type=checkbox name=btw";
    if (p.btw)
      result+=" CHECKED ";
result+=">";
*/
result+="<input type=radio name=btwperc value=0";
if (!p.btw & !p.laagbtw)
  result+=" CHECKED ";
result+=">0% - <input type=radio name=btwperc value=6";
if (p.btw & p.laagbtw)
  result+=" CHECKED ";
result+=">6% - <input type=radio name=btwperc value=19";
if (p.btw & !p.laagbtw)
  result+=" CHECKED ";
result+=">19%";
result+="						</td>";
result+="					</tr>";
/*
result+="					<tr>";
result+="						<td>";
result+="							BTW 6%:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=laagbtw";
    if (p.laagbtw)
      result+=" CHECKED ";
result+=">";
result+="						</td>";
result+="					</tr>";
*/
result+="					<tr>";
result+="						<td>";
result+="							Inkomsten:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=inkomsten";
    if (p.inkomsten)
      result+=" CHECKED ";
result+=">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Prijs:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=prijs size=5 value="+p.bedrag+">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Omschrijving:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=omschrijving value=\""+p.omschrijving+"\"><br>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Wijzigen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";
result+="		<td align=right>";
result+="<table>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/produkten.html>";
result+="			<input type=submit value=Produkten>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
    return result;
  }

  String saveProdukt(PostData pd)
  {
    changed.bool=true;
    Produkt p = (Produkt) get(new Integer(pd.getValue("produkt")).intValue());
    int btwperc = new Integer(pd.getValue("btwperc")).intValue();
    switch (btwperc)
    {
      case 0:p.btw=false;p.laagbtw=false;break;
      case 6:p.btw=true;p.laagbtw=true;break;
      case 19:p.btw=true;p.laagbtw=false;break;
    }
//    p.btw = pd.getValue("btw").equalsIgnoreCase("on");
//    p.laagbtw = pd.getValue("laagbtw").equalsIgnoreCase("on");
    p.inkomsten = pd.getValue("inkomsten").equalsIgnoreCase("on");
    p.bedrag = new Integer(pd.getValue("prijs")).intValue();
    p.omschrijving = pd.getValue("omschrijving");
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Produkt gewijzigd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/produkten.html>";
result+="			<input type=submit value=Produkten>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String remProdukt(int i)
  {
    changed.bool=true;
    remove(i);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Produkt verwijderd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/produkten.html>";
result+="			<input type=submit value=Produkten>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String makeSelect(boolean addall)
  {
    String result = new String();
    result+="				<select name=produkt>";
    if (addall)
      result+="					<option value=999>Alle produkten</option>";
    for (int i = 0; i < size(); i++)
    {
      Produkt p = (Produkt) get(i);
      result+="					<option value="+i+">"+p.omschrijving+"</option>";
    }
    result+="				</select>";
    return result;
  }

  String produktMenu()
  {
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Produkten";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/addprodukt.html>";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+="							BTW:";
result+="						</td>";
result+="						<td>";
//result+="							<input type=checkbox name=btw>";
result+="<input type=radio name=btwperc value=0 CHECKED >0% - <input type=radio name=btwperc value=6>6% - <input type=radio name=btwperc value=19>19%";
result+="						</td>";
result+="					</tr>";
/*
result+="					<tr>";
result+="						<td>";
result+="							BTW 6%:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=laagbtw>";
result+="						</td>";
result+="					</tr>";
*/
result+="					<tr>";
result+="						<td>";
result+="							Inkomsten:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=inkomsten>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Prijs:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=prijs size=5 value=0>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Omschrijving:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=omschrijving><br>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Toevoegen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";
result+="		<td align=right>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="				<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="";
result+="<hr>";
result+="";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				BTW";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				In/Uit";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Prijs";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Omschrijving";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Wijzigen";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Verwijderen";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
    for (int i = 0; i < size(); i++)
    {
      Produkt p = (Produkt) get(i);
      String s = new Integer(p.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="<tr><td align=center>"+(p.btw?"Ja":"Nee")+"</td><td align=center>"+(p.inkomsten?"In":"Uit")+"</td><td>� "+s+"</td><td>"+p.omschrijving+"</td><td align=center><form method=POST action=http://localhost/editprodukt.html><input type=hidden name=produkt value="+i+"><input type=submit value=Wijzigen></form></td><td align=center><form method=POST action=http://localhost/remprodukt.html><input type=hidden name=produkt value="+i+"><input type=submit value=Verwijderen></form></td></tr>";
    }
result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
    return result;
  }

}
