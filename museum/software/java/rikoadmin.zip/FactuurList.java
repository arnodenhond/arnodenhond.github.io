import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;

class FactuurList extends ArrayList
{

  NOBSBoolean changed;

  FactuurList(NOBSBoolean changed)
  {
    this.changed=changed;
  }

  String maakFactuur(Factuur f, PersoonList personen)
  {
    changed.bool=true;
    if (f.transakties.size()>0)
      add(f);
    String result=new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
if (f.transakties.size()>0)
  result+="Factuur gemaakt";
else
  result+="geen ongefactureerde transakties!";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=left valign=top>";
result+="			<form method=POST action=http://localhost/openposten.html>";
result+=personen.makeSelect(true);
result+="<br>";
result+="				<input type=submit value=\"Openstaande posten\">";
result+="			</form>";
result+="	</td>";
if (f.transakties.size()>0)
{
  result+=" <td align=center valign=top>";
  result+="   <form method=POST action=http://localhost/bekijkfactuur.html>";
  result+="     <input type=hidden name=factuur value="+indexOf(f)+">";
  result+="     <input type=submit value=\"Bekijk factuur\">";
  result+="   </form>";
  result+=" </td>";
}
result+="	<td align=right valign=top>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String openFacturen(int ifactuurid)
  {
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Openstaande facturen";
result+="</h2>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/factnr.html>";
result+="factuur nummer:";
result+="				<input type=text size=5 name=factnr value="+ifactuurid+">";
result+="				<input type=submit value=Opslaan>";
result+="			</form>";
result+="		</td>";
result+="   <td align=right>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="</td>";
result+="	</tr>";
result+="</table>";

result+="<hr>";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Volnr";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Naam";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Datum";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Bedrag";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Bekijken";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Betaald";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
    for (int i=0; i < size(); i++)
    {
      Factuur f = (Factuur) get(i);
      String s = new Integer(f.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    Calendar c = Calendar.getInstance();
    c.setTime(f.datum);
      result+="<tr><td align=center>"+f.volgnr+"</td><td>"+f.persoon.naam+"</td><td>"+c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR)+"</td><td>� "+s+"</td><td align=center><form method=POST action=http://localhost/bekijkfactuur.html><input type=hidden name=factuur value="+i+"><input type=submit value=Bekijken></form></td><td align=center><form method=POST action=http://localhost/factuurbetaald.html><input type=hidden name=factuur value="+i+"><input type=submit value=Betaald></form></td></tr>";
    }
result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
    return result;
  }

  String bekijkFactuur(int fid)
  {
    changed.bool=true;
    Factuur f = (Factuur) get(fid);
    String result = new String();
result+="<center>";
//result+="<img src=file://c:/RIKOAdmin/facthdr.jpg>";
result+="</center>";
result+="<br><br><br><br><br><br><br><br><br><br>";
result+="<table>";
result+="<tr><td>Aan:</td><td>"+f.persoon.naam+"</td></tr>";
result+="<tr><td></td><td>"+f.persoon.adres1+"</td></tr>";
result+="<tr><td></td><td>"+f.persoon.adres2+"</td></tr>";
result+="</table>";
result+="<br><br><br><br><br>";
    Calendar c = Calendar.getInstance();
    c.setTime(f.datum);
result+="<table><tr><td>Datum:</td><td>";
result+=c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR);
result+="</td></tr><tr><td>Factuurnr:</td><td>";
result+=f.volgnr;
result+="</td></tr><tr><td>Betreft:</td><td>";
result+=f.betreft;
result+="</td></tr></table>";
result+="<br><br><br><br><br>";
result+="<table width=90%><tr><td>Produkt</td><td>Datum</td><td></td><td colspan=2><b>prijs ex. BTW<b></td></tr>";
int totaalexbtw=0;
for (int i=0; i < f.transakties.size(); i++)
{
  Transaktie t = (Transaktie) f.transakties.get(i);
      float ftbedrag = t.bedrag;
      float fbtw=(ftbedrag/119)*100;
//      int ibtw = t.bedrag;
      int ibtw = Math.round(fbtw);
      int bedragexbtw = (t.btw?ibtw:t.bedrag);
      totaalexbtw+=bedragexbtw;
      String s = new Integer(bedragexbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());

  result+="<tr><td>"+t.produkt.omschrijving+"</td><td>"+t.day+"/"+t.month+"/"+t.year+"</td><td></td><td>�</td><td width=50 align=right>"+s+"</td></tr>";
}
      String s = new Integer(totaalexbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
result+="<tr><td></td><td></td><td></td><td colspan=2><hr></td></tr>";
result+="<tr><td></td><td></td><td><b>Sub. Totaal</b></td><td>�</td><td width=50 align=right>"+s+"</td></tr>";
float ftotexbtw = totaalexbtw;
float ftotbtw= (ftotexbtw/100)*19;
int totaalbtw = Math.round(ftotbtw);
s = new Integer(totaalbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
result+="<tr><td></td><td></td><td>BTW 19%</td><td>�</td><td width=50 align=right>"+s+"</td></tr>";
result+="<tr><td></td><td></td><td></td><td colspan=2><hr></td></tr>";
int totaal = totaalexbtw+totaalbtw;
if (totaal!=f.bedrag)
  System.out.println("ERROR! totals dont match after BTW calculations!");
s = new Integer(totaal).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
result+="<tr><td></td><td></td><td><b>Totaal bedrag<b></td><td>�</td><td width=50 align=right>"+s+"</td></tr>";
//hier transakties invullen;
/*
result+="<tr><td></td><td></td><td></td><td></td><td><hr></td></tr>";
result+="<tr><td></td><td></td><td></td><td><b>Sub. Totaal<b></td><td>� "+((f.bedrag/100)*81)+"</td></tr>";
result+="<tr><td></td><td></td><td></td><td>BTW 19%</td><td>� "+((f.bedrag/100)*19)+"</td></tr>";
result+="<tr><td></td><td></td><td></td><td></td><td><hr></td></tr>";
result+="<tr><td></td><td></td><td></td><td><b>Totaal bedrag<b></td><td>� "+f.bedrag+"</td></tr>";
*/
result+="</table>";
result+="<br><br><br><br><br>";
result+="<i>Wij verzoeken u vriendelijk het bovenstaande totaalbedrag, o.v.v. het factuurnummer, binnen 14 dagen<br>";
result+="over te maken naar Postbank rekeningnummer 9225046 t.n.v. RIKO rij-instructie te Voorhout.<br>";
result+="BTW nummer NL 0797.32.483.B01.</i>";
result+="<br><br><br><br><br>";
result+="<center>";
//result+="<img src=file://c:/RIKOAdmin/factftr.jpg>";
result+="</center>";
    return result;
  }

  String factuurBetaald(int fid)
  {
    changed.bool=true;
    Factuur f = (Factuur) get(fid);
    for (int i = 0; i < f.transakties.size(); i++)
    {
      Transaktie t = (Transaktie) f.transakties.get(i);
      t.betaald=true;
    }
    remove(fid);
    String result=new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Factuur betaald";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center valign=top>";
result+="			<form method=POST action=http://localhost/openfacturen.html>";
result+="				<input type=submit value=\"Openstaande facturen\">";
result+="			</form>";
result+="	</td>";
result+="	<td align=center valign=top>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }
}