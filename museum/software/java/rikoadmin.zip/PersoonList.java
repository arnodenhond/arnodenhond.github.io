import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;

class PersoonList extends ArrayList implements Serializable
{

  NOBSBoolean changed;

  PersoonList(NOBSBoolean nb)
  {
    changed=nb;
  }

  String addPersoon(Persoon p)
  {
    changed.bool=true;
    String result=new String();
    add(p);
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Persoon toegevoegd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/personen.html>";
result+="			<input type=submit value=Personen>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String editPersoon(int i)
  {
    Persoon p = (Persoon) get(i);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Persoon Wijzigen";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/savepersoon.html>";
result+="<input type=hidden name=persoon value="+i+">";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+="							Naam:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=naam";
      result+=" value=\""+p.naam+"\"";
result+=">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Straat + Huisnr:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=adres1";
      result+=" value=\""+p.adres1+"\"";
result+=">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Postcode + Woonplaats:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=adres2 value=\""+p.adres2+"\">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Wijzigen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";
result+="		<td align=right>";
result+="<table>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/personen.html>";
result+="			<input type=submit value=Personen>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
    return result;
  }

  String savePersoon(PostData pd)
  {
    changed.bool=true;
    Persoon p = (Persoon) get(new Integer(pd.getValue("persoon")).intValue());
    p.naam = pd.getValue("naam");
    p.adres1 = pd.getValue("adres1");
    p.adres2 = pd.getValue("adres2");
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Persoon gewijzigd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/personen.html>";
result+="			<input type=submit value=Personen>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String remPersoon(int i)
  {
    changed.bool=true;
    remove(i);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Persoon verwijderd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/personen.html>";
result+="			<input type=submit value=Personen>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String makeSelect(boolean addall)
  {
    String result = new String();
    result+="				<select name=persoon>";
    if (addall)
      result+="					<option value=999>Alle personen</option>";
    for (int i = 0; i < size(); i++)
    {
      Persoon p = (Persoon) get(i);
      result+="					<option value="+i+">"+p.naam+"</option>";
    }
    result+="				</select>";
    return result;
  }

  String persoonMenu()
  {
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Personen";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/addpersoon.html>";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+="							Naam:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=naam>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Straat + Huisnr:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=adres1>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Postcode + Woonplaats:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=adres2>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Toevoegen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";
result+="		<td align=right>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="				<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="";
result+="<hr>";
result+="";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Naam";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Straat + Huisnr";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Postcode + Woonplaats";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Wijzigen";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Verwijderen";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
    for (int i = 0; i < size(); i++)
    {
      Persoon p = (Persoon) get(i);
      result+="<tr><td align=center>"+p.naam+"</td><td align=center>"+p.adres1+"</td><td>"+p.adres2+"</td><td align=center><form method=POST action=http://localhost/editpersoon.html><input type=hidden name=persoon value="+i+"><input type=submit value=Wijzigen></form></td><td align=center><form method=POST action=http://localhost/rempersoon.html><input type=hidden name=persoon value="+i+"><input type=submit value=Verwijderen></form></td></tr>";
    }
result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
    return result;
  }

}
