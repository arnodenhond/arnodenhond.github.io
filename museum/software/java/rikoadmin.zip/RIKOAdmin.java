import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;

class RIKOAdmin
{

  static DataBase db  = null;

  static void savedb() throws Exception
  {
    File f = new File("RIKOAdmin.db");
    FileOutputStream fos = new FileOutputStream(f);
    ObjectOutputStream oos = new ObjectOutputStream(fos);
    db.changed.bool=false;
    oos.writeObject(db);
    oos.flush();
    fos.close();
    System.out.println("DATABASE SAVED");
  }

  static void loaddb() throws Exception
  {
    File f = new File("RIKOAdmin.db");
    if (f.exists())
    {
      FileInputStream fis = new FileInputStream(f);
      ObjectInputStream ois = new ObjectInputStream(fis);
      db = (DataBase) ois.readObject();
      fis.close();
    }
    else
    {
      db = new DataBase();
      db.changed=new NOBSBoolean(false);
      db.produkten = new ProduktList(db.changed);
      db.facturen = new FactuurList(db.changed);
      db.personen = new PersoonList(db.changed);
      db.personen.add(new Persoon("Ongespecificeerd"));
      db.transakties = new TransaktieList(db.produkten,db.personen,db.changed);
      savedb();
    }
  }

  static void removeold()
  {
    long multiplier = 100000;
    long qmult = 4;
    long diff = 80352 * multiplier;
    diff = diff * qmult;
//    System.out.println(new Date(System.currentTimeMillis()-diff).toString());
    for (int i=0;i<db.transakties.size();i++)
    {
      Transaktie t = (Transaktie) db.transakties.get(i);
      Calendar c = Calendar.getInstance();
      c.set(t.year,t.month,t.day);
      long l = c.getTime().getTime();
      if (System.currentTimeMillis()-diff>l)
      {
        db.transakties.remove(i);
        i--;
      }
    }
  }

  static String getRequesthdr(BufferedReader in) throws Exception
  {
    String templine = " ";
    String requesthdr = "";
    while (!templine.equals(""))
    {
      templine = in.readLine();
      requesthdr += templine+"|";
    }
    return requesthdr;
  }

  static String getPostdata(String requesthdr, BufferedReader in) throws Exception
  {
    String postdata = new String();
    int clstart=requesthdr.toUpperCase().indexOf("CONTENT-LENGTH:");
    if (clstart!=-1)
    {
      int length=new Integer(requesthdr.substring(clstart+16,requesthdr.indexOf("|",clstart))).intValue();
      char[] pdchars = new char[length];
      int rl=0;
      while (rl<length)
        rl+=in.read(pdchars,rl,length-rl);
      postdata=new String(pdchars);
      postdata = new URLDecoder().decode(postdata);
    }
    return postdata;
  }

  static String mainMenu()
  {
    String result = new String();
result+="<body bgcolor=black text=white link=white vlink=white alink=white>";
result+="<font face=verdana>";
result+="<center>";
result+="";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="";
result+="<hr>";
result+="";
result+="<table>";
result+="	<tr  height=50>";
result+="		<td>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/transakties.html>";
result+="				<input type=submit value=Transakties>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=post action=http://localhost/overzicht.html>";
result+="		 		<select name=month>";
result+="					<option value=999>Alle maanden</option>";
    Calendar c = Calendar.getInstance();
    c.setTime(new Date(System.currentTimeMillis()));
    for (int i = 0; i < 12; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.MONTH)==i)
        result+=" selected";
      result+=">";
      switch (i)
      {
        case 0:result+="januari";break;
        case 1:result+="februari";break;
        case 2:result+="maart";break;
        case 3:result+="april";break;
        case 4:result+="mei";break;
        case 5:result+="juni";break;
        case 6:result+="july";break;
        case 7:result+="augustus";break;
        case 8:result+="september";break;
        case 9:result+="oktober";break;
        case 10:result+="november";break;
        case 11:result+="december";break;
      }
      result+="</option>";
    }
result+="				</select>";
result+="		 		<select name=year>";
    for (int i = 2002; i < 2013; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.YEAR)==i)
        result+=" selected";
      result+=">"+i+"</option>";
    }
result+="		 		</select>";
result+="				<br>";
result+=db.produkten.makeSelect(true);
result+="				<br>";
result+=db.personen.makeSelect(true);
result+="				<br>";
result+="				<input type=submit value=\"Transaktie overzicht\">";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/openposten.html>";
result+=db.personen.makeSelect(true);
result+="<br>";
result+="				<input type=submit value=\"Openstaande posten\">";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/openfacturen.html>";
result+="				<input type=submit value=\"Openstaande facturen\">";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/btwoverzicht.html>";
result+="				<select name=kwartaal>";
result+="					<option value=1>januari</option>";
result+="					<option value=2>februari</option>";
result+="					<option value=3>maart</option>";
result+="					<option value=4>april</option>";
result+="					<option value=5>mei</option>";
result+="					<option value=6>juni</option>";
result+="					<option value=7>juli</option>";
result+="					<option value=8>augustus</option>";
result+="					<option value=9>september</option>";
result+="					<option value=10>oktober</option>";
result+="					<option value=11>november</option>";
result+="					<option value=12>december</option>";
result+="				</select>";
result+="				<select name=jaar>";
    for (int i = 2002; i < 2013; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.YEAR)==i)
        result+=" selected";
      result+=">"+i+"</option>";
    }
result+="				</select>";
result+="				<br>";
result+="				<input type=submit value=\"BTW Overzicht\">";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/personen.html>";
result+="				<input type=submit value=Personen>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/produkten.html>";
result+="				<input type=submit value=Produkten>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr  height=50>";
result+="		<td>";
result+="			<HR>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td align=center>";
result+="			<form method=POST action=http://localhost/shutdown.html>";
result+="				<input type=submit value=Afsluiten>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="<hr>RIKO-Admin v1.2 � <a href=http://arno.denhond.com/nobsoft>noBSoft</a>";
result+="</font></center>";
    return result;
  }

  public static void main(String[] args) throws Exception
  {
    System.out.println("RIKO-Admin v1.2 NOBSOFT");
    File f = new File("c:/RIKOAdmin/RIKOAdmin.jpg");
    if (f.length()!=12166)
    {
//      System.exit(36);
    }
    loaddb();
    removeold();
    savedb();
    NOBSBoolean quit = new NOBSBoolean(false);
    ServerSocket ss = new ServerSocket(80);
    ss.setSoTimeout(1000);
    Socket s = null;
    while (!quit.bool)
    {
      try
      {
        try
        {
          s = ss.accept();
          BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
          String requesthdr = getRequesthdr(in);

    	    StringTokenizer st = new StringTokenizer(requesthdr," ");
          boolean POST = st.nextToken().toUpperCase().equals("POST");
	       	String URL = st.nextToken().toUpperCase();

          String postdata=new String();
          if (POST)
            postdata = getPostdata(requesthdr, in);
          PostData pd = new PostData(postdata);

          PrintWriter pw = new PrintWriter(s.getOutputStream(),true);
          pw.println("HTTP/1.0 200 OK\r\n\r\n");

          System.out.println(URL);
          System.out.println(postdata);

          if (URL.equals("/"))
            pw.println(mainMenu());
          if (POST)
          {
//produkten
            if (URL.equalsIgnoreCase("/produkten.html"))
              pw.println(db.produkten.produktMenu());
            if (URL.equalsIgnoreCase("/addprodukt.html"))
              pw.println(db.produkten.addProdukt(new Produkt(pd)));
            if (URL.equalsIgnoreCase("/editprodukt.html"))
              pw.println(db.produkten.editProdukt(new Integer(pd.getValue("produkt")).intValue()));
            if (URL.equalsIgnoreCase("/saveprodukt.html"))
              pw.println(db.produkten.saveProdukt(pd));
            if (URL.equalsIgnoreCase("/remprodukt.html"))
              pw.println(db.produkten.remProdukt(new Integer(pd.getValue("produkt")).intValue()));
//personenn
            if (URL.equalsIgnoreCase("/personen.html"))
              pw.println(db.personen.persoonMenu());
            if (URL.equalsIgnoreCase("/addpersoon.html"))
              pw.println(db.personen.addPersoon(new Persoon(pd)));
            if (URL.equalsIgnoreCase("/editpersoon.html"))
              pw.println(db.personen.editPersoon(new Integer(pd.getValue("persoon")).intValue()));
            if (URL.equalsIgnoreCase("/savepersoon.html"))
              pw.println(db.personen.savePersoon(pd));
            if (URL.equalsIgnoreCase("/rempersoon.html"))
              pw.println(db.personen.remPersoon(new Integer(pd.getValue("persoon")).intValue()));
            //persoontraksakties!!

//transakties
            if (URL.equalsIgnoreCase("/remTransaktie.html"))
            {
              ArrayList removable=new ArrayList();
              for (int i = 0; i < pd.elements.size(); i++)
              {
                int index = new Integer((String) pd.elements.get(i)).intValue();
                String value=(String)pd.values.get(i);
                if (value.equals("on"))
                  removable.add(db.transakties.get(index));
              }
              for (int i = 0; i < removable.size(); i++)
              {
                Transaktie t = (Transaktie) removable.get(i);
                db.transakties.remove(t);
              }
              URL="/transakties.html";
            }
            if (URL.equalsIgnoreCase("/transakties.html"))
              pw.println(db.transakties.transaktieMenu(db.transaktieid));
            if (URL.equalsIgnoreCase("/addtransaktie.html"))
              pw.println(db.transakties.addTransaktieMenu(pd));
            if (URL.equalsIgnoreCase("/savetransaktie.html"))
              pw.println(db.transakties.saveTransaktie(new Transaktie(pd,db.produkten,db.personen)));
//overzichten
            if (URL.equalsIgnoreCase("/overzicht.html"))
              pw.println(db.transakties.transaktieOverzicht(pd));
            if (URL.equalsIgnoreCase("/btwoverzicht.html"))
              pw.println(db.transakties.btwOverzicht(new Integer(pd.getValue("kwartaal")).intValue(),new Integer(pd.getValue("jaar")).intValue()));


//openstaande posten
            if (URL.equalsIgnoreCase("/openposten.html"))
              pw.println(db.transakties.openPosten(new Integer(pd.getValue("persoon")).intValue()));
            if (URL.equalsIgnoreCase("/betaald.html"))
              pw.println(db.transakties.postBetaald(new Integer(pd.getValue("transaktie")).intValue()));

//openstaande facturen
            if (URL.equalsIgnoreCase("/maakfactuur.html"))
              pw.println(db.facturen.maakFactuur(new Factuur(new Integer(pd.getValue("persoon")).intValue(),pd.getValue("betreft"),db),db.personen));
            if (URL.equalsIgnoreCase("/openfacturen.html"))
              pw.println(db.facturen.openFacturen(db.factuurid));
            if (URL.equalsIgnoreCase("/factuurbetaald.html"))
              pw.println(db.facturen.factuurBetaald(new Integer(pd.getValue("factuur")).intValue()));
            if (URL.equalsIgnoreCase("/bekijkfactuur.html"))
              pw.println(db.facturen.bekijkFactuur(new Integer(pd.getValue("factuur")).intValue()));
//shutdown
            if (URL.equalsIgnoreCase("/shutdown.html"))
              quit.bool=true;
            if (URL.equalsIgnoreCase("/factnr.html"))
            {
              db.factuurid=new Integer(pd.getValue("factnr")).intValue();
              pw.println("<center>factuur nummer opgeslagen!</center>");
              pw.println(db.facturen.openFacturen(db.factuurid));
              db.changed.bool=true;
            }
            if (URL.equalsIgnoreCase("/transnr.html"))
            {
              pw.println("<center>transaktie lengte opgeslagen!</center>");
              db.transaktieid=new Integer(pd.getValue("transaktieid")).intValue();
              pw.println(db.transakties.transaktieMenu(db.transaktieid));
              db.changed.bool=true;
            }
            if (db.changed.bool)
              savedb();
          }
        }
        catch (InterruptedIOException ie)
        {}
      }
      catch (Exception e)
      {
        System.out.println(e.toString());
      }
      if (s!=null)
        s.close();
    }
    savedb();
  }
}

class PostData
{
  ArrayList elements;
  ArrayList values;

  PostData(String s)
  {
    elements = new ArrayList();
    values = new ArrayList();
    StringTokenizer st = new StringTokenizer(s,"&");
    while (st.hasMoreTokens())
    {
      String pdp=st.nextToken();
      String element=pdp.substring(0,pdp.indexOf("="));
      String value=pdp.substring(pdp.indexOf("=")+1,pdp.length());
      elements.add(element);
      values.add(value);
    }
  }

  String getValue(String element)
  {
    for (int i = 0; i < elements.size(); i++)
    {
      String s = (String) elements.get(i);
      if (s.equalsIgnoreCase(element))
      {
        String result = (String) values.get(i);
        return result;
      }
    }
    return new String();
  }

}

class NOBSBoolean implements Serializable
{
  boolean bool;
  NOBSBoolean(boolean b)
  {
    bool=b;
  }
}

class DataBase implements Serializable
{
  int factuurid;
  int transaktieid;//nodig?
  ProduktList produkten;
  TransaktieList transakties;
  PersoonList personen;
  FactuurList facturen;
  NOBSBoolean changed;
}

class Factuur implements Serializable
{
  int volgnr;
  Date datum;
  int bedrag;
  Persoon persoon;
  String betreft;
  TransaktieList transakties;

  Factuur(int pid,String betreft, DataBase db)
  {
    volgnr=db.factuurid++;
    this.betreft=betreft;
    datum=new Date(System.currentTimeMillis());
    transakties=new TransaktieList(db.produkten,db.personen,db.changed);
    Persoon p = (Persoon) db.personen.get(pid);
    persoon = p;
    for (int i = 0; i < db.transakties.size(); i++)
    {
      Transaktie t = (Transaktie) db.transakties.get(i);
      if (t.betaald | t.gefactureerd)
        continue;
      if (t.persoon==p)
      {
        t.gefactureerd=true;
        transakties.add(t);
        bedrag+=t.bedrag;
        if (!t.btw)
        {
          float tfbedrag = t.bedrag;
          float fbedrag =(tfbedrag/119)*19;
          bedrag+=(int) fbedrag;
        }
      }
    }
    System.out.println("factuur gemaakt");
  }
}

class Produkt implements Serializable
{
  boolean btw;
  boolean laagbtw;
  boolean inkomsten;
  int bedrag;
  String omschrijving;

  Produkt(PostData pd)
  {
    int btwperc = new Integer(pd.getValue("btwperc")).intValue();
    switch (btwperc)
    {
      case 0:btw=false;laagbtw=false;break;
      case 6:btw=true;laagbtw=true;break;
      case 19:btw=true;laagbtw=false;break;
    }
//    btw = pd.getValue("btw").equalsIgnoreCase("on");
//    laagbtw = pd.getValue("laagbtw").equalsIgnoreCase("on");
    inkomsten = pd.getValue("inkomsten").equalsIgnoreCase("on");
    bedrag = new Integer(pd.getValue("prijs")).intValue();
    omschrijving = pd.getValue("omschrijving");
  }
}

class Persoon implements Serializable
{
  String naam;
  String adres1;
  String adres2;
  Persoon(String s)
  {
    naam=s;
    adres1=new String();
    adres2=new String();
  }

  Persoon(PostData pd)
  {
    naam = pd.getValue("naam");
    adres1 = pd.getValue("adres1");
    adres2 = pd.getValue("adres2");
  }
}

class Transaktie implements Serializable
{
  int volgnr;
  boolean btw;
  boolean laagbtw;
  boolean inkomsten;
  boolean betaald;
  boolean gefactureerd;
  int day;
  int month;
  int year;
  int bedrag;
  Produkt produkt;
  Persoon persoon;
  String commentaar;

  Transaktie(PostData pd, ProduktList pl, PersoonList pel)
  {
    volgnr = new Integer(pd.getValue("volgnr")).intValue();
    int btwperc = new Integer(pd.getValue("btwperc")).intValue();
    switch (btwperc)
    {
      case 0:btw=false;laagbtw=false;break;
      case 6:btw=true;laagbtw=true;break;
      case 19:btw=true;laagbtw=false;break;
    }
//    btw = pd.getValue("btw").equalsIgnoreCase("on");
//    laagbtw = pd.getValue("laagbtw").equalsIgnoreCase("on");
    inkomsten = pd.getValue("inkomsten").equalsIgnoreCase("on");
    betaald = pd.getValue("betaald").equalsIgnoreCase("on");
    day = new Integer(pd.getValue("day")).intValue();
    month = new Integer(pd.getValue("month")).intValue()+1;
    year = new Integer(pd.getValue("year")).intValue();
    bedrag = new Integer(pd.getValue("prijs")).intValue();
    produkt = (Produkt) pl.get(new Integer(pd.getValue("produkt")).intValue());
    persoon = (Persoon) pel.get(new Integer(pd.getValue("persoon")).intValue());
    commentaar = pd.getValue("commentaar");
    gefactureerd=false;
  }

}
