import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;

class TransaktieList extends ArrayList implements Serializable
{
  ProduktList pl;
  PersoonList pel;
  NOBSBoolean changed;

  TransaktieList(ProduktList pl, PersoonList pel, NOBSBoolean nb)
  {
    this.pl=pl;
    this.pel=pel;
    changed=nb;
  }

  String transaktieOverzicht(PostData pd)
  {
    String result=new String();
    try {
    int maand = new Integer(pd.getValue("month")).intValue();
    int jaar = new Integer(pd.getValue("year")).intValue();
    int produkt = new Integer(pd.getValue("produkt")).intValue();
    int persoon = new Integer(pd.getValue("persoon")).intValue();
    ArrayList intransakties = new ArrayList();
    ArrayList outtransakties = new ArrayList();
    ArrayList indatums = new ArrayList();//long
    ArrayList outdatums = new ArrayList();
    ArrayList invalues = new ArrayList();//int
    ArrayList outvalues = new ArrayList();
    int highestin=0;
    int highestout=0;
    int totaalin=0;
    int totaaluit=0;
    for (int i = 0; i < size(); i++)
    {
      Transaktie t = (Transaktie) get(i);
      if (maand!=999)
        if (maand+1!=t.month)
          continue;
      if (jaar!=t.year)
        continue;
      if (produkt!=999)
        if (produkt!=pl.indexOf(t.produkt))
          continue;
      if (persoon!=999)
        if (persoon!=pel.indexOf(t.persoon))
          continue;

      Calendar c = Calendar.getInstance();
      c.set(t.year,t.month,t.day,0,0,0);
      long l = c.getTime().getTime();

      if (t.inkomsten)
      {
        totaalin+=t.bedrag;
        intransakties.add(t);
        boolean found=false;
        for (int j = 0; j < indatums.size(); j++)
        {
          Long L = (Long) indatums.get(j);
          if (L.longValue()==l)
          {
            Integer I = (Integer) invalues.get(j);
            invalues.set(j,new Integer(I.intValue()+t.bedrag));
            if (I.intValue()+t.bedrag>highestin)
              highestin=I.intValue()+t.bedrag;
            found=true;
            break;
          }
        }
        if (!found)
        {
          int index=0;
          for (int j = 0; j < indatums.size(); j++)
          {
            Long L = (Long) indatums.get(j);
            if (L.longValue()<l)
            {
              index=j;
              break;
            }
          }
          indatums.add(index,new Long(l));
          invalues.add(index,new Integer(t.bedrag));
          if (t.bedrag>highestin)
            highestin=t.bedrag;
        }
      }
      else //t.inkomsten?
      {
        outtransakties.add(t);
        totaaluit+=t.bedrag;
        boolean found=false;
        for (int j = 0; j < outdatums.size(); j++)
        {
          Long L = (Long) outdatums.get(j);
          if (L.longValue()==l)
          {
            Integer I = (Integer) outvalues.get(j);
            outvalues.set(j,new Integer(I.intValue()+t.bedrag));
            if (I.intValue()+t.bedrag>highestout)
              highestout=I.intValue()+t.bedrag;
            found=true;
            break;
          }
        }
        if (!found)
        {
          int index=0;
          for (int j = 0; j < outdatums.size(); j++)
          {
            Long L = (Long) outdatums.get(j);
            if (L.longValue()<l)
            {
              index=j;
              break;
            }
          }
          outdatums.add(index,new Long(l));
          outvalues.add(index,new Integer(t.bedrag));
          if (t.bedrag>highestout)
            highestout=t.bedrag;
        }
      }
    }
result+="<body bgcolor=white text=black>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transaktie overzicht van ";
      switch (maand)
      {
        case 0:result+="januari";break;
        case 1:result+="februari";break;
        case 2:result+="maart";break;
        case 3:result+="april";break;
        case 4:result+="mei";break;
        case 5:result+="juni";break;
        case 6:result+="july";break;
        case 7:result+="augustus";break;
        case 8:result+="september";break;
        case 9:result+="oktober";break;
        case 10:result+="november";break;
        case 11:result+="december";break;
      }
result+=" "+jaar+"<br>";
result+="</h2>";
    result+="<table width=100%><tr><td align=left>";
    if (produkt==999)
      result+="Alle produkten";
    else
    {
      Produkt p = (Produkt) pl.get(produkt);
      result+="produkt: "+p.omschrijving;
    }
    result+="<BR>";
    if (persoon==999)
      result+="Alle personen";
    else
    {
      Persoon p = (Persoon) pel.get(persoon);
      result+="persoon: "+p.naam;
    }
    result+="</td><td align=right>";
      String s = new Integer(totaalin).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    if (totaalin>0)
      result+="totaal bijgeboekt: � "+s+"<br>";
      s = new Integer(totaaluit).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    if (totaaluit>0)
      result+="totaal afgeboekt: � "+s;
    result+="</td></tr></table>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="<hr>";
result+="<b>BTW</b> <i>Betaald</i> <u>Inkomsten</u><br>";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Volg nr";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Datum";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Prijs";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Gefactureerd";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Produkt";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Persoon";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Commentaar";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
result+=" <tr><td colspan=7 align=center>inkomsten</td></tr>";
    for (int i = 0; i < intransakties.size(); i++)
    {
      Transaktie t = (Transaktie) intransakties.get(i);
      s = new Integer(t.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      String header=new String();
      String footer=new String();
      if (t.btw)
      {
        header+="<b>";
        footer="</b>"+footer;
      }
      if (t.betaald)
      {
        header+="<i>";
        footer="</i>"+footer;
      }
      if (t.inkomsten)
      {
        header+="<u>";
        footer="</u>"+footer;
      }

      result+="<tr><td align=center>"+t.volgnr+"</td><td align=center>"+t.day+" "+t.month+" "+t.year+"</td><td>� "+header+s+footer+"</td><td align=center>"+(t.gefactureerd?"Ja":"Nee")+"</td><td>"+t.produkt.omschrijving+"</td><td>"+t.persoon.naam+"</td><td>"+t.commentaar+"</td></tr>";
    }

//grafiekenzooi!
    result+="<tr><td colspan=7>";
    result+="<table><tr>";
    for (int i = 0; i < indatums.size(); i++)
    {
//      Long L = (Long) indatums.get(i);
      Integer I = (Integer) invalues.get(i);
      float hv = highestin;
      float tv = I.intValue();
      float full = 100;
      float fresult = (tv/hv)*full;
      int rowheight = (int) fresult;
      result+="<td valign=bottom><table><tr height="+rowheight+"><td bgcolor=white width=10></td></tr></table></td>";
//      result+=new Date(L.longValue()).toString()+" "+I.intValue()+"<br>";
    }
    result+="</tr></table>";
    result+="</td></tr>";

result+=" <tr><td colspan=7 align=center>uitgaven</td></tr>";
    for (int i = 0; i < outtransakties.size(); i++)
    {
      Transaktie t = (Transaktie) outtransakties.get(i);
      s = new Integer(t.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      String header=new String();
      String footer=new String();
      if (t.btw)
      {
        header+="<b>";
        footer="</b>"+footer;
      }
      if (t.betaald)
      {
        header+="<i>";
        footer="</i>"+footer;
      }
      if (t.inkomsten)
      {
        header+="<u>";
        footer="</u>"+footer;
      }

      result+="<tr><td align=center>"+t.volgnr+"</td><td align=center>"+t.day+" "+t.month+" "+t.year+"</td><td>� "+header+s+footer+"</td><td align=center>"+(t.gefactureerd?"Ja":"Nee")+"</td><td>"+t.produkt.omschrijving+"</td><td>"+t.persoon.naam+"</td><td>"+t.commentaar+"</td></tr>";
    }

    //grafiekenzooi!
    result+="<tr><td colspan=7>";
    result+="<table><tr>";
    for (int i = 0; i < outdatums.size(); i++)
    {
//      Long L = (Long) indatums.get(i);
      Integer I = (Integer) outvalues.get(i);
      float hv = highestout;
      float tv = I.intValue();
      float full = 100;
      float fresult = (tv/hv)*full;
      int rowheight = (int) fresult;
      result+="<td valign=bottom><table><tr height="+rowheight+"><td bgcolor=white width=10></td></tr></table></td>";
//      result+=new Date(L.longValue()).toString()+" "+I.intValue()+"<br>";
    }
    result+="</tr></table>";
    result+="</td></tr>";

result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
  } catch (Exception e)
  { System.out.println(e.toString()); }
    return result;
  }

  String btwOverzicht(int maand, int jaar)
  {
    String result = new String();
    int btwinkomsten=0;//totaal btw inkomsten
    int btwuitgaven=0;//totaal btw uitgaven
    int totininbtw=0;//totaal inkomsten incl btw
    int totuitinbtw=0;//totaal uitgaven incl btw
    int laagbtwinkomsten=0;//totaal btw inkomsten
    int laagbtwuitgaven=0;//totaal btw uitgaven
    int laagtotininbtw=0;//totaal inkomsten incl btw
    int laagtotuitinbtw=0;//totaal uitgaven incl btw
    int ebin=0;//totaal inkomsten excl btw
    int ebuit=0;//totaal uitgaven excl btw

    String s=new String();
    result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="BTW Overzicht van ";
/*    switch (maand)
    {
      case 1:result+="eerste";break;
      case 2:result+="tweede";break;
      case 3:result+="derde";break;
      case 4:result+="vierde";break;
    }
result+=" kwartaal "+jaar;*/
    switch (maand)
    {
      case 1:result+="januari";break;
      case 2:result+="februari";break;
      case 3:result+="maart";break;
      case 4:result+="april";break;
      case 5:result+="mei";break;
      case 6:result+="juni";break;
      case 7:result+="juli";break;
      case 8:result+="augustus";break;
      case 9:result+="september";break;
      case 10:result+="oktober";break;
      case 11:result+="november";break;
      case 12:result+="december";break;
    }
result+=" "+jaar;
    
result+="</h2>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="<hr>";

ArrayList inprodukten = new ArrayList();
ArrayList intransakties = new ArrayList();
ArrayList intotinbtw = new ArrayList();
ArrayList inbtw = new ArrayList();
ArrayList laaginprodukten = new ArrayList(); // lijst van produkten
ArrayList laagintransakties = new ArrayList(); // lijst van transaktie aantallen (per produkt)
ArrayList laagintotinbtw = new ArrayList(); // lijst van totale bedragen incl btw (per produkt)
ArrayList laaginbtw = new ArrayList(); // lijst van totaal betaalde btw (per produkt)
ArrayList ebinprodukten = new ArrayList();  //lijst van produkten
ArrayList ebintransakties = new ArrayList(); // lijst van transaktie aantallen (per produkt)
ArrayList ebintotaal = new ArrayList(); // lijst van totalen (per produkt)

    for (int i = 0; i < size(); i++)
    {
      Transaktie t = (Transaktie) get(i);
      if (t.year!=jaar)
        continue;
/*      int kwartaal=0;
      switch (t.month)
      {
        case 1:;
        case 2:;
        case 3:kwartaal=1;break;
        case 4:;
        case 5:;
        case 6:kwartaal=2;break;
        case 7:;
        case 8:;
        case 9:kwartaal=3;break;
        case 10:;
        case 11:;
        case 12:kwartaal=4;break;
      }*/
      int kwartaal=t.month;
      if (maand!=kwartaal)
        continue;
      if (!t.inkomsten)
        continue;
      if (!t.btw)
      {
        ebin+=t.bedrag;
        if (ebinprodukten.contains(t.produkt))
        {
          int pid = ebinprodukten.indexOf(t.produkt);
          Integer io = new Integer(0);
          io = (Integer) ebintransakties.get(pid);
          ebintransakties.set(pid,new Integer(io.intValue()+1));
          io = (Integer) ebintotaal.get(pid);
          ebintotaal.set(pid,new Integer(io.intValue()+t.bedrag));
        }
        else
        {
          ebinprodukten.add(t.produkt);
          ebintransakties.add(new Integer(1));
          ebintotaal.add(new Integer(t.bedrag));
        }
      }
      else
      {
        if (!t.laagbtw)
          if (inprodukten.contains(t.produkt))
          {
            int pid = inprodukten.indexOf(t.produkt);
            Integer io = new Integer(0);
            io = (Integer) intransakties.get(pid);
            intransakties.set(pid,new Integer(io.intValue()+1));
            io = (Integer) intotinbtw.get(pid);
            intotinbtw.set(pid,new Integer(io.intValue()+t.bedrag));
            io = (Integer) inbtw.get(pid);
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/119)*19;
            int tbtwi=Math.round(tbtwf);
            inbtw.set(pid,new Integer(io.intValue()+tbtwi));
          }
          else
          {
            inprodukten.add(t.produkt);
            intransakties.add(new Integer(1));
            intotinbtw.add(new Integer(t.bedrag));
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/119)*19;
            int tbtwi=Math.round(tbtwf);
            inbtw.add(new Integer(tbtwi));
          }
        else //?!t.laagbtw
          if (laaginprodukten.contains(t.produkt))
          {
            int pid = laaginprodukten.indexOf(t.produkt);
            Integer io = new Integer(0);
            io = (Integer) laagintransakties.get(pid);
            laagintransakties.set(pid,new Integer(io.intValue()+1));
            io = (Integer) laagintotinbtw.get(pid);
            laagintotinbtw.set(pid,new Integer(io.intValue()+t.bedrag));
            io = (Integer) laaginbtw.get(pid);
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/106)*6;
            int tbtwi=Math.round(tbtwf);
            laaginbtw.set(pid,new Integer(io.intValue()+tbtwi));
          }
          else
          {
            laaginprodukten.add(t.produkt);
            laagintransakties.add(new Integer(1));
            laagintotinbtw.add(new Integer(t.bedrag));
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/106)*6;
            int tbtwi=Math.round(tbtwf);
            laaginbtw.add(new Integer(tbtwi));
          }
        if (!t.laagbtw)
        {
          float fbedrag = t.bedrag;
          float tbtwf =(fbedrag/119)*19;
          int tbtwi=Math.round(tbtwf);
          btwinkomsten+=tbtwi;
          totininbtw+=t.bedrag;
        }
        else
        {
          float fbedrag = t.bedrag;
          float tbtwf =(fbedrag/106)*6;
          int tbtwi=Math.round(tbtwf);
          laagbtwinkomsten+=tbtwi;
          laagtotininbtw+=t.bedrag;
        }
      }
    }
//-- 19% btw
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=4 align=center><b>Inkomsten 19%</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal incl. BTW</b></font></td><td bgcolor=gray><font color=silver><b>BTW</b></font></td></tr>";
    for (int i = 0; i < inprodukten.size(); i++)
    {
      Produkt p = (Produkt) inprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) intransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) intotinbtw.get(i);
      int totinbtw = io.intValue();
      io = (Integer) inbtw.get(i);
      int btw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td><td>";
      s = new Integer(btw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(totininbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td><td bgcolor=gray>";
      s = new Integer(btwinkomsten).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";
//--6%
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=4 align=center><b>Inkomsten 6%</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal incl. BTW</b></font></td><td bgcolor=gray><font color=silver><b>BTW</b></font></td></tr>";
    for (int i = 0; i < laaginprodukten.size(); i++)
    {
      Produkt p = (Produkt) laaginprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) laagintransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) laagintotinbtw.get(i);
      int totinbtw = io.intValue();
      io = (Integer) laaginbtw.get(i);
      int btw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td><td>";
      s = new Integer(btw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(laagtotininbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td><td bgcolor=gray>";
      s = new Integer(laagbtwinkomsten).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";
//--excl. btw
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=3 align=center><b>Inkomsten excl. BTW</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal</b></font></td></tr>";
    for (int i = 0; i < ebinprodukten.size(); i++)
    {
      Produkt p = (Produkt) ebinprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) ebintransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) ebintotaal.get(i);
      int totinbtw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(ebin).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";

//einde inkomsten
result+="<hr>";
ArrayList uitprodukten = new ArrayList();
ArrayList uittransakties = new ArrayList();
ArrayList uittotinbtw = new ArrayList();
ArrayList uitbtw = new ArrayList();
ArrayList laaguitprodukten = new ArrayList();
ArrayList laaguittransakties = new ArrayList();
ArrayList laaguittotinbtw = new ArrayList();
ArrayList laaguitbtw = new ArrayList();
ArrayList ebuitprodukten = new ArrayList();
ArrayList ebuittransakties = new ArrayList();
ArrayList ebuittotaal = new ArrayList();

    for (int i = 0; i < size(); i++)
    {
      Transaktie t = (Transaktie) get(i);
      if (t.year!=jaar)
        continue;
/*      int kwartaal=0;
      switch (t.month)
      {
        case 1:;
        case 2:;
        case 3:kwartaal=1;break;
        case 4:;
        case 5:;
        case 6:kwartaal=2;break;
        case 7:;
        case 8:;
        case 9:kwartaal=3;break;
        case 10:;
        case 11:;
        case 12:kwartaal=4;break;
      }*/
      int kwartaal=t.month;
      if (maand!=kwartaal)
        continue;
      if (t.inkomsten)
        continue;
      if (!t.btw)
      {
        ebuit+=t.bedrag;
        if (ebuitprodukten.contains(t.produkt))
        {
          int pid = ebuitprodukten.indexOf(t.produkt);
          Integer io = new Integer(0);
          io = (Integer) ebuittransakties.get(pid);
          ebuittransakties.set(pid,new Integer(io.intValue()+1));
          io = (Integer) ebuittotaal.get(pid);
          ebuittotaal.set(pid,new Integer(io.intValue()+t.bedrag));
        }
        else
        {
          ebuitprodukten.add(t.produkt);
          ebuittransakties.add(new Integer(1));
          ebuittotaal.add(new Integer(t.bedrag));
        }
      }
      else
      {
        if (!t.laagbtw)
          if (uitprodukten.contains(t.produkt))
          {
            int pid = uitprodukten.indexOf(t.produkt);
            Integer io = new Integer(0);
            io = (Integer) uittransakties.get(pid);
            uittransakties.set(pid,new Integer(io.intValue()+1));
            io = (Integer) uittotinbtw.get(pid);
            uittotinbtw.set(pid,new Integer(io.intValue()+t.bedrag));
            io = (Integer) uitbtw.get(pid);
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/119)*19;
            int tbtwi=Math.round(tbtwf);
            uitbtw.set(pid,new Integer(io.intValue()+tbtwi));
          }
          else
          {
            uitprodukten.add(t.produkt);
            uittransakties.add(new Integer(1));
            uittotinbtw.add(new Integer(t.bedrag));
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/119)*19;
            int tbtwi=Math.round(tbtwf);
            uitbtw.add(new Integer(tbtwi));
          }
        else
          if (laaguitprodukten.contains(t.produkt))
          {
            int pid = laaguitprodukten.indexOf(t.produkt);
            Integer io = new Integer(0);
            io = (Integer) laaguittransakties.get(pid);
            laaguittransakties.set(pid,new Integer(io.intValue()+1));
            io = (Integer) laaguittotinbtw.get(pid);
            laaguittotinbtw.set(pid,new Integer(io.intValue()+t.bedrag));
            io = (Integer) laaguitbtw.get(pid);
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/106)*6;
            int tbtwi=Math.round(tbtwf);
            laaguitbtw.set(pid,new Integer(io.intValue()+tbtwi));
          }
          else
          {
            laaguitprodukten.add(t.produkt);
            laaguittransakties.add(new Integer(1));
            laaguittotinbtw.add(new Integer(t.bedrag));
            float fbedrag = t.bedrag;
            float tbtwf =(fbedrag/106)*6;
            int tbtwi=Math.round(tbtwf);
            laaguitbtw.add(new Integer(tbtwi));
          }
        if (!t.laagbtw)
        {
          float fbedrag = t.bedrag;
          float tbtwf =(fbedrag/119)*19;
          int tbtwi=Math.round(tbtwf);
          btwuitgaven+=(tbtwi);
          totuitinbtw+=t.bedrag;
        }
        else
        {
          float fbedrag = t.bedrag;
          float tbtwf =(fbedrag/106)*6;
          int tbtwi=Math.round(tbtwf);
          laagbtwuitgaven+=(tbtwi);
          laagtotuitinbtw+=t.bedrag;
        }
      }
    }
//--19%
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=4 align=center><b>Uitgaven 19%</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal incl. BTW</b></font></td><td bgcolor=gray><font color=silver><b>BTW</b></font></td></tr>";
    for (int i = 0; i < uitprodukten.size(); i++)
    {
      Produkt p = (Produkt) uitprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) uittransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) uittotinbtw.get(i);
      int totinbtw = io.intValue();
      io = (Integer) uitbtw.get(i);
      int btw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td><td>";
      s = new Integer(btw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(totuitinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td><td bgcolor=gray>";
      s = new Integer(btwuitgaven).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";
//--6%
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=4 align=center><b>Uitgaven 6%</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal incl. BTW</b></font></td><td bgcolor=gray><font color=silver><b>BTW</b></font></td></tr>";
    for (int i = 0; i < laaguitprodukten.size(); i++)
    {
      Produkt p = (Produkt) laaguitprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) laaguittransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) laaguittotinbtw.get(i);
      int totinbtw = io.intValue();
      io = (Integer) laaguitbtw.get(i);
      int btw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td><td>";
      s = new Integer(btw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(laagtotuitinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td><td bgcolor=gray>";
      s = new Integer(laagbtwuitgaven).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";
//--excl. btw
result+="<table width=100%>";
result+="<tr><td bgcolor=gray colspan=3 align=center><b>Uitgaven excl. BTW</b></td></tr>";
result+="<tr><td bgcolor=gray><font color=silver><b>Produkt</b></font></td><td bgcolor=gray><font color=silver><b>Transakties</b></font></td><td bgcolor=gray><font color=silver><b>Totaal</b></font></td></tr>";
    for (int i = 0; i < ebuitprodukten.size(); i++)
    {
      Produkt p = (Produkt) ebuitprodukten.get(i);
      Integer io = new Integer(0);
      io = (Integer) ebuittransakties.get(i);
      int transakties = io.intValue();
      io = (Integer) ebuittotaal.get(i);
      int totinbtw = io.intValue();
      result+="<tr><td>"+p.omschrijving+"</td><td>"+transakties+"</td><td>";
      s = new Integer(totinbtw).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="� "+s;
      result+="</td></tr>";
    }
    result+="<tr><td colspan=2 bgcolor=gray>Totaal:</td><td bgcolor=gray>";
      s = new Integer(ebuit).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    result+="� "+s;
    result+="</td></tr>";
    result+="</table>";

//einde uitgaven
result+="<hr>";
result+="<table>";
result+="<tr><td>BTW inkomsten: </td><td>� ";
      s = new Integer(btwinkomsten+laagbtwinkomsten).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
      result+="</td></tr>";
result+="<tr><td>BTW uitgaven: </td><td>� ";
      s = new Integer(btwuitgaven+laagbtwuitgaven).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
      result+="</td></tr>";
result+="<tr><td>Verschil: </td><td>� ";
      s = new Integer((btwinkomsten+laagbtwinkomsten)-(btwuitgaven+laagbtwuitgaven)).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
    result+="</td></tr>";
    result+="</table>";

result+="<hr>";
    //totalen excl. btw
result+="<table>";
result+="<tr><td>inkomsten excl. BTW: </td><td>� ";
      s = new Integer(ebin).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
      result+="</td></tr>";
result+="<tr><td>uitgaven excl. BTW: </td><td>� ";
      s = new Integer(ebuit).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
      result+="</td></tr>";
result+="<tr><td>Verschil: </td><td>� ";
      s = new Integer(ebin-ebuit).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+=s;
    result+="</td></tr>";
    result+="</table>";
    return result;
  }

  String openPosten(int pid)
  {
    Persoon p = new Persoon("alle personen");
    if (pid!=999)
      p = (Persoon) pel.get(pid);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Openstaande posten van "+p.naam;
result+="</h2>";
if (pid!=999)
{
result+="<table width=100%><tr><td align=left>";
result+="   <form method=POST action=http://localhost/maakfactuur.html>";
result+="     Betreft: <input type=tet name=betreft value=\"Autorijlessen categorie B\"><br>";
result+="     <input type=hidden name=persoon value="+pid+">";
result+="     <input type=submit value=\"Maak factuur\">";
result+="   </form>";
}
result+="</td><td align=right>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="</td></tr></table>";

result+="<hr>";
result+="";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Volg nr";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Datum";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				BTW";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				In/Uit";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Prijs";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Produkt";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Commentaar";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Gefactureerd";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Betaald";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
    for (int i = size()-1; i > size()-26; i--)
    {
      if (i<0)
        break;
      Transaktie t = (Transaktie) get(i);
      if (pid != 999)
        if (pid != pel.indexOf(t.persoon))
          continue;
      if (t.betaald)
        continue;
      String s = new Integer(t.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      result+="<tr><td align=center>"+t.volgnr+"</td><td align=center>"+t.day+" "+t.month+" "+t.year+"</td><td align=center>"+(t.btw?"Ja":"Nee")+"</td><td align=center>"+(t.inkomsten?"In":"Uit")+"</td><td>� "+s+"</td><td>"+t.produkt.omschrijving+"</td><td>"+t.commentaar+"</td><td align=center>"+(t.gefactureerd?"Ja":"Nee")+"</td><td align=center><form method=POST action=http://localhost/betaald.html><input type=hidden name=transaktie value="+i+"><input type=submit value=Betaald></form></td></tr>";
    }
result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
    return result;
  }

  String postBetaald(int pid)
  {
    changed.bool=true;
    Transaktie t = (Transaktie) get(pid);
    t.betaald=true;
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transaktie betaald";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/openposten.html>";
result+="			<input type=submit value=\"Openstaande posten\">";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String remTransaktie(int pid)
  {
    changed.bool=true;
    remove(pid);
    String result = new String();
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transaktie verwijderd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/transakties.html>";
result+="			<input type=submit value=Transakties>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String saveTransaktie(Transaktie t)
  {
    changed.bool=true;
    String result=new String();
    add(t);
result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transaktie toegevoegd";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="<tr>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/transakties.html>";
result+="			<input type=submit value=Transakties>";
result+="		</form>";
result+="	</td>";
result+="	<td>";
result+="	<td align=center>";
result+="		<form method=POST action=http://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="		</form>";
result+="	</td>";
result+="</tr>";
result+="</table>";
result+="</center>";
    return result;
  }

  String addTransaktieMenu(PostData pd)
  {
    String result=new String();
    int pid = new Integer(pd.getValue("produkt")).intValue();
    Produkt p = (Produkt) pl.get(pid);

result+="<body bgcolor=black text=white>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transaktie toevoegen";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/savetransaktie.html>";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+="							Volg nummer:";
result+="						</td>";
result+="						<td>";
    int volgnr=0;
    if (size()>0)
    {
      Transaktie t = (Transaktie) get(size()-1);
      volgnr = t.volgnr+1;
    }
result+=volgnr;
result+="<input type=hidden name=volgnr value="+volgnr+">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Betaald:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=betaald CHECKED >";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Datum:";
result+="						</td>";
result+="						<td>";
    Calendar c = Calendar.getInstance();
    c.setTime(new Date(System.currentTimeMillis()));
result+="		 		<select name=day>";
    for (int i = 1; i < 32; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.DAY_OF_MONTH)==i)
        result+=" selected";
      result+=">"+i+"</option>";
    }
result+="		 		</select>";
result+="		 		<select name=month>";
    for (int i = 0; i < 12; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.MONTH)==i)
        result+=" selected";
      result+=">";
      switch (i)
      {
        case 0:result+="januari";break;
        case 1:result+="februari";break;
        case 2:result+="maart";break;
        case 3:result+="april";break;
        case 4:result+="mei";break;
        case 5:result+="juni";break;
        case 6:result+="july";break;
        case 7:result+="augustus";break;
        case 8:result+="september";break;
        case 9:result+="oktober";break;
        case 10:result+="november";break;
        case 11:result+="december";break;
      }
      result+="</option>";
    }
result+="				</select>";
result+="		 		<select name=year>";
    for (int i = 2002; i < 2013; i++)
    {
      result+="<option value="+i;
      if (c.get(Calendar.YEAR)==i)
        result+=" selected";
      result+=">"+i+"</option>";
    }
result+="		 		</select>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							BTW:";
result+="						</td>";
result+="						<td>";
/*
result+="							<input type=checkbox name=btw";
    if (p.btw)
      result+=" CHECKED ";
result+=">";
*/
result+="<input type=radio name=btwperc value=0";
if (!p.btw & !p.laagbtw)
  result+=" CHECKED ";
result+=">0% - <input type=radio name=btwperc value=6";
if (p.btw & p.laagbtw)
  result+=" CHECKED ";
result+=">6% - <input type=radio name=btwperc value=19";
if (p.btw & !p.laagbtw)
  result+=" CHECKED ";
result+=">19%";
result+="						</td>";
result+="					</tr>";
/*
result+="					<tr>";
result+="						<td>";
result+="							BTW 6%:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=laagbtw";
    if (p.laagbtw)
      result+=" CHECKED ";
result+=">";
result+="						</td>";
result+="					</tr>";
*/
result+="					<tr>";
result+="						<td>";
result+="							Inkomsten:";
result+="						</td>";
result+="						<td>";
result+="							<input type=checkbox name=inkomsten";
    if (p.inkomsten)
      result+=" CHECKED ";
result+=">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Prijs:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=prijs size=5 value="+p.bedrag+">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Produkt:";
result+="						</td>";
result+="						<td>";
result+=p.omschrijving;
result+="<input type=hidden name=produkt value="+pid+">";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Persoon:";
result+="						</td>";
result+="						<td>";
result+=pel.makeSelect(false);
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td>";
result+="							Commentaar:";
result+="						</td>";
result+="						<td>";
result+="							<input type=text name=Commentaar><br>";
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Toevoegen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";
result+="		<td align=right>";
result+="<table>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/transakties.html>";
result+="			<input type=submit value=Transakties>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="	<tr>";
result+="		<td>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="			<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
    return result;

  }

  String transaktieMenu(int length)
  {
    String result = new String();
result+="<body bgcolor=white text=black>";
result+="<font face=Verdana>";
result+="<center>";
result+="<img src=file://c:/RIKOAdmin/RIKOAdmin.jpg>";
result+="<h2>";
result+="Transakties";
result+="</h2>";
result+="<hr>";
result+="<table width=100%>";
result+="	<tr>";
result+="		<td align=left>";
result+="			<form method=POST action=http://localhost/addtransaktie.html>";
result+="				<table>";
result+="					<tr>";
result+="						<td>";
result+=pl.makeSelect(false);
result+="						</td>";
result+="					</tr>";
result+="					<tr>";
result+="						<td colspan=2 align=center>";
result+="							<input type=submit value=Toevoegen>";
result+="						</td>";
result+="					</tr>";
result+="				</table>";
result+="			</form>";
result+="		</td>";

result+="   <td align=center>";
result+="     <form method=POST action=http://localhost/transnr.html>";
result+="       transakties:";
result+="       <input type=text name=transaktieid value="+length+" size=5>";
result+="       <input type=submit value=Opslaan>";
result+="     </form>";
result+="   </td>";

result+="		<td align=right>";
result+="			<form method=POST action=HTTP://localhost/>";
result+="				<input type=submit value=Hoofdmenu>";
result+="			</form>";
result+="		</td>";
result+="	</tr>";
result+="</table>";
result+="";
result+="<hr>";
result+="<b>BTW</b> <i>Betaald</i> <u>Inkomsten</u><br>";
result+="<form method=POST action=http://localhost/remtransaktie.html>";
result+="<table width=100%>";
result+="	<tr bgcolor=gray>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Volg nr";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Datum";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Prijs";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Gefactureerd";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Produkt";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Persoon";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="				Commentaar";
result+="			</b></font>";
result+="		</td>";
result+="		<td align=center>";
result+="			<font color=silver><b>";
result+="<input type=submit value=Verwijderen>";
//result+="				Verwijderen";
result+="			</b></font>";
result+="		</td>";
result+="	</tr>";
//    result+="<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td align=center><input type=submit value=Verwijderen></td></tr>";
    for (int i = size()-1; i > size()-(length+1); i--)
    {
      if (i<0)
        break;
      Transaktie t = (Transaktie) get(i);
      String s = new Integer(t.bedrag).toString();
      if (s.length()<3)
        if (s.length()<2)
          s="0.0"+s;
        else
          s="0."+s;
      else
        s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
      String header=new String();
      String footer=new String();
      if (t.btw)
      {
        header+="<b>";
        footer="</b>"+footer;
      }
      if (t.betaald)
      {
        header+="<i>";
        footer="</i>"+footer;
      }
      if (t.inkomsten)
      {
        header+="<u>";
        footer="</u>"+footer;
      }

      result+="<tr><td align=center>"+t.volgnr+"</td><td align=center>"+t.day+" "+t.month+" "+t.year+"</td><td>� "+header+s+footer+"</td><td align=center>"+(t.gefactureerd?"Ja":"Nee")+"</td><td>"+t.produkt.omschrijving+"</td><td>"+t.persoon.naam+"</td><td>"+t.commentaar+"</td><td align=center><input type=checkbox name="+i+"></td></tr>";
    }
    result+="</form>";
    result+="</table>";
result+="</center>";
result+="</font>";
result+="</body>";
    return result;
  }

}
