/* Decompiled by Mocha from Account.class */
/* Originally compiled from Account.java */

import java.util.*;
import java.io.Serializable;

class Account implements Serializable
{
    String name;
    int id;
    int credits;
    long firstdate;
    long lastdate;
    int totalspent;
    ArrayList mutations;

    Account(String string, int i, String v)
    {
        name = string;
        credits = i;
        id = new Random().nextInt(9000)+1000;
        firstdate = System.currentTimeMillis();
        lastdate = System.currentTimeMillis();
        totalspent = 0;
        mutations = new ArrayList();
        mutations.add(new Mutation(true, i,v ));
    }

    String editCredits(boolean flag, int i, String v)
    {
        int j;
        Mutation mutation;
        String string = new String();
        if (flag)
            credits += i;
        else
        {
            credits -= i;
            totalspent += i;
        }
        mutations.add(new Mutation(flag, i, v));
        string = string + "<center>";
        string = string + "<font size=6>S.R.S @ COM</font><br>NET<hr>";
        string = string + "<font face=verdana>";
        string = string + "<table><tr><td>";
        string = string + "Date";
        string = string + "</td><td>";
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(System.currentTimeMillis()));
        string = string + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1);
        string = string + "</td></tr><tr><td>";
        string = string + "Account";
        string = string + "</td><td>";
        string = string + name;
        string = string + "</td></tr><tr><td>";
        string = string + "Action";
        string = string + "</td><td>";
        string = string + (flag ? "Deposit" : "Withdraw");
        string = string + "</td></tr><tr><td>";
        string = string + "Credits";
        string = string + "</td><td>";
        string = string + i;
        string = string + "</td></tr><tr><td>";
        string = string + "Operator";
        string = string + "</td><td>";
        string = string + v;
        string = string + "</td></tr><tr><td>";
        string = string + "New total";
        string = string + "</td><td>";
        string = string + credits;
        string = string + "</td></tr></table>";
        string = string + "<hr><table>";
        string = string + "<tr><td>Type</td><td>Credits</td><td>Date</td><td>Operator</td></tr>";
        for (j = mutations.size() - 1; j > mutations.size() - 11 && j >= 0; j--)
        {
            mutation = (Mutation)mutations.get(j);
            string = string + mutation.makeRow();
        }
        string = string + "</table>";
        string = string + "<hr>";
        string = string + "<a href=/><font color=black>Thank you for your " + (flag ? "deposit" : "withdraw") + "</font></a>";
        string = string + "</font></center>";
        if (mutations.size()>100)
            mutations.remove(0);
        return string;
    }

    String makeScreen(int i)
    {
        String string = new String();
        string = string + "<head><title>" + name + "</title></head>";
        string = string + "<font face=verdana>";
        string = string + "<table>";
        string = string + "<form action=index.html method=get>";
        string = string + "<tr><td colspan=4 align=center>";
        string = string + "<input type=submit value=mainmenu>";
        string = string + "</td></tr>";
        string = string + "</form>";
        string = string + "<tr><td colspan=4><hr></td></tr>";
        string = string + "<tr><td width=100>";
        string = string + "Name:";
        string = string + "</td><td></td><td>";
        string = string + name;
        string = string + "</td></tr><tr><td>";
        string = string + "I.D.:";
        string = string + "</td><td></td><td>";
        string = string + id;
        string = string + "</td></tr><tr><td>";
        string = string + "</td></tr><tr><td>";
        string = string + "Credits:";
        string = string + "</td><td></td><td>";
        string = string + credits;
        string = string + "</td></tr><tr><td>";
        string = string + "First date:";
        string = string + "</td><td></td><td>";
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(firstdate));
        string = string + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1);
        string = string + "</td></tr><tr><td>";
        string = string + "Last date:";
        string = string + "</td><td></td><td>";
        calendar.setTime(new Date(lastdate));
        string = string + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1);
        string = string + "</td></tr><tr><td>";
        string = string + "Total spent:";
        string = string + "</td><td></td><td>";
        string = string + totalspent;
        string = string + "</td></tr>";
        //------
        string = string + "<tr><td colspan=4><hr></td></tr>";
        string = string + "<form action=addcredits.html method=post>";
        string = string + "<tr><td colspan=2>";
        string = string + "Deposit";
        string = string + "</td><td align=right>";
        string = string + "<input type=text name=credits value=0 size=3>";
        string = string + "<input type=hidden name=account value=" + i + ">";
        string+="</td></tr><tr><td colspan=2>";
        string+="<input type=text name=verkoper></td><td>";
        string = string + "<input type=submit value=\" Increase  \">";
        string = string + "</td></tr>";
        string = string + "</form>";
        
        string = string + "<form action=remcredits.html method=post>";
        string = string + "<tr><td colspan=2>";
        string = string + "Withdraw";
        string = string + "</td><td align=right>";
        string = string + "<input type=text name=credits value=0 size=3>";
        string = string + "<input type=hidden name=account value=" + i + " size=3>";
        string+="</td></tr><tr><td colspan=2>";
        string+="<input type=text name=verkoper></td><td>";
        string = string + "<input type=submit value=Decrease>";
        string = string + "</td></tr>";
        string = string + "</form>";
        //------
        string = string + "<tr><td colspan=4><hr></td></tr>";
        for (int j = 0; j < mutations.size(); j++)
        {
            Mutation mutation = (Mutation)mutations.get(j);
            string = string + mutation.makeRow();
        }
        string = string + "<form action=remaccount.html method=post>";
        string = string + "<tr><td colspan=4><hr></td></tr>";
        string = string + "<tr><td colspan=4 align=center>";
        string = string + "<input type=hidden name=account value=" + i + ">";
        string = string + "<input type=submit value=\"Remove Account\">";
        string = string + "</form>";
        string = string + "</td></tr>";
        string = string + "</table>";
        string = string + "</font>";
        return string;
    }
}
