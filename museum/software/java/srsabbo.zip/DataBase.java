/* Decompiled by Mocha from DataBase.class */
/* Originally compiled from SRSAbbo.java */

import java.io.Serializable;

class DataBase implements Serializable
{
    NOBSBoolean changed;
    java.util.ArrayList Abbos;

    DataBase()
    {
    }
}
