/* Decompiled by Mocha from Mutation.class */
/* Originally compiled from Mutation.java */

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

class Mutation implements Serializable
{
    boolean deposit;
    int credits;
    long date;
    String verkoper;

    Mutation(boolean flag, int i, String v)
    {
        deposit = flag;
        credits = i;
        date = System.currentTimeMillis();
        verkoper = v;
    }

    String makeRow()
    {
        Calendar calendar;
        calendar = Calendar.getInstance();
        calendar.setTime(new Date(date));
        return "<tr><td>" + (deposit ? "Deposit" : "Withdraw") + "</td><td>" + credits + "</td><td>" + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1) + "</td><td>"+verkoper+"</td></tr>";
    }
    
    String makeCells() {
        Calendar calendar;
        calendar = Calendar.getInstance();
        calendar.setTime(new Date(date));
        return "<td>" + (deposit ? "Deposit" : "Withdraw") + "</td><td>" + credits + "</td><td>" + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1) + "</td><td>"+verkoper+"</td>";
    }
    
}
