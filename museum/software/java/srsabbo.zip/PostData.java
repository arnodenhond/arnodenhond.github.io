/* Decompiled by Mocha from PostData.class */
/* Originally compiled from SRSAbbo.java */

import java.util.ArrayList;
import java.util.StringTokenizer;

class PostData
{
    ArrayList elements;
    ArrayList values;

    PostData(String string1)
    {
        elements = new ArrayList();
        values = new ArrayList();
        for (StringTokenizer stringTokenizer = new StringTokenizer(string1, "&"); stringTokenizer.hasMoreTokens(); )
        {
            String string2 = stringTokenizer.nextToken();
            String string3 = string2.substring(0, string2.indexOf("="));
            String string4 = string2.substring(string2.indexOf("=") + 1, string2.length());
            elements.add(string3);
            values.add(string4);
        }
    }

    String getValue(String string1)
    {
        for (int i = 0; i < elements.size(); i++)
        {
            String string2 = (String)elements.get(i);
            if (string2.equalsIgnoreCase(string1))
            {
                String string3 = (String)values.get(i);
                return string3;
            }
        }
        return new String();
    }
}
