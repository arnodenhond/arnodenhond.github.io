
import java.util.*;
import java.io.*;

class NOBSDate extends Date implements Serializable
{

  NOBSDate()
  {
    super();
  }

  NOBSDate(String day, String month, String year)
  {
    Calendar c = Calendar.getInstance();
    c.set(Calendar.DAY_OF_MONTH,new Integer(day).intValue());
    c.set(Calendar.MONTH,new Integer(month).intValue());
    c.set(Calendar.YEAR,new Integer(year).intValue());
    c.set(Calendar.HOUR_OF_DAY,0);
    c.set(Calendar.MINUTE,0);
    c.set(Calendar.SECOND,0);
    c.set(Calendar.MILLISECOND,0);
    this.setTime(c.getTime().getTime());
  }

  String toHiddenElements(String prefix)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(this);
    String result = new String();
    result+="<input type=hidden name="+prefix+"day value="+c.get(Calendar.DAY_OF_MONTH)+">";
    result+="<input type=hidden name="+prefix+"month value="+c.get(Calendar.MONTH)+">";
    result+="<input type=hidden name="+prefix+"year value="+c.get(Calendar.YEAR)+">";
    return result;
  }

  String toHTML(boolean editable, String prefix)
  {
    Calendar c = Calendar.getInstance();
    c.setTime(this);
    String minute = new Integer(c.get(Calendar.MINUTE)).toString();
    if (minute.length()==1)
      minute="0"+minute;
    if (editable)
    {
      String result = new String();
      result+="<select name="+prefix+"day>";
      for (int i = 1; i < 32; i++)
      {
        result+="<option value="+i;
        if (c.get(Calendar.DAY_OF_MONTH)==i)
          result+=" selected";
        result+=">"+i+"</option>";
      }
      result+="</select>";
      result+="<select name="+prefix+"month>";
      for (int i = 0; i < 12; i++)
      {
        result+="<option value="+i;
        if (c.get(Calendar.MONTH)==i)
          result+=" selected";
        result+=">"+(i+1)+"</option>";
      }
      result+="</select>";
      result+="<select name="+prefix+"year>";
      for (int i = 2002; i < 2012; i++)
      {
        result+="<option value="+i;
        if (c.get(Calendar.YEAR)==i)
          result+=" selected";
        result+=">"+i+"</option>";
      }
      result+="</select>";
      return result;
    }
    else
      return c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR)+" "+c.get(Calendar.HOUR_OF_DAY)+":"+minute;
  }

}
