/* Decompiled by Mocha from NOBSBoolean.class */
/* Originally compiled from SRSAbbo.java */

import java.io.Serializable;

class NOBSBoolean implements Serializable
{
    boolean bool;

    NOBSBoolean(boolean flag)
    {
        bool = flag;
    }
}
