/* Decompiled by Mocha from SRSAbbo.class */
/* Originally compiled from SRSAbbo.java */

import java.io.*;
import java.net.*;
import java.util.*;

class SRSAbbo {
    static DataBase db;
    
    SRSAbbo() {
    }
    
    static void savedb()
    throws Exception {
        File file = new File("SRSAbbo.db");
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        db.changed.bool = false;
        objectOutputStream.writeObject(db);
        objectOutputStream.flush();
        fileOutputStream.close();
        System.out.println("DATABASE SAVED");
    }
    
    static void loaddb()
    throws Exception {
        File file = new File("SRSAbbo.db");
        if (file.exists()) {
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            db = (DataBase)objectInputStream.readObject();
            fileInputStream.close();
        }
        else {
            db = new DataBase();
            db.changed = new NOBSBoolean(false);
            db.Abbos = new ArrayList();
            savedb();
        }
    }
    
    static String getRequesthdr(BufferedReader bufferedReader)
    throws Exception {
        String string1 = " ";
        String string2 = "";
        while (!string1.equals("")) {
            string1 = bufferedReader.readLine();
            string2 = string2 + string1 + "|";
        }
        return string2;
    }
    
    static String getPostdata(String string1, BufferedReader bufferedReader)
    throws Exception {
        String string2 = new String();
        int i = string1.toUpperCase().indexOf("CONTENT-LENGTH:");
        if (i != -1) {
            int j = new Integer(string1.substring(i + 16, string1.indexOf("|", i))).intValue();
            char ach[] = new char[j];
            for (int k = 0; k < j; k += bufferedReader.read(ach, k, j - k)) /* null body */ ;
            string2 = new String(ach);
            new URLDecoder();
            string2 = URLDecoder.decode(string2);
        }
        return string2;
    }
    
    static String mainMenu() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < db.Abbos.size(); i++) {
            Account account1 = (Account)db.Abbos.get(i);
            boolean flag1 = false;
            Account account2;
            for (int j = 0; j < arrayList.size(); j++) {
                account2 = (Account)arrayList.get(j);
                if (account1.name.compareToIgnoreCase(account2.name) >= 0)
                    continue;
                arrayList.add(j, account1);
                flag1 = true;
                break;
            }
            if (!flag1)
                arrayList.add(account1);
        }
        String string = new String();
        string = string + "<center>";
        string = string + "<table width=100%>";
        string = string + "<tr><td colspan=2>";
        string = string + "<tr height=100 valign=top><td colspan=2 align=center>";
        string = string + "<font size=10>S.R.S @ COM</font><br>NET<hr>";
        string = string + "</td></tr>";
        string = string + "<tr><td colspan=2 align=center>";
        string+="<form action=quicklogin.html method=post><input size=6 type=text name=code><input type=submit value=login></form></td></tr>";
        string = string + "<tr bgcolor=silver><td colspan=2>";
        string = string + "<font face=verdana color=gray>Quick login</font>";
        string = string + "</td></tr>";
        string = string + "<tr><td colspan=2>";
        string = string + "<hr></td></tr>";
        boolean flag2 = true;
        string = string + "<tr>";
        for (int k = 0; k < arrayList.size(); k++) {
            Account account3 = (Account)arrayList.get(k);
            string = string + "<form action=login.html method=post>";
            string = string + "<td align=center>";
            string = string + "<input type=hidden name=account value=" + db.Abbos.indexOf(account3) + ">";
            string = string + "<input type=submit value=\"" + account3.name + "\">";
            if (account3.credits < 0)
                string = string + "<br><font color=red>negative credit!</font>";
            Calendar calendar1 = Calendar.getInstance();
            Mutation mutation = (Mutation)account3.mutations.get(account3.mutations.size() - 1);
            Calendar calendar2 = Calendar.getInstance();
            calendar2.setTime(new Date(mutation.date));
            calendar2.add(5, 31);
            if (calendar1.getTime().after(calendar2.getTime()))
                string = string + "<br><font color=red>idle account</font>";
            string = string + "</td>";
            string = string + "</form>";
            if (!flag2)
                string = string + "</tr><tr>";
            flag2 = !flag2;
        }
        string = string + "</tr>";
        string = string + "<tr bgcolor=silver><td colspan=2>";
        string = string + "<font face=verdana color=gray>Select an account</font>";
        string = string + "</td></tr></table>";
        string = string + "<hr>";
        string = string + "<table>";
        string = string + "<form action=createaccount.html method=post>";
        string = string + "<tr><td>";
        string = string + "<font face=verdana>Name:</font>";
        string = string + "</td><td>";
        string = string + "<input type=text name=name>";
        string = string + "</td></tr><tr><td>";
        string = string + "<font face=verdana>Credits:</font>";
        string = string + "</td><td>";
        string = string + "<input type=text name=credits value=0>";
        string = string + "</td></tr><tr><td>";
        string = string + "<font face=verdana>Operator:</font>";
        string = string + "</td><td>";
        string = string + "<input type=text name=verkoper>";
        string = string + "</td></tr><tr><td colspan=2 align=center>";
        string = string + "<input type=submit value=Create>";
        string = string + "</td></tr><tr><td colspan=2 bgcolor=silver>";
        string = string + "<font face =verdana color=gray>Create a new account</font>";
        string = string + "</td></tr>";
        string = string + "</form>";
        string = string + "</table>";
        string = string + "<hr>";
        string+="<table>";
        string+="<tr><td align=center colspan=2>";
        string+="<form action=statistics.html method=post>";
        string+="from "+new NOBSDate().toHTML(true,"from")+" to "+new NOBSDate().toHTML(true,"to");
        string+="<input type=submit value=statistics>";
        string+="</form>";
        string+="</td></tr>";
        string = string + "<tr bgcolor=silver> <td colspan=2 align=left>";
        string = string + "<font face=verdana color=gray>Statistics</font>";
        string = string + "</td></tr>";
        string+="</table>";
        
        string = string + "<hr>";
        string = string + "<form action=shutdown.html method=post>";
        string = string + "<input type=submit value=\"Shut down\">";
        string = string + "</form>";
        string = string + "<a href=http://www.nobsoft.com><font face=verdana color=black>noBSoft</font></a>";
        string = string + "</center>";
        return string;
    }
    
    public static void main(String astring[])
    throws Exception {
        NOBSBoolean nOBSBoolean;
        ServerSocket serverSocket;
        Socket socket;
        Object object;
        System.out.println("SRSAbbo v1.2 NOBSOFT");
        loaddb();
        savedb();
        nOBSBoolean = new NOBSBoolean(false);
        serverSocket = new ServerSocket(81);
        serverSocket.setSoTimeout(1000);
        socket = null;
        //        if (!nOBSBoolean.bool) goto 45 else 1193;
        while (!nOBSBoolean.bool) {
            try {
                socket = serverSocket.accept();
            } catch (Exception e) {
                continue;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String string1 = getRequesthdr(bufferedReader);
            StringTokenizer stringTokenizer = new StringTokenizer(string1, " ");
            boolean flag1 = stringTokenizer.nextToken().toUpperCase().equals("POST");
            String string2 = stringTokenizer.nextToken().toUpperCase();
            String string3 = new String();
            if (flag1)
                string3 = getPostdata(string1, bufferedReader);
            PostData postData = new PostData(string3);
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
            printWriter.println("HTTP/1.0 200 OK");
            printWriter.println("content-type=text/html\r\n\r\n");
            System.out.println(string2);
            System.out.println(string3);
            if (string2.equalsIgnoreCase("/quicklogin.html")) {
                Account acnt = null;
                boolean found=false;
                int iid = Integer.valueOf(postData.getValue("code")).intValue();
                for (int i = 0; i < db.Abbos.size(); i++) {
                    acnt= (Account) db.Abbos.get(i);
                    if (acnt.id==iid) {
                        found=true;
                        break;
                    }
                }
                if (found) {
                    postData = new PostData("account="+db.Abbos.indexOf(acnt)+"&id="+acnt.id);
                    string2="/viewaccount.html";
                }
                else {
                    string2="/";
                    printWriter.println("code not found!");
                }
            }
            
            if ((string2.equals("/") | string2.equals("/INDEX.HTML?")))
                printWriter.println(mainMenu());
            if (flag1) {
                if (string2.equalsIgnoreCase("/createaccount.html")) {
                    boolean flag2 = false;
                    Account account5;
                    for (int i = 0; i < db.Abbos.size(); i++) {
                        account5 = (Account)db.Abbos.get(i);
                        if (!account5.name.equalsIgnoreCase(postData.getValue("name")))
                            continue;
                        flag2 = true;
                        break;
                    }
                    if (flag2) {
                        printWriter.println("<center>");
                        printWriter.println("account name in use<br>");
                        printWriter.println("<form action=index.html method=get>");
                        printWriter.println("<input type=submit value=mainmenu>");
                        printWriter.println("</form>");
                        printWriter.println("</center>");
                    }
                    else {
                        Account account6 = new Account(postData.getValue("name"), new Integer(postData.getValue("credits")).intValue(),postData.getValue("verkoper"));
                        db.Abbos.add(account6);
                        printWriter.println("<center>");
                        printWriter.println("<font size=6>S.R.S @ COM</font><br>NET<hr>");
                        printWriter.println("<font face=verdana>");
                        printWriter.println("<table>");
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(new Date(account6.firstdate));
                        printWriter.println("<tr><td>Date</td><td>" + calendar.get(5) + "/" + (calendar.get(2) + 1) + "/" + calendar.get(1) + "</td></tr>");
                        printWriter.println("<tr><td>Name</td><td>" + account6.name + "</td></tr>");
                        printWriter.println("<tr><td>I.D.</td><td>" + account6.id + "</td></tr>");
                        printWriter.println("<tr><td>Operator</td><td>" + postData.getValue("verkoper") + "</td></tr>");
                        printWriter.println("<tr><td>Credits</td><td>" + account6.credits + "</td></tr>");
                        printWriter.println("</table><hr>");
                        printWriter.println("<a href=/><font color=black>Account Created</font></a>");
                        printWriter.println("</font></center>");
                        db.changed.bool = true;
                    }
                }
                if (string2.equalsIgnoreCase("/viewaccount.html")) {
                    Account account1 = (Account)db.Abbos.get(new Integer(postData.getValue("account")).intValue());
                    if (account1.id == new Integer(postData.getValue("id")).intValue())
                        printWriter.println(account1.makeScreen(db.Abbos.indexOf(account1)));
                    else
                        printWriter.println("incorrect I.D.!<br>Press back and try again");
                }
                if (string2.equalsIgnoreCase("/statistics.html")) {
                    NOBSDate from = new NOBSDate(postData.getValue("fromday"),postData.getValue("frommonth"),postData.getValue("fromyear"));
                    NOBSDate to = new NOBSDate(postData.getValue("today"),postData.getValue("tomonth"),postData.getValue("toyear"));
                    printWriter.println("<center>");
                    printWriter.println("statistics from "+from.toHTML(false,"")+" to "+to.toHTML(false,""));
                    printWriter.println("<form action=index.html method=get>");
                    printWriter.println("<input type=submit value=mainmenu>");
                    printWriter.println("</form>");
                    printWriter.println("<table>");
                    printWriter.println("<tr><td>Account</td><td>Type</td><td>Credits</td><td>Date</td><td>Operator</td></tr>");
                    int totalDeposit=0;
                    int totalWithdraw=0;
                    //calculate balance
                    for (int i = 0; i < db.Abbos.size(); i++) {
                        Account acnt=(Account) db.Abbos.get(i);
                        for (int j = 0; j < acnt.mutations.size() ;j++) {
                            Mutation mut = (Mutation) acnt.mutations.get(j);
                            Date dat = new Date(mut.date);
                            if (from.before(dat) && to.after(dat)) {
                                 printWriter.println("<tr><td>"+acnt.name+"</td>"+mut.makeCells()+"</tr>");
                                 if (mut.deposit)
                                     totalDeposit+=mut.credits;
                                 else
                                     totalWithdraw+=mut.credits;
                            }
                        } 
                    }
                    printWriter.println("<tr><td colspan=5><hr></td></tr>");
                    printWriter.println("<tr><td>total deposit</td><td>"+totalDeposit+"</td></tr>");
                    printWriter.println("<tr><td>total witdraw</td><td>"+totalWithdraw+"</td></tr>");
                    printWriter.println("<tr><td>balance</td><td>"+(totalDeposit-totalWithdraw)+"</td></tr>");
                    printWriter.println("</table>");
                    printWriter.println("</center>");
                    
                }
                if (string2.equalsIgnoreCase("/login.html")) {
                    Account account2 = (Account)db.Abbos.get(new Integer(postData.getValue("account")).intValue());
                    printWriter.println("<center>");
                    printWriter.println("<font size=10>S.R.S @ COM</font><br>NET<hr>");
                    printWriter.println("<font face=verdana>");
                    printWriter.println("please enter the password for <b>" + account2.name + "</b>");
                    printWriter.println("<br>");
                    printWriter.println("<form action=viewaccount.html method=post>");
                    printWriter.println("<input type=hidden name=account value=" + postData.getValue("account") + "><input type=text name=id size=6>");
                    printWriter.println("<input type=submit value=\"Log In\">");
                    printWriter.println("</form></font></center><!--code:"+account2.id+"-->");
                }
                if (string2.equalsIgnoreCase("/remaccount.html")) {
                    db.Abbos.remove(new Integer(postData.getValue("account")).intValue());
                    printWriter.println("<center>Account removed<br>");
                    printWriter.println("<form action=index.html method=get>");
                    printWriter.println("<input type=submit value=mainmenu>");
                    printWriter.println("</form>");
                    printWriter.println("</center>");
                    db.changed.bool = true;
                }
                if (string2.equalsIgnoreCase("/addcredits.html")) {
                    Account account3 = (Account)db.Abbos.get(new Integer(postData.getValue("account")).intValue());
                    printWriter.println(account3.editCredits(true, new Integer(postData.getValue("credits")).intValue(),postData.getValue("verkoper")));
                    db.changed.bool = true;
                }
                if (string2.equalsIgnoreCase("/remcredits.html")) {
                    Account account4 = (Account)db.Abbos.get(new Integer(postData.getValue("account")).intValue());
                    printWriter.println(account4.editCredits(false, new Integer(postData.getValue("credits")).intValue(),postData.getValue("verkoper")));
                    db.changed.bool = true;
                }
                if (string2.equalsIgnoreCase("/shutdown.html"))
                    nOBSBoolean.bool = true;
                if (db.changed.bool)
                    savedb();
            }
            //        pop object
            //        pop object
            //System.out.println(object.toString());
            if (socket != null)
                socket.close();
        }
        savedb();
    }
    
    static {
        db = null;
    }
}
