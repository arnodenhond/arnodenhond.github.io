import java.io.*;
import java.net.*;
import java.util.*;

class SRSAdmin2 {
    
    static Database loadDatabase() throws Exception {
        Database result = new Database();
        File f = new File("SRSAdmin2.db");
        if (f.exists()) {
            try {
                FileInputStream fis = new FileInputStream(f);
                ObjectInputStream ois = new ObjectInputStream(fis);
                result = (Database) ois.readObject();
                fis.close();
            }
            catch (Exception e) {
                System.out.println("error while opening database, attempting to restore backup");
                boolean failed = true;
                for (int i = 0; i < 10; i++) {
                    File backup = new File("SRS"+i+"Backup.db");
                    try {
                        FileInputStream fis2 = new FileInputStream(backup);
                        ObjectInputStream ois2 = new ObjectInputStream(fis2);
                        result = (Database) ois2.readObject();
                        fis2.close();
                        failed = false;
                        System.out.println("restored backup "+i);
                    } catch (Exception e2) {
                        System.out.println("backup "+i+" was corrupted");
                        failed=true;
                    }
                    if (failed==false)
                        break;
                }
                if (failed) {
                    System.out.println("unable to restore database");
                    System.exit(0);
                }
            }
        }
        else {
            System.out.println("Creating new database");
            //            result = new Database(); // done at top now
        }
        return result;
    }
    
    static String getRequesthdr(BufferedReader in) throws Exception {
        String templine = " ";
        String requesthdr = "";
        while (!templine.equals("")) {
            templine = in.readLine();
            requesthdr += templine+"|";
        }
        return requesthdr;
    }
    
    static String getPostdata(String requesthdr, BufferedReader in) throws Exception {
        String postdata = new String();
        int clstart=requesthdr.toUpperCase().indexOf("CONTENT-LENGTH:");
        if (clstart!=-1) {
            int length=new Integer(requesthdr.substring(clstart+16,requesthdr.indexOf("|",clstart))).intValue();
            char[] pdchars = new char[length];
            int rl=0;
            while (rl<length)
                rl+=in.read(pdchars,rl,length-rl);
            postdata=new String(pdchars);
            postdata = new URLDecoder().decode(postdata);
        }
        return postdata;
    }
    
    static Type findCode(GroupList gl, String code) {
        for (int i = 0; i < gl.size(); i++) {
            TypeList tl = (TypeList) gl.get(i);
            for (int j = 0; j < tl.size(); j++) {
                Type t = (Type) tl.get(j);
                if (t.code.equals(code))
                    return t;
            }
        }
        return null;
    }
    
    
    public static void main(String[] args) throws Exception {
        String version = "2.3";
        System.out.println("Starting up SRSAdmin "+version+" by noBSoft 2004");
        Database db = loadDatabase();
//read language file here
        File f = new File("language.txt");
        if (f.exists()) {
            BufferedReader lin = new BufferedReader(new FileReader(f));
            db.lang.login = lin.readLine();
            db.lang.user = lin.readLine();
            db.lang.admin = lin.readLine();
            db.lang.cash = lin.readLine();
            db.lang.plastic = lin.readLine();
            db.lang.logoff = lin.readLine();
            db.lang.set = lin.readLine();
            db.lang.curr = lin.readLine();
            db.lang.adminloggedin = lin.readLine();
            db.lang.usernotfound = lin.readLine();
            db.lang.badpw=lin.readLine();
            db.lang.additem=lin.readLine();
            db.lang.nocode=lin.readLine();
            db.lang.delitem=lin.readLine();
            db.lang.receiptsaved=lin.readLine();
            db.lang.notloggedin=lin.readLine();
            db.lang.cashset=lin.readLine();
            db.lang.plasticset=lin.readLine();
            db.lang.dbcleared=lin.readLine();
            db.lang.from=lin.readLine();
            db.lang.to=lin.readLine();
            db.lang.adminpwset =lin.readLine();
            db.lang.useradded = lin.readLine();
            db.lang.userdeld = lin.readLine();
            db.lang.backgroupstats = lin.readLine();
            db.lang.backtypes = lin.readLine();
            db.lang.backmain = lin.readLine();
            db.lang.closewin = lin.readLine();
            db.lang.groups = lin.readLine();
            db.lang.newgroup = lin.readLine();
            db.lang.addgroup = lin.readLine();
            db.lang.stats = lin.readLine();
            db.lang.cleardb = lin.readLine();
            db.lang.loginhist = lin.readLine();
            db.lang.passwords = lin.readLine();
            db.lang.undosale = lin.readLine();
            db.lang.purchase = lin.readLine();
            db.lang.shutdown  = lin.readLine();
            db.lang.groupcreated = lin.readLine();
            db.lang.groupremoved = lin.readLine();
            db.lang.groupexists=lin.readLine();
            db.lang.inventory=lin.readLine();
            db.lang.remgroup=lin.readLine();
            db.lang.newtype=lin.readLine();
            db.lang.addtype=lin.readLine();
            db.lang.backgroups=lin.readLine();
            db.lang.typecreated=lin.readLine();
            db.lang.typeremoved=lin.readLine();
            db.lang.typeexists=lin.readLine();
            db.lang.removeinv=lin.readLine();
            db.lang.removetype=lin.readLine();
            db.lang.name=lin.readLine();
            db.lang.code=lin.readLine();
            db.lang.inprice=lin.readLine();
            db.lang.outprice=lin.readLine();
            db.lang.minimum=lin.readLine();
            db.lang.savetype=lin.readLine();
            db.lang.typesaved=lin.readLine();
            db.lang.invremoved=lin.readLine();
            db.lang.type=lin.readLine();
            db.lang.invnumber=lin.readLine();
            db.lang.value=lin.readLine();
            db.lang.add=lin.readLine();
            db.lang.total=lin.readLine();
            db.lang.addinv=lin.readLine();
            db.lang.invadded=lin.readLine();
            db.lang.lowinv=lin.readLine();
            db.lang.users=lin.readLine();
            db.lang.none=lin.readLine();
            db.lang.adduser=lin.readLine();
            db.lang.username=lin.readLine();
            db.lang.newuser=lin.readLine();
            db.lang.adminpw=lin.readLine();
            db.lang.savepw=lin.readLine();
            db.lang.delete=lin.readLine();
            db.lang.scan=lin.readLine();
            db.lang.flexphone=lin.readLine();
            db.lang.spent=lin.readLine();
            db.lang.earned=lin.readLine();
            db.lang.ssale=lin.readLine();
            db.lang.description=lin.readLine();
            db.lang.save=lin.readLine();
            db.lang.ffsaved=lin.readLine();
            db.lang.sssaved=lin.readLine();
            db.lang.items=lin.readLine();
            db.lang.remove=lin.readLine();
            db.lang.price=lin.readLine();
            db.lang.discount=lin.readLine();
            db.lang.payment=lin.readLine();
            db.lang.comment=lin.readLine();
            db.lang.receipt=lin.readLine();
            db.lang.product=lin.readLine();
            db.lang.amount=lin.readLine();
            db.lang.tax=lin.readLine();
            db.lang.number=lin.readLine();
            db.lang.soldby=lin.readLine();
            db.lang.date=lin.readLine();
            db.lang.thanks=lin.readLine();
            db.lang.purchadded=lin.readLine();
            db.lang.saleundone=lin.readLine();
            db.lang.noreceipt=lin.readLine();
            db.lang.allaccounts=lin.readLine();
            db.lang.filter=lin.readLine();
            db.lang.sfor=lin.readLine();
            db.lang.salestatsfor=lin.readLine();
            db.lang.sold=lin.readLine();
            db.lang.profit=lin.readLine();
            db.lang.turnover=lin.readLine();
            db.lang.group=lin.readLine();
            db.lang.purchstats=lin.readLine();
            db.lang.bought=lin.readLine();
            db.lang.backstats=lin.readLine();
            db.lang.backtypestats=lin.readLine();
        }
        else {
            System.out.println("could not open language file");
            throw new Exception();
        }
        
        NOBSBoolean quit = new NOBSBoolean(false);
        ServerSocket ss = new ServerSocket(80);
        ss.setSoTimeout(1000);
        Socket s = null;
        while (!quit.bool) {
            try {
                try {
                    s = ss.accept();
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    String requesthdr = getRequesthdr(in);
                    
                    StringTokenizer st = new StringTokenizer(requesthdr," ");
                    boolean POST = st.nextToken().toUpperCase().equals("POST");
                    String URL = st.nextToken();
                    URL = new URLDecoder().decode(URL);
                    
                    String postdata=new String();
                    if (POST)
                        postdata = getPostdata(requesthdr, in);
                    postdata = new URLDecoder().decode(postdata);
                    PostData pd = new PostData(postdata);
                    
                    PrintWriter pw = new PrintWriter(s.getOutputStream(),true);
                    pw.println("HTTP/1.0 200 OK\r\n\r\n");
                    
                    System.out.println(URL);
                    System.out.println(postdata);
                    String message = new String();
                    
                    if (URL.equals("/"))
                        pw.println(new Screens().chooseLogin(db));
                    if (POST) {
                        if (URL.equals("/userlogin.html")) {
                            boolean userfound=false;
                            for (int i = 0; i < db.verkopers.size(); i++) {
                                Verkoper v = (Verkoper) db.verkopers.get(i);
                                if (v.name.equalsIgnoreCase(pd.getValue("password"))) {
                                    userfound=true;
                                    db.verkoper=v;
                                    db.userlogin=new Date();
                                    db.loginhistory.add(new NOBSDate());
                                    db.loginnames.add(v);
                                    if (db.loginhistory.size()>25) {
                                        db.loginhistory.remove(0);
                                        db.loginnames.remove(0);
                                    }
                                    message=db.lang.adminloggedin;
                                    URL="/user/main.html";
                                    break;
                                }
                            }
                            if (!userfound) {
                                pw.println(db.lang.usernotfound);
                                pw.println(new Screens().chooseLogin(db));
                            }
                        }
/*                            if (pd.getValue("password").equals(db.userpw)) {
                                db.userlogin=new Date();
                                db.loginhistory.add(new NOBSDate());
                                if (db.loginhistory.size()>25)
                                    db.loginhistory.remove(0);
                                message="you have logged in";
                                URL="/user/main.html";
                            }
                            else {
                                pw.println("incorrect password!");
                                pw.println(new Screens().chooseLogin());
                            }*/
                        if (URL.equals("/adminlogin.html")) {
                            if (pd.getValue("password").equals(db.adminpw)) {
                                db.adminlogin=new Date();
                                message=db.lang.adminloggedin;
                                URL="/admin/main.html";
                            }
                            else {
                                pw.println(db.lang.badpw);
                                pw.println(new Screens().chooseLogin(db));
                            }
                        }
                        //------------------------------start of user section!
                        if (URL.startsWith("/user/")) {
                            Calendar c = Calendar.getInstance();
                            c.setTime(db.userlogin);
                            c.add(Calendar.MINUTE,10);
                            if (c.getTime().after(new Date())) {
                                db.userlogin=new Date();
                                if (URL.equals("/user/viewgroup.html")) {
                                    pw.println(new Screens().header(false,db));
                                    pw.println(db.groups.getGroup(pd.getValue("group")).toHTML("/user/additem.html","/user/main.html",pd.getValue("group"),db.inventory,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/user/addcode.html")) {
                                    Type type = findCode(db.groups,pd.getValue("code"));
                                    if (type!=null) {
                                        int amount = 1;
                                        if (amount>db.inventory.itemsAvailable(type))
                                            amount=db.inventory.itemsAvailable(type);
                                        for (int i = 0; i < amount; i++) {
                                            Item item = db.inventory.getItem(type);
                                            db.inventory.remove(item);
                                            db.basket.add(item);
                                        }
                                        message=db.lang.additem;
                                    }
                                    else
                                        message=db.lang.nocode;
                                    URL="/user/main.html";
                                    
                                }
                                if (URL.equals("/user/additem.html")) {
                                    Type type = db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type"));
                                    int amount = new Integer(pd.getValue("amount")).intValue();
                                    if (amount>db.inventory.itemsAvailable(type))
                                        amount=db.inventory.itemsAvailable(type);
                                    for (int i = 0; i < amount; i++) {
                                        Item item = db.inventory.getItem(type);
                                        db.inventory.remove(item);
                                        db.basket.add(item);
                                    }
                                    message=db.lang.additem;
                                    URL="/user/main.html";
                                }
                                if (URL.equals("/user/removeitem.html")) {
                                    int id = new Integer(pd.getValue("type")).intValue();
                                    int amount = new Integer(pd.getValue("amount")).intValue();
                                    Type type = (Type) db.basket.getUniqueTypes().get(id);
                                    if (amount>db.basket.getTypeAmount(type))
                                        amount=db.basket.getTypeAmount(type);
                                    for (int i = 0; i < amount; i++) {
                                        Item item = db.basket.getItem(type);
                                        db.basket.remove(item);
                                        db.inventory.add(item);
                                    }
                                    message=db.lang.delitem;
                                    URL="/user/main.html";
                                }
                                if (URL.equals("/user/savereceipt.html")) {
                                    //                                    if (db.basket.paid)
                                    if (db.basket.plastic)
                                        db.plastic.bedrag+=db.basket.totalprice.bedrag;
                                    else
                                        db.cash.bedrag+=db.basket.totalprice.bedrag;
                                    db.outhistory.add(new Sale(db.basket,db.saleid,db.verkoper));
                                    db.saleid++;
                                    message=db.lang.receiptsaved;
                                    URL="/user/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/user/addflexphone.html")) {
                                    message=db.flexPhoneList.addFlexPhone(new Bedrag(pd.getValue("ineuro"),pd.getValue("incent")),new Bedrag(pd.getValue("outeuro"),pd.getValue("outcent")),db);
                                    db.cash.bedrag+=new Bedrag(pd.getValue("outeuro"),pd.getValue("outcent")).bedrag;
                                    URL="/user/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/user/addsale.html")) {
                                    message = db.separateSales.addSale(new Bedrag(pd.getValue("ineuro"),pd.getValue("incent")),new Bedrag(pd.getValue("outeuro"),pd.getValue("outcent")),pd.getValue("description"), db.verkoper,db);
                                    db.cash.bedrag+=new Bedrag(pd.getValue("outeuro"),pd.getValue("outcent")).bedrag;
                                    URL="/user/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/user/main.html")) {
                                    pw.println(new Screens().header(false,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println("<form action=/user/addcode.html method=post>");
                                    pw.println("<input type=text name=code>");
                                    pw.println("<input type=submit value=\""+db.lang.scan+"\">");
                                    pw.println("</form>");
                                    pw.println("<hr>");
                                    pw.println(db.groups.toHTML("/user/viewgroup.html",db));
                                    pw.println("<hr>");
                                    //pw.println(new Screens().flexPhone(db));
                                    //pw.println("<hr>");
                                    pw.println(new Screens().addSale(db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/user/credit.html")) {
                                    pw.println(new Screens().header(false,db));
                                    pw.println(db.outhistory.showCredit(db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/user/addpayment.html")) {
                                    message=db.outhistory.getPayHistory(pd.getValue("sale")).addPayment(pd);
                                    db.cash.bedrag+=new Bedrag(pd.getValue("euro"),pd.getValue("cent")).bedrag;
                                    URL="/user/viewcredit.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/user/viewcredit.html")) {
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(db.outhistory.getPayHistory(pd.getValue("sale")).toHTML(pd.getValue("sale"),db.outhistory.getSale(pd.getValue("sale")),db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/user/makereceipt.html"))
                                    pw.println(db.basket.makeReceipt(pd,db.saleid,db.verkoper,db));
                            }
                            else {
                                pw.println(db.lang.notloggedin);
                                pw.println(new Screens().chooseLogin(db));
                            }
                        }
                        //------------------------------start of admin section!
                        if (URL.startsWith("/admin/")) {
                            Calendar c = Calendar.getInstance();
                            c.setTime(db.adminlogin);
                            c.add(Calendar.MINUTE,10);
                            if (c.getTime().after(new Date())) {
                                db.adminlogin=new Date();
                                if (URL.equals("/admin/addgroup.html")) {
                                    message=db.groups.addGroup(pd.getValue("name"),db);
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/removegroup.html")) {
                                    message=db.groups.removeGroup(pd.getValue("group"),db);
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/setcash.html")) {
                                    db.cash.fromHTML(pd.getValue("euro"),pd.getValue("cent"));
                                    message=db.lang.cashset;
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/setplastic.html")) {
                                    db.plastic.fromHTML(pd.getValue("euro"),pd.getValue("cent"));
                                    message=db.lang.plasticset;
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/undosale.html")) {
                                    message=db.outhistory.undo(pd.getValue("sale"),db.inventory,db.cash,db);
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/addpurchase.html")) {
                                    message=db.inhistory.addPurchase(pd.getValue("euro"),pd.getValue("cent"),pd.getValue("comment"),db.purchases,db);
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/cleardb.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    db.outhistory.cleardb(from,to);
                                    db.inhistory.cleardb(from,to);
                                    db.flexPhoneList.cleardb(from,to);
                                    db.separateSales.cleardb(from,to);
                                    message = db.lang.dbcleared+" "+db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"");
                                    URL="/admin/main.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/main.html")) {
                                    pw.println(new Screens().header(true,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(db.groups.toHTML("/admin/viewgroup.html",db));
                                    pw.println(new Screens().adminMenu(db));
                                    pw.println(db.inventory.lowInventoryWarning(db.groups,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/addtype.html")) {
                                    message=db.groups.getGroup(pd.getValue("group")).addItem(pd.getValue("name"),db);
                                    URL="/admin/viewgroup.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/removetype.html")) {
                                    db.inventory.removeInventory(db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type")));
                                    message=db.groups.getGroup(pd.getValue("group")).removeType(pd.getValue("type"),db);
                                    URL="/admin/viewgroup.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/viewgroup.html")) {
                                    pw.println(new Screens().header(true,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(db.groups.getGroup(pd.getValue("group")).toHTML("/admin/viewtype.html","/admin/main.html",pd.getValue("group"),db.inventory,db));
                                    pw.println(db.inventory.lowInventoryWarning(db.groups,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/savetype.html")) {
                                    message=db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type")).fromHTML(pd,db);
                                    URL="/admin/viewtype.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/removeinventory.html")) {
                                    message=db.inventory.removeInventory(db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type")),db.inhistory,db);
                                    URL="/admin/viewtype.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/viewtype.html")) {
                                    pw.println(new Screens().header(true,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type")).toHTML(pd.getValue("group"),pd.getValue("type"),db));
                                    pw.println(db.inventory.lowInventoryWarning(db.groups,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/addinventory.html")) {
                                    message=db.inventory.addInventory(db.groups,db.inhistory,pd,db);
                                    URL="/admin/inventory.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/inventory.html")) {
                                    pw.println(new Screens().header(true,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(db.inventory.showInventory(db.groups.getGroup(pd.getValue("group")),pd.getValue("group"),db));
                                    pw.println(db.inventory.lowInventoryWarning(db.groups,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/loginhistory.html")) {
                                    pw.println(new Screens().header(true,db));
                                    pw.println(new Screens().loginHistory(db.loginhistory,db.loginnames,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/setpasswords.html")) {
                                    db.adminpw=pd.getValue("adminpassword");
                                    //db.userpw=pd.getValue("userpassword");
                                    message=db.lang.adminpwset;
                                    URL="/admin/viewpasswords.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/adduser.html")) {
                                    db.verkopers.add(new Verkoper(pd.getValue("username")));
                                    message=db.lang.useradded;
                                    URL="/admin/viewpasswords.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/deluser.html")) {
                                    db.verkopers.remove(new Integer(pd.getValue("userid")).intValue());
                                    message=db.lang.userdeld;
                                    URL="/admin/viewpasswords.html";
                                    new SaveDatabase(db).start();
                                }
                                if (URL.equals("/admin/viewpasswords.html")) {
                                    pw.println(new Screens().header(true,db));
                                    if (!message.equals(""))
                                        pw.println("<b>"+message+"</b><hr>");
                                    pw.println(new Screens().passwordsMenu(db));
                                    pw.println(new Screens().footer());
                                }
                                
                                if (URL.equals("/admin/viewsale.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    Verkoper sv = null;
                                    if (!pd.getValue("verkoper").equals("")&&!pd.getValue("verkoper").equals("999"))
                                        sv = (Verkoper) db.verkopers.get(new Integer(pd.getValue("verkoper")).intValue());
                                    
                                    int vid = 999;
                                    if (sv!=null)
                                        vid=new Integer(pd.getValue("verkoper")).intValue();

                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.outhistory.getSale(new Integer(pd.getValue("sale")).intValue()).toHTML(pd.getValue("group"),pd.getValue("type"),from,to,vid,db));
                                    pw.println(new Screens().footer());
                                }
                                //type-stats
                                if (URL.equals("/admin/typestats.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    Verkoper sv = null;
                                    if (!pd.getValue("verkoper").equals("")&&!pd.getValue("verkoper").equals("999"))
                                        sv = (Verkoper) db.verkopers.get(new Integer(pd.getValue("verkoper")).intValue());
                                    
                                    int vid = 999;
                                    if (sv!=null)
                                        vid=new Integer(pd.getValue("verkoper")).intValue();

                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"")+"<br>");
                                    pw.println(db.outhistory.typeStats(db.groups.getGroup(pd.getValue("group")).getType(pd.getValue("type")),from,to,pd.getValue("type"),pd.getValue("group"),sv,vid,db));
                                    pw.println("<form action=/admin/groupstats.html method=post>");
                                    pw.println("<input type=hidden name=group value="+pd.getValue("group")+">");
                                    pw.println(from.toHiddenElements("from"));
                                    pw.println(to.toHiddenElements("to"));
                                    pw.println("<input type=hidden name=verkoper value="+vid+">");
                                    pw.println("<input type=submit value=\""+db.lang.backgroupstats+"\">");
                                    pw.println("</form>");
                                    pw.println(new Screens().footer());
                                }
                                //type-stats
                                if (URL.equals("/admin/groupstats.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    Verkoper sv = null;
                                    if (!pd.getValue("verkoper").equals("")&&!pd.getValue("verkoper").equals("999"))
                                        sv = (Verkoper) db.verkopers.get(new Integer(pd.getValue("verkoper")).intValue());
                                    
                                    int vid = 999;
                                    if (sv!=null)
                                        vid=new Integer(pd.getValue("verkoper")).intValue();
                                    
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"")+"<br>");
                                    pw.println(db.outhistory.groupStats(db.groups.getGroup(pd.getValue("group")),from,to,pd.getValue("group"),sv,vid,db));
                                    pw.println("<hr>");
                                    pw.println(db.inhistory.groupStats(db.groups.getGroup(pd.getValue("group")),from,to,db));
                                    pw.println("<form action=/admin/viewgroup.html method=post><input type=hidden name=group value="+pd.getValue("group")+"><input type=submit value=\""+db.lang.backtypes+"\"></form>");
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/statistics.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    Verkoper sv = null;
                                    if (!pd.getValue("verkoper").equals("")&&!pd.getValue("verkoper").equals("999"))
                                        sv = (Verkoper) db.verkopers.get(new Integer(pd.getValue("verkoper")).intValue());
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println("<form action=/admin/statistics.html method=post>");
                                    pw.println(db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"")+" "+db.lang.sfor+" ");
                                    pw.println(new Screens().makeVerkoperSelect(db.verkopers,sv,db));
                                    pw.println(from.toHiddenElements("from"));
                                    pw.println(to.toHiddenElements("to"));
                                    pw.println("<input type=submit value=\""+db.lang.filter+"\"></form>");
                                    pw.println("<br>");
                                    int vid = 999;
                                    if (sv!=null)
                                        vid=new Integer(pd.getValue("verkoper")).intValue();
                                    pw.println(db.outhistory.statistics(db.groups,db.flexPhoneList,db.separateSales,from,to,sv,vid,db));
                                    pw.println("<hr>");
                                    pw.println(db.inhistory.statistics(db.groups,db.purchases,db.flexPhoneList,db.separateSales,from,to,db));
                                    pw.println("<form action=/admin/main.html method=post><input type=submit value=\""+db.lang.backmain+"\"></form>");
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/creditstats.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.outhistory.creditStats(from,to,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/flexphonestats.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.flexPhoneList.stats(from,to,db));
                                    pw.println(new Screens().footer());
                                }
                                if (URL.equals("/admin/separatesalesstats.html")) {
                                    NOBSDate from = new NOBSDate(pd.getValue("fromday"),pd.getValue("frommonth"),pd.getValue("fromyear"));
                                    NOBSDate to = new NOBSDate(pd.getValue("today"),pd.getValue("tomonth"),pd.getValue("toyear"));
                                    pw.println("<html><center>");
                                    pw.println(new Screens().logo());
                                    pw.println(db.separateSales.stats(from,to,db));
                                    pw.println(new Screens().footer());
                                    
                                }
                                if (URL.equals("/admin/shutdown.html")) {
                                    pw.println(db.lang.closewin);
                                    quit.bool=true;
                                }
                            }
                            else {
                                pw.println(db.lang.notloggedin);
                                pw.println(new Screens().chooseLogin(db));
                            }
                        }
                    }
                }
                catch (InterruptedIOException ie)
                {}
            }
            catch (Exception e) {
                System.out.println(e.toString());
                e.printStackTrace(System.out);
            }
            if (s!=null)
                s.close();
        }
    }
    
}