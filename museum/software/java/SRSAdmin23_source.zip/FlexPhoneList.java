import java.util.*;
import java.io.*;

class FlexPhoneList extends ArrayList implements Serializable
{
  String addFlexPhone(Bedrag in, Bedrag out,Database db)
  {
    add(new FlexPhone(in,out));
    return db.lang.ffsaved;
  }

  Bedrag getEarned(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        result.bedrag+=fp.out.bedrag;
    }
    return result;
  }

  Bedrag getProfit(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        result.bedrag+=(fp.out.bedrag-fp.in.bedrag);
    }
    return result;
  }

  Bedrag getSpent(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        result.bedrag+=fp.in.bedrag;
    }
    return result;
  }


  int getNumber(NOBSDate from, NOBSDate to)
  {
    int result=0;
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        result++;
    }
    return result;
  }

  String stats(NOBSDate from, NOBSDate to, Database db)
  {
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=3 align=center><b>"+db.lang.flexphone+" "+db.lang.stats+" "+db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"")+"</b></td></tr>";
    result+="<tr><td width=33% align=center><b>"+db.lang.spent+"</b></td><td width=33% align=center><b>"+db.lang.earned+"</b></td><td width=33% align=center><b>"+db.lang.date+"</b></td></tr>";
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      result+="<tr><td align=center>"+fp.in.toHTML(false,"",db.lang.curr)+"</td><td align=center>"+fp.out.toHTML(false,"",db.lang.curr)+"</td><td align=center>"+fp.date.toHTML(false,"")+"</td></tr>";
    }
    result+="</table>";
    result+="<form action=/admin/statistics.html method=post>";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<input type=submit value=\""+db.lang.backstats+"\">";
    result+="</form>";
    return result;
  }

  void cleardb(NOBSDate from, NOBSDate to)
  {
    ArrayList removeable = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      FlexPhone fp = (FlexPhone) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        removeable.add(fp);
    }
    for (int i = 0; i < removeable.size(); i++)
      remove(removeable.get(i));
  }
}