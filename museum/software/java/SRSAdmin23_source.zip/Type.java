import java.io.*;

class Type implements Serializable
{

  String name;
  String code;
  Bedrag inprice;
  Bedrag outprice;
  int minimum;

  Type(String name)
  {
    this.name=name;
    code="code";
    inprice=new Bedrag(0);
    outprice=new Bedrag(0);
    minimum=10;
  }

  String fromHTML(PostData pd,Database db)
  {
    this.name=pd.getValue("name");
    this.code=pd.getValue("code");
    inprice=new Bedrag(pd.getValue("inpriceeuro"),pd.getValue("inpricecent"));
    outprice=new Bedrag(pd.getValue("outpriceeuro"),pd.getValue("outpricecent"));
    minimum=new Integer(pd.getValue("minimum")).intValue();
    return db.lang.typesaved;
  }

  String toHTML(String group, String type, Database db)
  {
    String result = new String();
    result+="<table width=100% border=10><tr><td colspan=2 align=center><b>"+name+"</b></td></tr>";
    result+="<tr>";
    result+="<form action=/admin/removeinventory.html method=post>";
    result+="<input type=hidden name=group value="+group+">";
    result+="<input type=hidden name=type value="+type+">";
    result+="<td align=center><input type=submit value=\""+db.lang.removeinv+"\"></td>";
    result+="</form>";
    result+="<form action=/admin/removetype.html method=post>";
    result+="<input type=hidden name=group value="+group+">";
    result+="<input type=hidden name=type value="+type+">";
    result+="<td align=center><input type=submit value=\""+db.lang.removetype+"\"></td>";
    result+="</form>";
    result+="</tr>";
    result+="<form action=/admin/savetype.html method=post>";
    result+="<input type=hidden name=group value="+group+">";
    result+="<input type=hidden name=type value="+type+">";
    result+="<tr><td width=50% align=center>"+db.lang.name+":</td><td width=50% align=center><input type=text name=name value=\""+name+"\"></td></tr>";
    result+="<tr><td align=center>"+db.lang.code+":</td><td align=center><input type=text name=code value=\""+code+"\"></td></tr>";
    result+="<tr><td align=center>"+db.lang.inprice+":</td><td align=center>"+inprice.toHTML(true,"inprice",db.lang.curr)+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.outprice+":</td><td align=center>"+outprice.toHTML(true,"outprice",db.lang.curr)+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.minimum+":</td><td align=center><input type=text name=minimum value="+minimum+" size=3></td></tr>";
    result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.savetype+"\"></td></tr>";
    result+="</form>";
    result+="<form action=/admin/viewgroup.html method=post>";
    result+="<input type=hidden name=group value="+group+">";
    result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.backtypes+"\"></td></tr>";
    result+="</form>";
    result+="</table>";
    return result;
  }

}