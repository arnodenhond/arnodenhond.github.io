import java.util.*;
import java.io.*;

class PayHistory extends ArrayList implements Serializable
{

  Bedrag totalPaid()
  {
    int result=0;
    for (int i = 0; i < size(); i++)
    {
      Payment p = (Payment) get(i);
      result+=p.bedrag.bedrag;
    }
    return new Bedrag(result);
  }

  String toHTML(String id, Sale sale, Database db)
  {
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=2 align=center><b>"+sale.comment+"</b></td></tr>";
    result+="<tr><td width=50% align=center>total price: "+sale.price.toHTML(false,"",db.lang.curr)+"</td><td width=50% align=center>remaining: "+new Bedrag(sale.price.bedrag-totalPaid().bedrag).toHTML(false,"",db.lang.curr)+"</td></tr>";
    if (size()>0)
      result+="<tr><td align=center><b>date</b></td><td align=center><b>amount</b></td></tr>";
    for (int i = 0; i < size(); i++)
    {
      Payment payment = (Payment) get(i);
      result+="<tr><td align=center>"+payment.date.toHTML(false,"")+"</td><td align=center>"+payment.bedrag.toHTML(false,"",db.lang.curr)+"</td></tr>";
    }
    result+="<form action=/user/addpayment.html method=post>";
    result+="<input type=hidden name=sale value="+id+">";
    result+="<tr><td align=center>"+new Bedrag(0).toHTML(true,"",db.lang.curr)+"</td><td align=center><input type=submit value=\"add payment\"></td></tr>";
    result+="</form>";
    result+="<form action=/user/credit.html method=post>";
    result+="<tr><td colspan=2 align=center><input type=submit value=\"back to list\"></td></tr>";
    result+="</table>";
    return result;
  }

  String addPayment(PostData pd)
  {
    add(new Payment(new Bedrag(pd.getValue("euro"),pd.getValue("cent"))));
    return "payment added";
  }

}
