import java.util.*;
import java.io.*;

class Basket extends ArrayList implements Serializable
{

  Bedrag discount;
  boolean paid;
  boolean plastic;
  String comment;
  Bedrag totalprice;

  ArrayList getUniqueTypes()
  {
    ArrayList result = new ArrayList();
    for (int i=0; i< size(); i++)
    {
      Item item = (Item) get(i);
      if (!result.contains(item.type))
        result.add(item.type);
    }
    return result;
  }

  int getTypeAmount(Type type)
  {
    int result = 0;
    for (int i = 0; i < size(); i++)
    {
      Item item = (Item) get(i);
      if (item.type==type)
        result++;
    }
    return result;
  }

  Item getItem(Type type)
  {
    Item result;
    for (int i = 0; i < size(); i++)
    {
      result = (Item) get(i);
      if (result.type==type)
        return result;
    }
    return null;
  }

  String makeReceipt(PostData pd,int id, Verkoper v,Database db)
  {
    discount=new Bedrag(pd.getValue("discounteuro"),pd.getValue("discountcent"));
    paid=pd.getValue("paid").equals("on");
    plastic=pd.getValue("plastic").equals("on");
    comment=pd.getValue("comment");

    int totalprice=0;
    ArrayList types = getUniqueTypes();

    String result = new String();
    result+="<html><center>";
    result+=new Screens().logo();
    result+=new Screens().address();
    result+=" <table width=100%>";
    result+="<tr><td>"+db.lang.product+"</td><td>"+db.lang.amount+"</td><td>"+db.lang.price+"</td></tr>";

    for (int i = 0; i < types.size(); i++)
    {
      Type type = (Type) types.get(i);
      result+="<tr><td>"+type.name+"</td><td>"+getTypeAmount(type)+"</td><td>"+new Bedrag(type.outprice.bedrag*getTypeAmount(type)).toHTML(false,"",db.lang.curr)+"</td></tr>";
      totalprice+=type.outprice.bedrag*getTypeAmount(type);
    }
    result+="<tr><td colspan=3><hr></td></tr>";
    if (discount.bedrag!=0)
      result+="<tr><td></td><td>"+db.lang.discount+"</td><td>"+discount.toHTML(false,"",db.lang.curr)+"</td></tr>";
    totalprice-=discount.bedrag;
    this.totalprice = new Bedrag(totalprice);
    result+="<tr><td></td><td>"+db.lang.total+"</td><td>"+new Bedrag(totalprice).toHTML(false,"",db.lang.curr)+"</td></tr>";
    float ftp=(float) totalprice;
    float f119 = (float) 119;
    float f19 = (float) 19;
    float fbtw = ftp/f119;
    fbtw*=f19;
    int btw=(int) fbtw;
    result+="<tr><td></td><td>"+db.lang.tax+"</td><td>"+new Bedrag(btw).toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="</table>";
    result+="<hr>";
    result+="<table width=100%>";
    result+="<tr><td>"+db.lang.number+":</td><td>"+id+"</td></tr>";
    result+="<tr><td>"+db.lang.soldby+":</td><td>"+v.name+"</td></tr>";
    if (!comment.equals(""))
      result+="<tr><td>"+db.lang.comment+":</td><td>"+comment+"</td></tr>";
    result+="<tr><td>"+db.lang.date+":</td><td>"+new NOBSDate().toHTML(false,"")+"</td></tr>";
    result+="</table>";
    result+="<form action=/user/savereceipt.html method=post>";
    result+="<input type=submit value=\""+db.lang.thanks+"\">";
    result+="</form>";
    result+="</center></html>";
    return result;
  }

  String showBasket(Database db)
  {
    if (size()==0)
      return "";
    String result = new String();
    ArrayList types = getUniqueTypes();
    int totalprice=0;
  	result+="<table width=100% border=10>";
		result+="<tr><td colspan=2 align=center><b>"+db.lang.items+":</b></td></tr>";
    for (int i=0;i<types.size();i++)
    {
      Type type = (Type) types.get(i);
      int amount = getTypeAmount(type);
      totalprice+=(type.outprice.bedrag*amount);
      result+="<tr><td align=center width=50%>"+type.name+"<br>"+type.outprice.toHTML(false,"",db.lang.curr)+"</td>";
      result+="<form action=/user/removeitem.html method=post>";
      result+="<td align=center width=50%>";
      result+="<input type=hidden name=type value="+i+">";
      result+="<input type=text name=amount value="+amount+" size="+new Integer(amount).toString().length()+">";
      result+="<input type=submit value=\""+db.lang.remove+"\">";
      result+="</td>";
      result+="</form>";
		  result+="</tr>";
    }
    result+="<form action=/user/makereceipt.html method=post>";
    result+="<tr><td align=center>"+db.lang.price+":</td><td align=center>"+new Bedrag(totalprice).toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.discount+":</td><td align=center>"+new Bedrag(0).toHTML(true,"discount",db.lang.curr)+"</td></tr>";
    //result+="<tr><td align=center>paid:</td><td align=center><input type=checkbox name=paid CHECKED ></td></tr>";
    result+="<input type=hidden name=paid value=on>";
    result+="<tr><td align=center>"+db.lang.payment+":</td><td align=center><input type=checkbox name=plastic>"+db.lang.plastic+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.comment+":</td><td align=center><input type=text name=comment></td></tr>";
    result+="<tr><td align=center colspan=2><input type=submit value=\""+db.lang.receipt+"\"></td></tr>";
    result+="</form>";
    result+="</table>";
    result+="<hr>";
    return result;
  }
}
