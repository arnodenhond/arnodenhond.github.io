import java.util.*;
import java.io.*;

class Inventory extends ArrayList implements Serializable
{

  int itemsAvailable(Type type)
  {
    int result=0;
    for (int i = 0; i < size(); i++)
    {
      Item item = (Item) get(i);
      if (item.type==type)
        result++;
    }
    return result;
  }

  String addInventory(GroupList groups, InHistory inhistory, PostData pd,Database db)
  {
    TypeList tl = groups.getGroup(pd.getValue("group"));
    Purchase p = new Purchase();
    inhistory.add(p);
    for (int i = 1; i < pd.values.size(); i++)
    {
      String s = (String) pd.values.get(i);
      String s2 = (String) pd.elements.get(i);
      int tid = new Integer(s2).intValue();
      if (s.equals(""))
        s="0";
      int amount = new Integer(s).intValue();
      Type t = (Type) tl.get(tid);
      for (int j = 0; j < amount; j++)
      {
        Item item = new Item(t);
        p.items.add(item);
        add(item);
      }
    }
    return db.lang.invadded;
  }

  Item getItem(Type type)
  {
    for (int i = 0; i < size(); i++)
    {
      Item item = (Item) get(i);
      if (item.type==type)
        return item;
    }
    return null;
  }

  String showInventory(TypeList group, String id, Database db)
  {
    ArrayList sorted = new ArrayList();
    for (int i = 0; i < group.size(); i++)
    {
      Type a = (Type) group.get(i);
      boolean found=false;
      for (int j = 0; j < sorted.size(); j++)
      {
        Type b = (Type) sorted.get(j);
        if (a.name.compareToIgnoreCase(b.name)<0)
        {
          sorted.add(j,a);
          found=true;
          break;
        }
      }
      if (!found)
        sorted.add(a);
    }
    String result = new String();
    Bedrag totalvalue=new Bedrag(0);
    result+="<table width=100% border=10><tr><td colspan=4 align=center><b>"+group.name+":</b></td></tr>";
    result+="<tr><td width=25% align=center><b>"+db.lang.type+"</b></td><td width=25% align=center><b>"+db.lang.invnumber+"</b></td><td width=25% align=center><b>"+db.lang.value+"</b></td><td width=25% align=center><b>"+db.lang.add+"</b></td></tr>";
    result+="<form action=/admin/addinventory.html method=post>";
    result+="<input type=hidden name=group value="+id+">";
    for (int i = 0; i < sorted.size(); i++)
    {
      Type t = (Type) sorted.get(i);
      result+="<tr><td align=center>"+t.name+"</td><td align=center>"+itemsAvailable(t)+"</td><td align=center>"+getTotalValue(t).toHTML(false,"",db.lang.curr)+"</td><td align=center><input type=text name="+group.indexOf(t)+" value=0 size=1></td></tr>";
      totalvalue.bedrag+=getTotalValue(t).bedrag;
    }
    result+="<tr><td align=center><b>"+db.lang.total+"</b></td><td><td align=center>"+totalvalue.toHTML(false,"",db.lang.curr)+"</td><td></td></tr>";
    result+="<tr><td colspan=4 align=center><input type=submit value=\""+db.lang.addinv+"\"></td></tr>";
    result+="</form>";
    result+="<form action=/admin/viewgroup.html method=post>";
    result+="<input type=hidden name=group value="+id+">";
    result+="<tr><td colspan=4 align=center><input type=submit value=\""+db.lang.backtypes+"\"></td></tr>";
    result+="</form>";
    result+="</table>";
    return result;
  }

  Bedrag getTotalValue(Type type)
  {
    int result = 0;
    for (int i = 0; i < size(); i++)
    {
      Item item = (Item) get(i);
      if (item.type==type)
        result+=item.inprice.bedrag;
    }
    return new Bedrag(result);
  }

  String lowInventoryWarning(GroupList groups,Database db)
  {
    ArrayList types = new ArrayList();
    for (int i = 0; i < groups.size(); i ++)
    {
      TypeList tl = (TypeList) groups.get(i);
      for (int j = 0; j < tl.size(); j++)
      {
        Type t = (Type) tl.get(j);
        if (itemsAvailable(t)<t.minimum)
          types.add(t);
      }
    }
    if (types.size()==0)
      return "";
    String result = new String();
    result+="<hr>";
    result+="<table width=100% border=10><tr><td colspan=2 align=center><b>"+db.lang.lowinv+"</b></td></tr><tr><td width=50% align=center><b>"+db.lang.type+"</b></td><td width=50% align=center><b>"+db.lang.invnumber+"</b></td></tr>";
    for (int i = 0; i < types.size(); i++)
    {
      Type t = (Type) types.get(i);
      result+="<tr><td align=center>"+t.name+"</td><td align=center>"+itemsAvailable(t)+"</td></tr>";
    }
    result+="</table>";
    return result;
  }

  ArrayList getItems(Type type)
  {
    ArrayList result = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      Item item = (Item) get(i);
      if (item.type==type)
        result.add(item);
    }
    return result;
  }

  String removeInventory(Type type, InHistory inhistory,Database db)
  {
    ArrayList items = getItems(type);
    for (int i = 0; i < items.size(); i++)
    {
      Item item = (Item) items.get(i);
      if (contains(item)&inhistory.containsItem(item))
      {
        remove(item);
        inhistory.removeItem(item);
      }
    }
    return db.lang.invremoved;
  }

  void removeInventory(Type type)
  {
    ArrayList items = getItems(type);
    for (int i = 0; i < items.size(); i++)
    {
      Item item = (Item) items.get(i);
      remove(item);
    }
  }

}