import java.util.*;
import java.io.*;

class TypeList extends ArrayList implements Serializable
{
  String name;

  TypeList(String name)
  {
    this.name=name;
  }

	public boolean equals(Object object)
	{
		return this==object;
	}

  String addItem(String name,Database db)
  {
    String result = new String();
    for (int i = 0; i < size(); i++)
    {
      Type t = (Type) get(i);
      if (t.name.equalsIgnoreCase(name))
        return db.lang.typeexists;
    }
    add(new Type(name));
    result+=db.lang.typecreated;
    return result;
  }

  Type getType(String type)
  {
    int itype = new Integer(type).intValue();
    return (Type) get(itype);
  }

  String removeType(String type,Database db)
  {
    int itype = new Integer(type).intValue();
    remove(itype);
    return db.lang.typeremoved;
  }

  String toHTML(String destination, String origin, String id, Inventory inventory, Database db)
  {
    ArrayList sorted = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      Type a = (Type) get(i);
      boolean found=false;
      for (int j = 0; j < sorted.size(); j++)
      {
        Type b = (Type) sorted.get(j);
        if (a.name.compareToIgnoreCase(b.name)<0)
        {
          sorted.add(j,a);
          found=true;
          break;
        }
      }
      if (!found)
        sorted.add(a);
    }
    boolean left=true;
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=2 align=center><b>"+name+":</b></td></tr>";
    if (destination.startsWith("/admin/"))
    {
      result+="<tr>";
      result+="<form action=/admin/groupstats.html method=post>";
      result+="<td width=50% align=center>";
      result+="<input type=hidden name=group value="+id+">";
      result+=new NOBSDate().toHTML(true,"from")+" - "+new NOBSDate().toHTML(true,"to");
      result+="<br>";
      result+="<input type=submit value=\""+db.lang.stats+"\">";
      result+="</td>";
      result+="</form>";
      result+="<form action=/admin/inventory.html method=post>";
      result+="<td width=50% align=center>";
      result+="<input type=hidden name=group value="+id+">";
      result+="<input type=submit value=\""+db.lang.inventory+"\">";
      result+="</td>";
      result+="</form>";
      result+="</tr>";
    }
    if (sorted.size()>0)
    {
      result+="<tr>";
      for (int i=0;i<sorted.size();i++)
      {
        Type t = (Type) sorted.get(i);
        result+="<form action="+destination+" method=post>";
        result+="<td align=center>";
        result+="<input type=hidden name=group value="+id+">";
        result+="<input type=hidden name=type value="+indexOf(t)+">";
        if (destination.startsWith("/user/"))
          result+="<input type=text name=amount value=0 size="+new Integer(inventory.itemsAvailable(t)).toString().length()+">";
        result+="<input type=submit value=\""+t.name+"\">";
        result+="<br>"+t.outprice.toHTML(false,"",db.lang.curr)+" - "+inventory.itemsAvailable(t);
        result+="</td>";
        result+="</form>";
        if (!left)
          result+="</tr><tr>";
        left=!left;
      }
      result+="</tr>";
    }
    else
      if (destination.startsWith("/admin/"))
      {
        result+="<tr>";
        result+="<td colspan=2 align=center>";
        result+="<form action=/admin/removegroup.html method=post>";
        result+="<input type=hidden name=group value="+id+">";
        result+="<input type=submit value=\""+db.lang.remgroup+"\">";
        result+="</td>";
        result+="</form>";
        result+="</tr>";
      }
    if (destination.startsWith("/admin/"))
    {
      result+="<tr>";
      result+="<form action=/admin/addtype.html method=post>";
      result+="<td colspan=2 align=center>";
      result+="<input type=hidden name=group value="+id+">";
      result+="<input type=text name=name value=\""+db.lang.newtype+"\">";
      result+="<input type=submit value=\""+db.lang.addtype+"\">";
      result+="</td>";
      result+="</form>";
      result+="</tr>";
    }
    result+="<tr>";
    result+="<form action="+origin+" method=post>";
    result+="<td colspan=2 align=center>";
    result+="<input type=submit value=\""+db.lang.backgroups+"\">";
    result+="</td>";
    result+="</form>";
    result+="</tr>";
    result+="</table>";
    return result;
  }

}