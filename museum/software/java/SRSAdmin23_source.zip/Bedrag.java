import java.io.*;

class Bedrag implements Serializable
{

  int bedrag;

  Bedrag(int bedrag)
  {
    this.bedrag=bedrag;
  }

  Bedrag(String euro, String cent)
  {
    fromHTML(euro,cent);
  }

  String toHTML(boolean editable, String prefix, String curr)
  {
    String bedrag = new Integer(this.bedrag).toString();
    for (int i = bedrag.length(); i < 3; i++)
      bedrag="0"+bedrag;
    String result = new String();
    result+=curr+" ";
    if (editable)
      result+="<input type=text name="+prefix+"euro value=";
    result+=bedrag.substring(0,bedrag.length()-2);
    if (editable)
      result+=" size="+(bedrag.length()-2)+">";
    result+=",";
    if (editable)
      result+="<input type=text name="+prefix+"cent value=";
    result+=bedrag.substring(bedrag.length()-2,bedrag.length());
    if (editable)
      result+=" size=1>";
    return result;
  }

  void fromHTML(String euro, String cent)
  {
    for (int i = 0; i < 2-cent.length(); i++)
      cent="0"+cent;
    if (cent.length()>2)
      cent=cent.substring(0,2);
    bedrag = new Integer(euro+cent).intValue();
  }

}