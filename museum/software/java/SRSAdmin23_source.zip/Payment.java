import java.util.*;
import java.io.*;

class Payment implements Serializable
{

  NOBSDate date;
  Bedrag bedrag;

  Payment(Bedrag bedrag)
  {
    date = new NOBSDate();
    this.bedrag = bedrag;
  }

}