import java.util.*;
import java.io.*;

class GroupList extends ArrayList implements Serializable
{

  String addGroup(String name, Database db)
  {
    String result = new String();
    for (int i = 0; i < size(); i++)
    {
      TypeList tl = (TypeList) get(i);
      if (tl.name.equalsIgnoreCase(name))
        return db.lang.groupexists;
    }
    add(new TypeList(name));
    result+=db.lang.groupcreated;
    return result;
  }

  TypeList getGroup(String group)
  {
    int igroup = new Integer(group).intValue();
    return (TypeList) get(igroup);
  }

  String removeGroup(String id,Database db)
  {
    remove(new Integer(id).intValue());
    return db.lang.groupremoved;
  }

	int myIndexOf(Object po)
	{
		for (int i = 0; i < size(); i++)
		{
			Object o = get(i);
			if (o==po)
				return i;
		}
		return -1;
	}

  String toHTML(String destination,Database db)
  {
    ArrayList sorted = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      TypeList a = (TypeList) get(i);
      boolean found=false;
      for (int j = 0; j < sorted.size(); j++)
      {
        TypeList b = (TypeList) sorted.get(j);
        if (a.name.compareToIgnoreCase(b.name)<0)
        {
          sorted.add(j,a);
          found=true;
          break;
        }
      }
      if (!found)
        sorted.add(a);
    }
    boolean left=true;
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=2 align=center><b>"+db.lang.groups+":</b></td></tr>";
    result+="<tr>";
    for (int i=0;i<sorted.size();i++)
    {
      TypeList tl = (TypeList) sorted.get(i);
      result+="<form action="+destination+" method=post>";
      result+="<td align=center width=50%>";
      result+="<input type=hidden name=group value="+indexOf(tl)+">";
      result+="<input type=submit value=\""+tl.name+"\">";
      result+="</td>";
      result+="</form>";
      if (!left)
        result+="</tr><tr>";
      left=!left;
    }
    result+="</tr>";
    if (destination.startsWith("/admin/"))
    {
      result+="<tr>";
      result+="<form action=/admin/addgroup.html method=post>";
      result+="<td colspan=2 align=center>";
      result+="<input type=text name=name value=\""+db.lang.newgroup+"\">";
      result+="<input type=submit value=\""+db.lang.addgroup+"\">";
      result+="</td>";
      result+="</form>";
      result+="</tr>";
    }
    result+="</table>";
    return result;
  }

}