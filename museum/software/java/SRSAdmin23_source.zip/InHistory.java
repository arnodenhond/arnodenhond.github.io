import java.util.*;
import java.io.*;

class InHistory extends ArrayList implements Serializable
{

  String addPurchase(String euro, String cent, String name, ArrayList purchases,Database db)
  {
    Type type = new Type(name);
    purchases.add(type);
    Item item = new Item(type);
    item.inprice=new Bedrag(euro,cent);
    Purchase purchase = new Purchase();
    purchase.items.add(item);
    add(purchase);
    return db.lang.purchadded;
  }

  void cleardb(NOBSDate from,NOBSDate to)
  {
    ArrayList removable = new ArrayList();
    for (int i=0;i<size();i++)
    {
      Purchase purchase = (Purchase) get(i);
      if (purchase.date.after(to) | purchase.date.before(from))
        continue;
      removable.add(purchase);
    }
    for (int i=0;i<removable.size();i++)
      remove(removable.get(i));
  }

  String groupStats(TypeList group, NOBSDate from, NOBSDate to,Database db)
  {
    ArrayList types=new ArrayList();
    ArrayList bought=new ArrayList();
    ArrayList spent=new ArrayList();
    Bedrag totalspent = new Bedrag(0);
    for (int i = 0; i < group.size(); i++)
    {
      Type type = (Type) group.get(i);
      for (int j = 0; j < size(); j++)
      {
        Purchase purchase = (Purchase) get(j);
        if (purchase.date.before(from) | purchase.date.after(to))
          continue;
        for (int k = 0; k < purchase.items.size(); k++)
        {
          Item item = (Item) purchase.items.get(k);
          if (item.type==type)
          {
            if (types.contains(item.type))
            {
              int index = types.indexOf(item.type);
              Integer ibought = (Integer) bought.get(index);
              Integer ispent = (Integer) spent.get(index);
              bought.set(index,new Integer(ibought.intValue()+1));
              spent.set(index,new Integer(ispent.intValue()+item.inprice.bedrag));
            }
            else
            {
              types.add(item.type);
              bought.add(new Integer(1));
              spent.add(new Integer(item.inprice.bedrag));
            }
            totalspent.bedrag+=item.inprice.bedrag;
          }
        }
      }
    }
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=3 align=center><b>"+db.lang.purchstats+" "+db.lang.sfor+" "+group.name+"<b></td></tr>";
    result+="<tr><td width=33% align=center><b>"+db.lang.type+"</b></td><td width=33% align=center><b>"+db.lang.bought+"</b></td><td width=33% align=center><b>"+db.lang.spent+"</b></td></tr>";
    for (int i = 0; i < types.size(); i++)
    {
      Type type = (Type) types.get(i);
      Integer ibought = (Integer) bought.get(i);
      Integer ispent = (Integer) spent.get(i);
      result+="<tr><td align=center>"+type.name+"</td><td align=center>"+ibought.toString()+"</td><td align=center>"+new Bedrag(ispent.intValue()).toHTML(false,"",db.lang.curr)+"</td></tr>";
    }
    result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.spent+"</b></td><td align=center><b>"+totalspent.toHTML(false,"",db.lang.curr)+"</b></td></tr>";
    result+="</table>";
    return result;
  }

  ArrayList getItems(TypeList group, NOBSDate from, NOBSDate to)
  {
    ArrayList result = new ArrayList();
    for (int i = 0; i < group.size(); i++)
    {
      Type type = (Type) group.get(i);
      for (int j = 0; j < size(); j++)
      {
        Purchase purchase = (Purchase) get(j);
        if (purchase.date.before(from) | purchase.date.after(to))
          continue;
        for (int k = 0; k < purchase.items.size(); k++)
        {
          Item item = (Item) purchase.items.get(k);
          if (item.type==type)
            result.add(item);
        }
      }
    }
    return result;
  }

  Bedrag getTotalInPrice(ArrayList items)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < items.size(); i++)
    {
      Item item = (Item) items.get(i);
      result.bedrag+=item.inprice.bedrag;
    }
    return result;
  }

  String statistics(GroupList groups, ArrayList purchases, FlexPhoneList flexPhone,SeparateSales separateSales, NOBSDate from, NOBSDate to, Database db)
  {
    Bedrag totalspent = new Bedrag(0);
    String result=new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=3 align=center><b>"+db.lang.purchstats+"</b></td></tr>";
    result+="<tr><td width=33% align=center><b>"+db.lang.group+"</b></td><td width=33% align=center><b>"+db.lang.bought+"</b></td><td width=33% align=center><b>"+db.lang.spent+"</b></td></tr>";
    for (int i = 0; i < groups.size(); i++)
    {
      TypeList group = (TypeList) groups.get(i);
      ArrayList items = getItems(group,from,to);
      totalspent.bedrag+=getTotalInPrice(items).bedrag;
      result+="<tr>";
      result+="<form action=/admin/groupstats.html method=post>";
      result+="<input type=hidden name=group value="+groups.indexOf(group)+">";
      result+=from.toHiddenElements("from");
      result+=to.toHiddenElements("to");
      result+="<td align=center><input type=submit value=\""+group.name+"\"></td>";
      result+="</form>";
      result+="<td align=center>"+items.size()+"</td><td align=center>"+getTotalInPrice(items).toHTML(false,"",db.lang.curr)+"</td></tr>";
    }
    result+="<form action=/admin/flexphonestats.html method=post>";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<tr><td align=center><input type=submit value=\""+db.lang.flexphone+"\"></td><td align=center>"+flexPhone.getNumber(from,to)+"</td><td align=center>"+flexPhone.getSpent(from,to).toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="</form>";
    totalspent.bedrag+=flexPhone.getSpent(from,to).bedrag;

    result+="<form action=/admin/separatesalesstats.html method=post>";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<tr><td align=center><input type=submit value=\""+db.lang.ssale+"\"></td><td align=center>"+separateSales.getNumber(from,to)+"</td><td align=center>"+separateSales.getSpent(from,to).toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="</form>";
    totalspent.bedrag+=separateSales.getSpent(from,to).bedrag;

    if (purchases.size()>0)
      result+="<tr><td colspan=3><hr></td></tr>";
    for (int i = 0; i < purchases.size(); i++)
    {
      Type type = (Type) purchases.get(i);
      Item item = getItem(type,from,to);
      if (item==null)
        continue;
      result+="<tr><td align=center>"+type.name+"</td><td></td><td align=center>"+item.inprice.toHTML(false,"",db.lang.curr)+"</td></tr>";
      totalspent.bedrag+=item.inprice.bedrag;
    }
    result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.spent+"</b></td><td align=center>"+totalspent.toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="</table>";
    return result;
  }

  Item getItem(Type type, NOBSDate from, NOBSDate to)
  {
    for (int i = 0; i < size(); i++)
    {
      Purchase purchase = (Purchase) get(i);
      if (purchase.date.before(from) | purchase.date.after(to))
        continue;
      for (int j = 0; j < purchase.items.size(); j++)
      {
        Item item = (Item) purchase.items.get(j);
        if (item.type==type)
          return item;
      }
    }
    return null;
  }

  boolean containsItem(Item item)
  {
    for (int i = 0; i < size(); i++)
    {
      Purchase purchase = (Purchase) get(i);
      if (purchase.items.contains(item))
        return true;
    }
    return false;
  }

  void removeItem(Item item)
  {
    for (int i = 0; i < size(); i++)
    {
      Purchase purchase = (Purchase) get(i);
      if (purchase.items.remove(item))
        break;
    }
  }

}
