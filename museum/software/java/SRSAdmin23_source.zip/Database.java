import java.io.*;
import java.util.*;

class Database implements Serializable
{

  OutHistory outhistory;  //all sales and sold items
  InHistory inhistory;    //all prurchases and items (sold or in inventory)
  Inventory inventory;    //all sellable items in inventory
  GroupList groups;       //all groups and types
  ArrayList loginhistory; //contains Date objects representing login times
  ArrayList loginnames;   //contains Verkoper objects corresponding to times
  ArrayList verkopers;    //all verkoper accounts
  Verkoper verkoper;    //the currently logged on verkoper
  
  ArrayList purchases;    //losse inkopen
  SeparateSales separateSales;        //losse verkopen
  int saleid;
  Basket basket;       //temporary shopping basket
  Bedrag cash;
  Bedrag plastic;
  String userpw;
  Date userlogin;
  String adminpw;
  Date adminlogin;
  FlexPhoneList flexPhoneList;
  Language lang;
  
  Database()
  {
    lang = new Language();
    separateSales = new SeparateSales();
    flexPhoneList = new FlexPhoneList();
    saleid=0;
    purchases=new ArrayList();
    cash=new Bedrag(0);
    plastic=new Bedrag(0);
    userpw = "user";
    userlogin = new Date(0);
    adminpw = "ramzi";
    adminlogin = new Date(0);
    loginhistory = new ArrayList();
    basket=new Basket();
    outhistory = new OutHistory();
    inhistory = new InHistory();
    inventory = new Inventory();
    loginhistory = new ArrayList();
    loginnames = new ArrayList();
    verkopers = new ArrayList();
    groups = new GroupList();
  }

}
