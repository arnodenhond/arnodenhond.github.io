import java.io.*;

class SaveDatabase extends Thread {
    
    Database d;
    
    SaveDatabase(Database d) {
        this.d = d;
    }
    
    public void run() {
        try {
            File oldest = new File("SRSAdmin2Backup.10");
            oldest.delete();
            for (int i = 0; i < 10; i++) {
                File orig = new File("SRS"+(9-i)+"Backup.db");
                File dest = new File("SRS"+(10-i)+"Backup.db");
                orig.renameTo(dest);
            }
            File current = new File("SRSAdmin2.db");
            File backup = new File("SRS0Backup.db");
            current.renameTo(backup);
        }
        catch (Exception e) {
            System.out.println("Error while making backup!");
            System.out.println(e.toString());
        }
        try {
            FileOutputStream fos = new FileOutputStream("SRSAdmin2.db");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(d);
            oos.flush();
            fos.close();
        }
        catch (Exception e) {
            System.out.println("Error while saving database!");
            System.out.println(e.toString());
        }
    }
    
}
