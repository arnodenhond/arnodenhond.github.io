import java.io.*;
import java.util.*;

class Verkoper implements Serializable
{
    
    String name;
    //ArrayList sales;
    
    Verkoper(String name) {
        this.name = name;
        //sales = new ArrayList();
    }
    
}
