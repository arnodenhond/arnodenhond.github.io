import java.io.*;

class Item implements Serializable
{

  Type type;
  Bedrag inprice;
  Bedrag outprice;

  Item(Type type)
  {
    this.type = type;
    inprice = type.inprice;
//    outprice = new Bedrag(0);
  }

}
