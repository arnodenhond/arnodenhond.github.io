import java.util.*;
import java.io.*;

class Screens {
    
    String logo() {
        try {
            String result = new String();
            InputStreamReader isr = new InputStreamReader(new FileInputStream("logo.txt"));
            while (isr.ready()){
                result+=(char)isr.read();
            }
            return result;
        }
        catch (Exception e)
        {}
        return "<h1>THIS PROGRAM IS UNREGISTERED!<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></h1>";
        // respect "<font size=10>S.R.S @ COM</font><br> NET<hr>";
    }
    
    String makeVerkoperSelect(ArrayList verkopers, Verkoper v,Database db) {
        String result = new String();
        result+="<select name=verkoper>";
        result+="<option value=999";
        if (v==null)
            result+=" selected";
        result+=">"+db.lang.allaccounts+"</option>";
        for (int i = 0; i < verkopers.size(); i++) {
            Verkoper tv = (Verkoper) verkopers.get(i);
            result+="<option value="+i;
            if (tv==v)
                result+=" selected";
            result+=">"+tv.name+"</option>";
        }
        result+="</select>";
        return result;
    }
    
    String address() {
        try {
            String result = new String();
            InputStreamReader isr = new InputStreamReader(new FileInputStream("adres.txt"));
            while (isr.ready()){
                result+=(char)isr.read();
            }
            return result;
        }
        catch (Exception e)
        {}
        return "<h1>THIS PROGRAM IS UNREGISTERED!<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></h1>";
        
        // respect "Overtoom 70<br>1054 HL Amsterdam<br>Tel: 020-6898160<br>Fax: 020-6187161<hr>";
    }
    
    String flexPhone(Database db) {
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=3 align=center><b>"+db.lang.flexphone+"</b></td></tr>";
        result+="<tr><td align=center width=33%><b>"+db.lang.spent+"</b></td><td align=center width=33%><b>"+db.lang.earned+"</b></td></tr>";
        result+="<form action=/user/addflexphone.html method=post>";
        result+="<tr><td align=center>"+new Bedrag(0).toHTML(true,"in",db.lang.curr)+"</td><td align=center>"+new Bedrag(0).toHTML(true,"out",db.lang.curr)+"</td><td align=center><input type=submit value=\""+db.lang.save+"\"></td></tr>";
        result+="</form>";
        result+="</table>";
        return result;
    }
    
    String addSale(Database db) {
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=4 align=center><b>"+db.lang.ssale+"</b></td></tr>";
        result+="<tr><td align=center width=33%><b>"+db.lang.spent+"</b></td><td align=center width=33%><b>"+db.lang.earned+"</b></td><td align=center width=33%><b>"+db.lang.description+"</b></td></tr>";
        result+="<form action=/user/addsale.html method=post>";
        result+="<tr><td align=center>"+new Bedrag(0).toHTML(true,"in",db.lang.curr)+"</td><td align=center>"+new Bedrag(0).toHTML(true,"out",db.lang.curr)+"</td><td align=center><input type=text name=description></td><td align=center><input type=submit value=\""+db.lang.save+"></td></tr>";
        result+="</form>";
        result+="</table>";
        return result;
    }
    
    String header(boolean admin,Database db) {
        String result = new String();
        result+="<html><center>";
        result+=logo();
        result+="<font face=verdana>";
        result+="<table width=100% border=10>";
        result+="<tr>";
        result+="<td align=center width=50%>";
        
        result+="<table width=100%><tr>";
        result+="<form action=/admin/setcash.html method=post>";
        result+="<td align=left>";
        result+="<b>"+db.lang.cash+": "+db.cash.toHTML(admin,"",db.lang.curr)+"</b>";
        if (admin)
            result+="<input type=submit value=\""+db.lang.set+"\">";
        result+="</td>";
        result+="</form>";
        result+="<form action=/admin/setplastic.html method=post>";
        result+="<td align=right>";
        result+="<b>"+db.lang.plastic+": "+db.plastic.toHTML(admin,"",db.lang.curr)+"</b>";
        if (admin)
            result+="<input type=submit value=\""+db.lang.set+"\">";
        result+="</td>";
        result+="</form>";
        result+="</tr></table>";
        
        result+="</td>";
        //    if (admin)
        //    {
        result+="<form action=/ method=post><td align=center width=50%>";
        result+="<table width=100%><tr><td align=left>";
        if (!admin)
            result+=db.verkoper.name;
        result+="</td><td align=right>";
        result+="<input type=submit value=\""+db.lang.logoff+"\">";
        result+="</td></tr></table>";
/*    }
    else
    {
      result+="<form action=/user/credit.html method=post><td align=center width=50%>";
      result+="<input type=submit value=credit>";
    }*/
        result+="</td></form></tr>";
        result+="</table>";
        result+="<hr>";
        if (!admin)
            result+=db.basket.showBasket(db);
        return result;
    }
    
    String footer() {
        String result = new String();
        result+="<hr>SRS Admin 2.3 � <a href=http://nobsoft.com/><font color=black>noBSoft</font></a> 2004";
        result+="</font></center></html>";
        return result;
    }
    
    
    String chooseLogin(Database db) {
        String result=new String();
        result+="<html><center>";
        result+=logo();
        result+="<font face=verdana>";
        result+="<h1>"+db.lang.login+"</h1>";
        result+="<table width=100%>";
        result+="<tr>";
        result+="<td align=center>";
        result+="<form action=/userlogin.html method=post>";
        result+="<input type=text name=password>";
        result+="<br>";
        result+="<input type=submit value=\""+db.lang.user+"\">";
        result+="</form>";
        result+="</td>";
        result+="<td align=center>";
        result+="<form action=/adminlogin.html method=post>";
        result+="<input type=password name=password>";
        result+="<br>";
        result+="<input type=submit value=\""+db.lang.admin+"\">";
        result+="</form>";
        result+="</td>";
        result+="</tr>";
        result+="</table>";
        result+="</font>";
        result+="</center></html>";
        return result;
    }
    
    String loginHistory(ArrayList loginhistory, ArrayList loginnames,Database db) {
        String result=new String();
        result+="<table width=100% border=10>";
        result+="<tr><td align=center colspan=2><b>"+db.lang.loginhist+"</b></td></tr>";
        for (int i = loginhistory.size(); i>loginhistory.size()-25; i--) {
            if (i==0)
                break;
            NOBSDate date = (NOBSDate) loginhistory.get(i-1);
            Verkoper v = (Verkoper) loginnames.get(i-1);
            result+="<tr><td align=center>"+date.toHTML(false,"")+"</td><td align=center>"+v.name+"</td></tr>";
        }
        result+="<form action=/admin/main.html method=post>";
        result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.backmain+"\"></td></tr>";
        result+="</form>";
        result+="</table>";
        return result;
    }
    
    String passwordsMenu(Database db) {
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td align=center colspan=2><b>"+db.lang.users+"</b></td></tr>";
        if (db.verkopers.size()==0)
            result+="<tr><td colspan=2 align=center>"+db.lang.none+"</td></tr>";
        for (int i = 0; i < db.verkopers.size(); i++) {
            Verkoper v = (Verkoper) db.verkopers.get(i);
            result+="<form action=/admin/deluser.html method=post>";
            result+="<input type=hidden name=userid value="+i+">";
            result+="<tr><td align=center>"+v.name+"</td><td align=center><input type=submit value="+db.lang.delete+"></td></tr>";
            result+="</form>";
        }
        result+="<form action=/admin/main.html method=post>";
        result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.backmain+"\"></td></tr>";
        result+="</form>";

        result+="<form action=/admin/adduser.html method=post>";
        result+="<tr><td colspan=2 align=center><b>"+db.lang.adduser+"</b></td></tr>";
        result+="<tr><td align=center>"+db.lang.username+":</td><td align=center><input type=text name=username value=\""+db.lang.newuser+"\"></td></tr>";
        result+="<tr><td align=center colspan=2><input type=submit value=\""+db.lang.adduser+"\"></td></tr>";
        result+="</form>";
        
        
        result+="<tr><td colspan=2 align=center><b>"+db.lang.adminpw+"</b></td></tr>";
        result+="<form action=/admin/setpasswords.html method=post>";
        //    result+="<tr><td width=50% align=center>user password:</td><td width=50% align=center><input type=password name=userpassword value=\""+userpassword+"\"></td></tr>";
        result+="<tr><td width=50% align=center>"+db.lang.adminpw+":</td><td width=50% align=center><input type=password name=adminpassword value=\""+db.adminpw+"\"></td></tr>";
        result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.savepw+"\"></td></tr>";
        result+="</form>";
        
        result+="</table>";
        return result;
    }
    
    String adminMenu(Database db) {
        String result = new String();
        result+="<hr>";
        result+="<table width=100% border=10>";
        
        result+="<tr>";
        result+="<form action=/admin/statistics.html method=post>";
        result+="<td align=center width=50%>";
        result+=new NOBSDate().toHTML(true,"from")+" - "+new NOBSDate().toHTML(true,"to");
        result+="<br>";
        result+="<input type=hidden name=verkoper value=999>";
        result+="<input type=submit value=\""+db.lang.stats+"\"></td>";
        result+="</form>";
        result+="<form action=/admin/cleardb.html method=post>";
        result+="<td align=center width=50%>";
        result+=new NOBSDate().toHTML(true,"from")+" - "+new NOBSDate().toHTML(true,"to");
        result+="<br>";
        result+="<input type=submit value=\""+db.lang.cleardb+"\"></td>";
        result+="</form>";
        result+="</tr>";
        
        result+="<tr>";
        result+="<form action=/admin/loginhistory.html method=post>";
        result+="<td align=center width=50%><input type=submit value=\""+db.lang.loginhist+"\"></td>";
        result+="</form>";
        result+="<form action=/admin/viewpasswords.html method=post>";
        result+="<td align=center width=50%><input type=submit value=\""+db.lang.passwords+"\"></td>";
        result+="</form>";
        result+="</tr>";
        
        result+="<tr>";
        result+="<form action=/admin/undosale.html method=post>";
        result+="<td align=center width=50%><input type=text name=sale size=3><input type=submit value=\""+db.lang.undosale+"\"></td>";
        result+="</form>";
        result+="<form action=/admin/addpurchase.html method=post>";
        result+="<td align=center width=50%>"+new Bedrag(0).toHTML(true,"",db.lang.curr)+"<input type=text name=comment><input type=submit value=\""+db.lang.purchase+"\"></td>";
        result+="</form>";
        result+="</tr>";
        
        result+="<form action=/admin/shutdown.html method=post>";
        result+="<tr><td colspan=2 align=center><input type=submit value=\""+db.lang.shutdown+"\"></td></tr>";
        result+="</form>";
        
        result+="</table>";
        return result;
    }
    
}