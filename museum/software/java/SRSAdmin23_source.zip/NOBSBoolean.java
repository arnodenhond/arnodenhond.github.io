import java.io.*;

class NOBSBoolean implements Serializable
{
  boolean bool;
  NOBSBoolean(boolean b)
  {
    bool=b;
  }
}

