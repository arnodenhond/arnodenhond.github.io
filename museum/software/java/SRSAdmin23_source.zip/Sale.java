import java.util.*;
import java.io.*;

class Sale implements Serializable
{

  ArrayList items;
  PayHistory payed;
  NOBSDate date;
  int saleid;
  Bedrag price;
  Bedrag discount;
  String comment;
  Verkoper verkoper;
  boolean plastic;

  Sale()
  {}

  Sale(Basket basket, int saleid, Verkoper v)
  {
    items = new ArrayList();
    while (basket.size()>0)
    {
      Item item = (Item) basket.get(0);
      basket.remove(0);
      item.outprice=item.type.outprice;
      items.add(item);
    }
    this.saleid=saleid;
    payed = new PayHistory();
    if (basket.paid)
      payed.add(new Payment(basket.totalprice));
    plastic=basket.plastic;
    date = new NOBSDate();
    price=basket.totalprice;
    discount=basket.discount;
    comment=basket.comment;
    verkoper=v;
    //verkoper.sales.add(this);
  }

  String toRow(String groupid, String typeid, NOBSDate from, NOBSDate to, int vid,Database db)
  {
    String result = new String();
    result+="<form action=/admin/viewsale.html method=post>";
    result+="<input type=hidden name=sale value="+saleid+">";
    result+="<input type=hidden name=group value="+groupid+">";
    result+="<input type=hidden name=type value="+typeid+">";
    result+="<input type=hidden name=verkoper value="+vid+">";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<tr><td align=center>";
    result+="<input type=submit value=\"";
    result+=date.toHTML(false,"");
    result+="\">";
    result+="</td><td align=center>";
    result+=price.toHTML(false,"",db.lang.curr);
    result+="</td><td align=center>";
    result+=saleid;
    result+="</td></tr>";
    result+="</form>";
    return result;
  }

  String toHTML(String groupid, String typeid, NOBSDate from, NOBSDate to, int vid, Database db)
  {
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td width=50% align=center>"+db.lang.date+"</td><td width=50% align=center>"+date.toHTML(false,"")+"</td></tr>";
    result+="<tr><td width=50% align=center>"+db.lang.number+"</td><td width=50% align=center>"+saleid+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.price+"</td><td align=center>"+price.toHTML(false,"",db.lang.curr)+"</td></tr>";
    if (discount.bedrag!=0)
      result+="<tr><td align=center>"+db.lang.discount+"</td><td align=center>"+discount.toHTML(false,"",db.lang.curr)+"</td></tr>";
    if (payed.totalPaid().bedrag!=price.bedrag)
      result+="<tr><td align=center>payed</td><td align=center>"+payed.totalPaid().toHTML(false,"",db.lang.curr)+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.comment+"</td><td align=center>"+comment+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.soldby+"</td><td align=center>"+verkoper.name+"</td></tr>";
    result+="<tr><td align=center>"+db.lang.payment+"</td><td align=center>"+(plastic?db.lang.plastic:db.lang.cash)+"</td></tr>";
    result+="<tr><td align=center colspan=2>"+db.lang.items+"</td></tr>";
    for (int i = 0; i < items.size(); i++)
    {
      Item item = (Item) items.get(i);
      result+="<tr><td align=center>"+item.type.name+"</td><td align=center>"+item.outprice.toHTML(false,"",db.lang.curr)+"</td></tr>";
    }
    result+="<form action=/admin/typestats.html method=post>";
    result+="<input type=hidden name=group value="+groupid+">";
    result+="<input type=hidden name=type value="+typeid+">";
    result+="<input type=hidden name=verkoper value="+vid+">";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<tr><td align=center colspan=2><input type=submit value=\""+db.lang.backtypestats+"\"></td></tr>";
    result+="</form>";
    result+="</table>";
    return result;
  }
}