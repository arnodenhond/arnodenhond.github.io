import java.util.*;
import java.io.*;

class SeparateSales extends ArrayList implements Serializable
{

  String addSale(Bedrag in, Bedrag out, String description, Verkoper v, Database db)
  {
    Sale s = new Sale();
    s.comment=description;
    s.date= new NOBSDate();
    s.discount=new Bedrag(0);
    s.items = new ArrayList();
    s.verkoper = v;
    Type type = new Type(description);
    Item item = new Item(type);
    item.inprice=in;
    item.outprice=out;
    s.items.add(item);
    s.payed = new PayHistory();
    s.payed.add(new Payment(out));
    s.saleid = 0;
    add(s);
    return db.lang.sssaved;
  }

  Bedrag getEarned(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      if (fp.date.after(from) & fp.date.before(to))
      {
        Item item = (Item) fp.items.get(0);
        result.bedrag+=item.outprice.bedrag;
      }
    }
    return result;
  }

  Bedrag getProfit(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      if (fp.date.after(from) & fp.date.before(to))
      {
        Item item = (Item) fp.items.get(0);
        result.bedrag+=(item.outprice.bedrag-item.inprice.bedrag);
      }
    }
    return result;
  }

  Bedrag getSpent(NOBSDate from, NOBSDate to)
  {
    Bedrag result = new Bedrag(0);
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      if (fp.date.after(from) & fp.date.before(to))
      {
        Item item = (Item) fp.items.get(0);
        result.bedrag+=item.inprice.bedrag;
      }
    }
    return result;
  }


  int getNumber(NOBSDate from, NOBSDate to)
  {
    int result=0;
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        result++;
    }
    return result;
  }

  String stats(NOBSDate from, NOBSDate to, Database db)
  {
    String result = new String();
    result+="<table width=100% border=10>";
    result+="<tr><td colspan=5 align=center><b>"+db.lang.ssale+" "+db.lang.stats+" "+db.lang.from+" "+from.toHTML(false,"")+" "+db.lang.to+" "+to.toHTML(false,"")+"</b></td></tr>";
    result+="<tr><td width=20% align=center><b>"+db.lang.spent+"</b></td><td width=20% align=center><b>"+db.lang.earned+"</b></td><td width=20% align=center><b>"+db.lang.comment+"</b></td><td width=20% align=center><b>"+db.lang.date+"</b></td><td width=20% align=center><b>"+db.lang.soldby+"</b></td></tr>";
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      Item item = (Item) fp.items.get(0);
      result+="<tr><td align=center>"+item.inprice.toHTML(false,"",db.lang.curr)+"</td><td align=center>"+item.outprice.toHTML(false,"",db.lang.curr)+"</td><td align=center>"+fp.comment+"</td><td align=center>"+fp.date.toHTML(false,"")+"</td><td align=center>"+fp.verkoper.name+"</td></tr>";
    }
    result+="</table>";
    result+="<form action=/admin/statistics.html method=post>";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<input type=submit value=\""+db.lang.backstats+"\">";
    result+="</form>";
    return result;
  }

  void cleardb(NOBSDate from, NOBSDate to)
  {
    ArrayList removeable = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      Sale fp = (Sale) get(i);
      if (fp.date.after(from) & fp.date.before(to))
        removeable.add(fp);
    }
    for (int i = 0; i < removeable.size(); i++)
      remove(removeable.get(i));
  }

}