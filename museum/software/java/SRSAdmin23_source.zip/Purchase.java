import java.util.*;
import java.io.*;

class Purchase implements Serializable
{

  NOBSDate date;
  ArrayList items;

  Purchase()
  {
    date = new NOBSDate();
    items = new ArrayList();
  }

}
