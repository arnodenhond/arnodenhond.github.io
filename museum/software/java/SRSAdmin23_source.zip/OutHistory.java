import java.util.*;
import java.io.*;

class OutHistory extends ArrayList implements Serializable {
    
    
    String creditStats(NOBSDate from, NOBSDate to, Database db) {
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=3 align=center><b>payment statistics from "+from.toHTML(false,"")+" to "+to.toHTML(false,"")+"</b></td></tr>";
        result+="<tr><td align=center width=33%><b>sale</b></td><td align=center width=33%><b>date</b></td><td align=center width=33%><b>amount</b></td></tr>";
        for (int i = 0; i < size(); i++) {
            Sale s = (Sale) get(i);
            if (s.payed.totalPaid().bedrag<s.price.bedrag) {
                for (int j = 0; j < s.payed.size(); j++) {
                    Payment p = (Payment) s.payed.get(j);
                    if (p.date.after(from) & p.date.before(to))
                        result+="<tr><td align=center>"+s.comment+"</td><td align=center>"+p.date.toHTML(false,"")+"</td><td align=center>"+p.bedrag.toHTML(false,"",db.lang.curr)+"</td></tr>";
                }
            }
        }
        result+="</table>";
        result+="<form action=/admin/statistics.html method=post>";
        result+=from.toHiddenElements("from");
        result+=to.toHiddenElements("to");
        result+="<input type=submit value=\"back to statistics\">";
        result+="</form>";
        return result;
    }
    
    Bedrag incomingCredit(NOBSDate from, NOBSDate to) {
        Bedrag result = new Bedrag(0);
        for (int i = 0; i < size(); i++) {
            Sale s = (Sale) get(i);
            if (s.payed.totalPaid().bedrag<s.price.bedrag) {
                for (int j = 0; j < s.payed.size(); j++) {
                    Payment p = (Payment) s.payed.get(j);
                    if (p.date.after(from) & p.date.before(to))
                        result.bedrag+=p.bedrag.bedrag;
                }
            }
        }
        return result;
    }
    
    ArrayList getSales(Type type, NOBSDate from, NOBSDate to, Verkoper v) {
        ArrayList result = new ArrayList();
        for (int i = 0; i < size(); i++) {
            Sale sale = (Sale) get(i);
            if (sale.date.after(to) | sale.date.before(from))
                continue;
            if (v!=null && sale.verkoper!=v)
                continue;
            for (int j = 0; j < sale.items.size(); j++) {
                Item item = (Item) sale.items.get(j);
                if (item.type==type)
                    result.add(sale);
            }
        }
        return result;
    }
    
    String typeStats(Type type, NOBSDate from, NOBSDate to, String typeid, String groupid, Verkoper v, int vid, Database db) {
        ArrayList sales = getSales(type,from,to,v);
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=3 align=center><b>"+db.lang.salestatsfor+" "+type.name+" "+db.lang.sfor+" ";
        if (v!=null)
            result+=v.name;
        else
            result+=db.lang.allaccounts;
        result+="<b></td></tr>";
        result+="<tr><td width=33% align=center><b>"+db.lang.date+"</b></td><td width=33% align=center><b>"+db.lang.price+"</b></td><td width=33% align=center><b>"+db.lang.number+"</b></td></tr>";
        for (int i = 0; i < sales.size(); i++) {
            Sale sale = (Sale) sales.get(i);
            result+=sale.toRow(groupid, typeid,from,to,vid,db);
        }
        result+="</table>";
        return result;
    }
    
    String groupStats(TypeList group, NOBSDate from, NOBSDate to,String groupid, Verkoper v, int vid, Database db) {
        ArrayList types=new ArrayList();
        ArrayList sold=new ArrayList();
        ArrayList earned=new ArrayList();
        Bedrag totalearned = new Bedrag(0);
        Bedrag totalprofit = new Bedrag(0);
        for (int i = 0; i < group.size(); i++) {
            Type type = (Type) group.get(i);
            for (int j = 0; j < size(); j++) {
                Sale sale = (Sale) get(j);
                //        if (sale.payed.totalPaid().bedrag<sale.price.bedrag)
                //          continue;
                if (sale.date.before(from) | sale.date.after(to))
                    continue;
                if (v!=null && sale.verkoper!=v)
                    continue;
                for (int k = 0; k < sale.items.size(); k++) {
                    Item item = (Item) sale.items.get(k);
                    if (item.type==type) {
                        if (types.contains(item.type)) {
                            int index = types.indexOf(item.type);
                            Integer isold = (Integer) sold.get(index);
                            Integer iearned = (Integer) earned.get(index);
                            sold.set(index,new Integer(isold.intValue()+1));
                            earned.set(index,new Integer(iearned.intValue()+item.outprice.bedrag));
                        }
                        else {
                            types.add(item.type);
                            sold.add(new Integer(1));
                            earned.add(new Integer(item.outprice.bedrag));
                        }
                        totalearned.bedrag+=item.outprice.bedrag;
                        totalprofit.bedrag+=(item.outprice.bedrag-item.inprice.bedrag);
                    }
                }
            }
        }
        
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=3 align=center><b>"+db.lang.salestatsfor+" "+group.name+" "+db.lang.sfor+" ";
        if (v!=null)
            result+=v.name;
        else
            result+=db.lang.allaccounts;
        result+="<b></td></tr>";
        result+="<tr><td width=33% align=center><b>"+db.lang.type+"</b></td><td width=33% align=center><b>"+db.lang.sold+"</b></td><td width=33% align=center><b>"+db.lang.earned+"</b></td></tr>";
        for (int i = 0; i < types.size(); i++) {
            Type type = (Type) types.get(i);
            Integer isold = (Integer) sold.get(i);
            Integer iearned = (Integer) earned.get(i);
            result+="<form action=/admin/typestats.html method=post>";
            result+="<input type=hidden name=group value="+groupid+">";
            result+="<input type=hidden name=type value="+group.indexOf(type)+">";
            result+=from.toHiddenElements("from");
            result+=to.toHiddenElements("to");
            result+="<input type=hidden name=verkoper value="+vid+">";
            result+="<tr><td align=center><input type=submit value=\""+type.name+"\"></td><td align=center>"+isold.toString()+"</td><td align=center>"+new Bedrag(iearned.intValue()).toHTML(false,"",db.lang.curr)+"</td></tr>";
            result+="</form>";
        }
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.earned+"</b></td><td align=center><b>"+totalearned.toHTML(false,"",db.lang.curr)+"</b></td></tr>";
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.profit+"</b></td><td align=center><b>"+totalprofit.toHTML(false,"",db.lang.curr)+"</b></td></tr>";
        result+="</table>";
        return result;
    }
    
    ArrayList getItems(TypeList group, NOBSDate from, NOBSDate to, Verkoper v) {
        ArrayList result = new ArrayList();
        for (int i = 0; i < group.size(); i++) {
            Type type = (Type) group.get(i);
            for (int j = 0; j < size(); j++) {
                Sale sale = (Sale) get(j);
                //        if (sale.payed.totalPaid().bedrag<sale.price.bedrag)
                //          continue;
                if (sale.date.before(from) | sale.date.after(to))
                    continue;
                if (v!=null & sale.verkoper!=v)
                    continue;
                for (int k = 0; k < sale.items.size(); k++) {
                    Item item = (Item) sale.items.get(k);
                    if (item.type==type)
                        result.add(item);
                }
            }
        }
        return result;
    }
    
    Bedrag getTotalOutPrice(ArrayList items) {
        Bedrag result = new Bedrag(0);
        for (int i = 0; i < items.size(); i++) {
            Item item = (Item) items.get(i);
            result.bedrag+=item.outprice.bedrag;
        }
        return result;
    }
    
    Bedrag getTotalProfit(ArrayList items) {
        Bedrag result = new Bedrag(0);
        for (int i = 0; i < items.size(); i++) {
            Item item = (Item) items.get(i);
            result.bedrag+=(item.outprice.bedrag-item.inprice.bedrag);
        }
        return result;
    }
    
    Bedrag getTotalDiscount(NOBSDate from, NOBSDate to) {
        Bedrag result = new Bedrag(0);
        for (int i = 0; i < size(); i++) {
            Sale sale = (Sale) get(i);
            //      if (sale.payed.totalPaid().bedrag<sale.price.bedrag)
            //        continue;
            if (sale.date.before(from) | sale.date.after(to))
                continue;
            result.bedrag+=sale.discount.bedrag;
        }
        return result;
    }
    
    Bedrag getTotalCredit() {
        Bedrag result = new Bedrag(0);
        for (int i = 0; i < size(); i++) {
            Sale sale = (Sale) get(i);
            if (sale.payed.totalPaid().bedrag<sale.price.bedrag)
                result.bedrag+=(sale.price.bedrag-sale.payed.totalPaid().bedrag);
        }
        return result;
    }
    
    String statistics(GroupList groups,FlexPhoneList flexPhone,SeparateSales separateSales, NOBSDate from, NOBSDate to, Verkoper v, int vid, Database db) {
        Bedrag totalearning = new Bedrag(0);
        Bedrag totalprofit = new Bedrag(0);
        String result=new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=3 align=center><b>"+db.lang.salestatsfor+" "+(v==null?db.lang.allaccounts:v.name)+"</b></td></tr>";
        result+="<tr><td width=33% align=center><b>"+db.lang.group+"</b></td><td width=33% align=center><b>"+db.lang.sold+"</b></td><td width=33% align=center><b>"+db.lang.earned+"</b></td></tr>";
        for (int i = 0; i < groups.size(); i++) {
            TypeList group = (TypeList) groups.get(i);
            ArrayList items = getItems(group,from,to,v);
            totalearning.bedrag+=getTotalOutPrice(items).bedrag;
            totalprofit.bedrag+=getTotalProfit(items).bedrag;
            result+="<tr>";
            result+="<form action=/admin/groupstats.html method=post>";
            result+="<input type=hidden name=group value="+groups.indexOf(group)+">";
            result+=from.toHiddenElements("from");
            result+=to.toHiddenElements("to");
            result+="<input type=hidden name=verkoper value="+vid+">";
            result+="<td align=center><input type=submit value=\""+group.name+"\"></td>";
            result+="</form>";
            result+="<td align=center>"+items.size()+"</td><td align=center>"+getTotalOutPrice(items).toHTML(false,"",db.lang.curr)+"</td></tr>";
        }
        //flexphone start
        result+="<form action=/admin/flexphonestats.html method=post>";
        result+=from.toHiddenElements("from");
        result+=to.toHiddenElements("to");
        result+="<tr><td align=center><input type=submit value=\""+db.lang.flexphone+"\"></td><td align=center>"+flexPhone.getNumber(from,to)+"</td><td align=center>"+flexPhone.getEarned(from,to).toHTML(false,"",db.lang.curr)+"</td></tr>";
        result+="</form>";
        totalearning.bedrag+=flexPhone.getEarned(from,to).bedrag;
        totalprofit.bedrag+=flexPhone.getProfit(from,to).bedrag;
        //flexphone end
        result+="<form action=/admin/separatesalesstats.html method=post>";
        result+=from.toHiddenElements("from");
        result+=to.toHiddenElements("to");
        result+="<tr><td align=center><input type=submit value=\""+db.lang.ssale+"\"></td><td align=center>"+separateSales.getNumber(from,to)+"</td><td align=center>"+separateSales.getEarned(from,to).toHTML(false,"",db.lang.curr)+"</td></tr>";
        result+="</form>";
        totalearning.bedrag+=separateSales.getEarned(from,to).bedrag;
        totalprofit.bedrag+=separateSales.getProfit(from,to).bedrag;
        
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.earned+"</b></td><td align=center>"+totalearning.toHTML(false,"",db.lang.curr)+"</td></tr>";
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.profit+"</b></td><td align=center>"+totalprofit.toHTML(false,"",db.lang.curr)+"</td></tr>";
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.discount+"</b></td><td align=center>"+getTotalDiscount(from,to).toHTML(false,"",db.lang.curr)+"</td></tr>";
/*    result+="<tr>";
    result+="<form action=/admin/creditstats.html method=post>";
    result+=from.toHiddenElements("from");
    result+=to.toHiddenElements("to");
    result+="<td align=center><input type=submit value=credit></td>";
    result+="</form>";
    result+="<td align=center>unpaid: "+getTotalCredit().toHTML(false,"")+"</td><td align=center>paid: "+incomingCredit(from,to).toHTML(false,"")+"</td></tr>";*/
        result+="<tr><td align=center><b>"+db.lang.total+" "+db.lang.turnover+":</b></td><td align=center>"+new Bedrag(totalearning.bedrag-getTotalDiscount(from,to).bedrag-getTotalCredit().bedrag).toHTML(false,"",db.lang.curr)+"</td></tr>";
        result+="</table>";
        return result;
    }
    
    void cleardb(NOBSDate from,NOBSDate to) {
        ArrayList removable = new ArrayList();
        for (int i=0;i<size();i++) {
            Sale sale = (Sale) get(i);
            if (sale.date.after(to) | sale.date.before(from))
                continue;
            if (sale.payed.totalPaid().bedrag==sale.price.bedrag)
                removable.add(sale);
        }
        for (int i=0;i<removable.size();i++)
            remove(removable.get(i));
    }
    
    Sale getSale(int saleid) {
        for (int i = 0; i < size(); i++) {
            Sale sale = (Sale) get(i);
            if (sale.saleid==saleid)
                return sale;
        }
        return null;
    }
    
    String undo(String id,Inventory inventory,Bedrag cash,Database db) {
        int sid=new Integer(id).intValue();
        Sale sale = getSale(sid);
        if (sale==null)
            return db.lang.noreceipt;
        cash.bedrag-=sale.payed.totalPaid().bedrag;
        for (int i=0;i<sale.items.size();i++) {
            Item item = (Item) sale.items.get(i);
            inventory.add(item);
        }
        remove(sale);
        return db.lang.saleundone;
    }
    
    String showCredit(Database db) {
        ArrayList unpaidsales = new ArrayList();
        int remaining = 0;
        for (int i = 0; i < size(); i++) {
            Sale sale = (Sale) get(i);
            if (sale.price.bedrag>sale.payed.totalPaid().bedrag) {
                unpaidsales.add(sale);
                remaining+=sale.price.bedrag-sale.payed.totalPaid().bedrag;
            }
        }
        String result = new String();
        result+="<table width=100% border=10>";
        result+="<tr><td colspan=4 align=center><b>credit:</b></td></tr>";
        result+="<tr><td colspan=2 align=center width=50%>total remaining:</td><td colspan=2 align=center width=50%>"+new Bedrag(remaining).toHTML(false,"",db.lang.curr)+"</td></tr>";
        if (unpaidsales.size()>0)
            result+="<tr><td width=25% align=center><b>comment</b></td><td width=25% align=center><b>date</b></td><td width=25% align=center><b>total price</b></td><td width=25% align=center><b>remaining</b></td></tr>";
        for (int i = 0; i < unpaidsales.size(); i++) {
            Sale sale = (Sale) unpaidsales.get(i);
            if (sale.price.bedrag>sale.payed.totalPaid().bedrag) {
                result+="<form action=/user/viewcredit.html method=post>";
                result+="<input type=hidden name=sale value="+indexOf(sale)+">";
                result+="<tr><td align=center><input type=submit value=\""+sale.comment+"\"</td><td align=center>"+sale.date.toHTML(false,"")+"</td><td align=center>"+sale.price.toHTML(false,"",db.lang.curr)+"</td><td align=center>"+new Bedrag(sale.price.bedrag-sale.payed.totalPaid().bedrag).toHTML(false,"",db.lang.curr)+"</td></tr>";
                result+="</form>";
            }
        }
        result+="<form action=/user/main.html method=post>";
        result+="<tr><td colspan=4 align=center><input type=submit value=\"back to main\"></td></tr>";
        result+="</form>";
        result+="</table>";
        return result;
    }
    
    Sale getSale(String id) {
        return (Sale) get(new Integer(id).intValue());
    }
    
    PayHistory getPayHistory(String id) {
        int isale = new Integer(id).intValue();
        Sale sale = (Sale) get(isale);
        return sale.payed;
    }
    
}