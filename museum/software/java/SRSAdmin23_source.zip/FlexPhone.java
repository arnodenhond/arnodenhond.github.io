import java.io.*;

class FlexPhone implements Serializable
{
  NOBSDate date;
  Bedrag in;  //het lage bedrag
  Bedrag out; //het hoge bedrag

  FlexPhone(Bedrag in, Bedrag out)
  {
    date = new NOBSDate();
    this.in=in;
    this.out=out;
  }
  
}