import java.io.*;
/**
 * The list containing Data objects
 * @author noBSoft
 * @version 1.0
 */
public class DataList implements Serializable
{

/**
  * the actual list of data objects
  */
  public Data[] array;

  public DataList()
  {
    array = new Data[0];
  }

/**
 * adds a new data object to the end of the list
 * @param d the new data object to be added
 */
  public void add(Data d)
  {
    Data[] newarray = new Data[array.length+1];
    System.arraycopy(array,0,newarray,0,array.length);
    newarray[array.length] = d;
    array = newarray;
  }
/**
 * inserts a new data object at index-1'th position in the list
 * @param d the new data object to be inserted
 * @param index the position to insert the new data object, is index is larger than length or array it is decreased to add new data object to end of array
 */
  public void insert(Data d, int index)
  {
    if (index > array.length)
      index = array.length;
    Data[] newarray = new Data[array.length+1];
    System.arraycopy(array,0,newarray,0,index);
    newarray[index] = d;
    System.arraycopy(array,index,newarray,index+1,array.length-index);
    array = newarray;
  }

/**
 * removes a data object from the list
 * @param d the data object to be removed
 */
  public void remove(Data d)
  {
    int index = indexOf(d);
    if (index == -1)
      return;
    Data[] newarray = new Data[array.length-1];
    System.arraycopy(array,0,newarray,0,index);
    System.arraycopy(array,index+1,newarray,index,array.length-index-1);
    array = newarray;
  }

/**
 * gets the index of a data object
 * @param d the data object of which to retreive the index
 * @return the index of the data object
 */
  public int indexOf(Data d)
  {
    for (int i = 0; i < array.length; i++)
      if (array[i] == d)
        return i;
    return -1;
  }

}