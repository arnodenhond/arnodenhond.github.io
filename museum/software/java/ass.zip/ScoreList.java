/**
 * Just a little thingie to keep scores
 * <BR>
 * nothing interesting
 * @author noBSoft
 * @version 1.0
 */
class ScoreList
{

  float[] array;

  ScoreList()
  {
    array = new float[0];
  }

  void addScore(float score)
  {
    float[] newarray = new float[array.length+1];
    System.arraycopy(array,0,newarray,0,array.length);
    newarray[array.length] = score;
    array = newarray;
  }

  void insert(float score, int index)
  {
    if (index > array.length)
      index = array.length;
    float[] newarray = new float[array.length+1];
    System.arraycopy(array,0,newarray,0,index);
    newarray[index] = score;
    System.arraycopy(array,index,newarray,index+1,array.length-index);
    array = newarray;
  }

}