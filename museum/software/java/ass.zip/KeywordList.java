import java.io.*;
/**
 * The list containing Keyword objects
 * @author noBSoft
 * @version 1.0
 */
public class KeywordList implements Serializable
{

/**
  * the actual list of keyword objects
  */
  public Keyword[] array;

  public KeywordList()
  {
    array = new Keyword[0];
  }

/**
 * adds a new keyword object to the end of the list
 * @param k the new keyword object to be added
 */
  public void add(Keyword k)
  {
    Keyword[] newarray = new Keyword[array.length+1];
    System.arraycopy(array,0,newarray,0,array.length);
    newarray[array.length] = k;
    array = newarray;
  }

/**
 * inserts a new keyword object at index-1'th position in the list
 * @param k the new keyword object to be inserted
 * @param index the position to insert the new keyword object, is index is larger than length or array it is decreased to add new keyword object to end of array
 */
  public void insert(Keyword k, int index)
  {
    if (index > array.length)
      index = array.length;
    Keyword[] newarray = new Keyword[array.length+1];
    System.arraycopy(array,0,newarray,0,index);
    newarray[index] = k;
    System.arraycopy(array,index,newarray,index+1,array.length-index);
    array = newarray;
  }

/**
 * removes a keyword object from the list
 * @param k the keyword object to be removed
 */
  public void remove(Keyword k)
  {
    int index = indexOf(k);
    if (index == -1)
      return;
    Keyword[] newarray = new Keyword[array.length-1];
    System.arraycopy(array,0,newarray,0,index);
    System.arraycopy(array,index+1,newarray,index,array.length-index-1);
    array = newarray;
  }

/**
 * gets the index of a keyword object
 * @param k the keyword object of which to retreive the index
 * @return the index of the keyword object
 */
  public int indexOf(Keyword k)
  {
    for (int i = 0; i < array.length; i++)
      if (array[i] == k)
        return i;
    return -1;
  }

}
