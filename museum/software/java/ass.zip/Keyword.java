import java.io.*;
/**
 * The keyword object
 * <BR>
 * this is what describes data
 * @author noBSoft
 * @version 1.0
 */
public class Keyword implements Serializable
{
/**
 * the name of the keyword
 */
  public String keyword;
/**
 * the datas which this keyword describes
 */
  public DataList datas;

/**
 *Creates a new Keyword object
 * @param keyword the name of the keyword
 */
  public Keyword(String keyword)
  {
    this.keyword = keyword;
    datas = new DataList();
  }

}
