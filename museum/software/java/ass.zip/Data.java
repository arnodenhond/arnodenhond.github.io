import java.io.*;
/**
 * The data object
 * <BR>
 * this contains the actual information and is described by a keyword
 * @author noBSoft
 * @version 1.0
 */
public class Data implements Serializable
{

/**
 * the data
 */
  public String data;
/**
 * the keywords describing this data
 */
  public KeywordList keywords;

/**
 *Creates a new Data object
 * @param data the data
 * @param keywords the keywords
 */
  public Data(String data, KeywordList keywords)
  {
    this.data = data;
    this.keywords = keywords;
  }

}
