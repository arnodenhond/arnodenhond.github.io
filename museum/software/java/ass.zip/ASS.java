import java.io.*;
/**
 * Associative Suggestion Search
 * @author noBSoft
 * @version 1.0
 */
public class ASS
{

/**
 * all the keywords in the database
 */
  public KeywordList keywords;
/**
 * all the datas in the database
 */
  public DataList datas;
  String filename;

/**
 * Load the database or create new if necessary
 * @param filename the name of the database-file on disk
 * @exception Exception if unable to connect to database
 */
  public ASS(String filename) throws Exception
  {
    this.filename=filename;
    File f = new File(filename);
    if (f.exists())
    {
      FileInputStream fis = new FileInputStream(f);
      ObjectInputStream ois = new ObjectInputStream(fis);
      keywords = (KeywordList) ois.readObject();
      datas = (DataList) ois.readObject();
      fis.close();
    }
    else
    {
      keywords = new KeywordList();
      datas = new DataList();
      savedb();
    }
  }

/**
 * Save the database to disk
 * @exception Exception if unable to connect to database
 */
  void savedb() throws Exception
  {
    File f = new File(filename);
    FileOutputStream fos = new FileOutputStream(f);
    ObjectOutputStream oos = new ObjectOutputStream(fos);
    oos.writeObject(keywords);
    oos.writeObject(datas);
    oos.flush();
    fos.close();
  }

/**
 * Add a new keyword to database
 * @param keyword the name of the new keyword
 * @return the new keyword
 * @exception Exception if unable to save database
 */
  public Keyword addKeyword(String keyword) throws Exception
  {
    Keyword result = new Keyword(keyword);
    keywords.add(result);
    savedb();
    return result;
  }

/**
 * Add a new data to database
 * @param data the content of the new data
 * @param keywords keywords linked to the new data
 * @return the new data
 * @exception Exception if unable to save database
 */
  public Data addData(String data, KeywordList keywords) throws Exception
  {
    Data result = new Data(data,keywords);
    for (int i = 0; i < keywords.array.length; i++)
      keywords.array[i].datas.add(result);
    datas.add(result);
    savedb();
    return result;
  }

/**
 * Remove a keyword from database
 * @param keyword the keyword to be removed
 * @exception Exception if unable to save database
 * @return succesfull
 */
  public boolean delKeyword(Keyword keyword) throws Exception
  {
    if (keywords.array[keywords.indexOf(keyword)] == null)
      return false;
    keywords.array[keywords.indexOf(keyword)] = null;
    for (int i = 0; i < keyword.datas.array.length; i++)
      keyword.datas.array[i].keywords.remove(keyword);
    savedb();
    return true;
  }

/**
 * Remove a data from database
 * @param data the data to be removed
 * @exception Exception if unable to save database
 * @return succesfull
 */
  public boolean delData(Data data) throws Exception
  {
    if (datas.array[datas.indexOf(data)] == null)
      return false;
    datas.array[datas.indexOf(data)] = null;
    for (int i = 0; i < data.keywords.array.length; i++)
      data.keywords.array[i].datas.remove(data);
    savedb();
      return true;
  }

/**
 * List keywords, sorted by alphabet or popularity
 * @param alpha if true, sort alphabetically else sort by popularity
 * @return an array of keywords
 */
  public KeywordList listKeywords(boolean alpha)
  {
    KeywordList result = new KeywordList();
    if (alpha)
      for (int i = 0; i < keywords.array.length; i++)
      {
        if (keywords.array[i] == null)
          continue;
        boolean found=false;
        for (int j = 0; j < result.array.length; j++)
          if (result.array[j].keyword.compareTo(keywords.array[i].keyword)>0)
          {
            result.insert(keywords.array[i],j);
            found=true;
            break;
          }
        if (!found)
          result.add(keywords.array[i]);
      }
    else
      for (int i = 0; i < keywords.array.length; i++)
      {
        if (keywords.array[i] == null)
          continue;
        boolean found=false;
        for (int j = 0; j < result.array.length; j++)
          if (result.array[j].datas.array.length<keywords.array[i].datas.array.length)
          {
            result.insert(keywords.array[i],j);
            found=true;
            break;
          }
        if (!found)
          result.add(keywords.array[i]);
      }
    return result;
  }

/**
 * List keywords associated to keywords
 * @param keywords the search query
 * @param average score calculation method (read documentation)
 * @return an array of keywords
 */
  public KeywordList listKeywordResults(KeywordList keywords, boolean average)
  {
    if (keywords.array.length == 0)
      return listKeywords(average);
    DataList datalist = new DataList();
    ScoreList datascores = new ScoreList();
    for (int i = 0; i < keywords.array.length; i++)
      for (int j = 0; j < keywords.array[i].datas.array.length; j++)
      {
        int index = datalist.indexOf(keywords.array[i].datas.array[j]);
        if (index ==-1)
        {
          datalist.add(keywords.array[i].datas.array[j]);
          datascores.addScore(1);
        }
        else
          datascores.array[index]++;
      }
    KeywordList keywordlist = new KeywordList();
    ScoreList keywordhits = new ScoreList();
    ScoreList keywordscores = new ScoreList();
    for (int i = 0; i < datalist.array.length; i++)
      for (int j = 0; j < datalist.array[i].keywords.array.length; j++)
      {
        if (keywords.indexOf(datalist.array[i].keywords.array[j])!=-1)
          continue;
        int index = keywordlist.indexOf(datalist.array[i].keywords.array[j]);
        if (index == -1)
        {
          keywordlist.add(datalist.array[i].keywords.array[j]);
          keywordhits.addScore(1);
          keywordscores.addScore(datascores.array[i]);
        }
        else
        {
          keywordhits.array[index]++;
          keywordscores.array[index]+=datascores.array[i];
        }
      }
    if (average)
      for (int i = 0; i < keywordlist.array.length; i++)
        keywordscores.array[i]/=keywordhits.array[i];
    KeywordList result = new KeywordList();
    ScoreList sortedscores = new ScoreList();
    for (int i = 0; i < keywordscores.array.length; i++)
    {
      boolean found=false;
      for (int j = 0; j < sortedscores.array.length; j++)
        if (sortedscores.array[j]<keywordscores.array[i])
        {
          sortedscores.insert(keywordscores.array[i],j);
          result.insert(keywordlist.array[i],j);
          found=true;
          break;
        }
      if (!found)
      {
        sortedscores.addScore(keywordscores.array[i]);
        result.add(keywordlist.array[i]);
      }
    }
    return result;
  }

/**
 * List datas associated to keywords
 * @param keywords the search query
 * @return an arrayto datas
 */
  public DataList listDataResults(KeywordList keywords)
  {
    if (keywords.array.length==0)
    {
      DataList result = new DataList();
      for (int i = datas.array.length-1; i >= 0; i--)
        if (datas.array[i]!=null)
          result.add(datas.array[i]);
      return result;
    }
    DataList datalist = new DataList();
    ScoreList scores = new ScoreList();
    for (int i = 0; i < keywords.array.length; i++)
      for (int j = 0; j < keywords.array[i].datas.array.length; j++)
      {
        int index = datalist.indexOf(keywords.array[i].datas.array[j]);
        if (index ==-1)
        {
          datalist.add(keywords.array[i].datas.array[j]);
          scores.addScore(1);
        }
        else
          scores.array[index]++;
      }
    DataList result = new DataList();
    ScoreList sortedscores = new ScoreList();
    for (int i = 0; i < scores.array.length; i++)
    {
      boolean found=false;
      for (int j = 0; j < sortedscores.array.length; j++)
        if (sortedscores.array[j]<scores.array[i])
        {
          sortedscores.insert(scores.array[i],j);
          result.insert(datalist.array[i],j);
          found=true;
          break;
        }
      if (!found)
      {
        sortedscores.addScore(scores.array[i]);
        result.add(datalist.array[i]);
      }
    }
    return result;
  }

/**
 * search for a keyword
 * @param keyword the search query
 * @return an array of keywords containing the search query
 */
  public KeywordList searchKeyword(String keyword)
  {
    KeywordList result = new KeywordList();
    for (int i = 0; i < keywords.array.length; i++)
      if (keywords.array[i] != null && keywords.array[i].keyword.indexOf(keyword)!=-1)
        result.add(keywords.array[i]);
    return result;
  }

}
