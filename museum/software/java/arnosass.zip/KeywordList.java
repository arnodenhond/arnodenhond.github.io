import javax.swing.*;
import java.awt.*;

public class KeywordList extends JPanel
{

  ZQLClient zql = null;
  int[] keywords = new int[0];
  JList list;
  JPanel panel = new JPanel();
  JScrollPane scrollPane = new JScrollPane(panel);

  public KeywordList(boolean selectable, ZQLClient zql, int[] keywords)
  {
    this.zql = zql;
    this.keywords = keywords;
    list = new JList(new KeywordListModel(keywords,zql));
    setEnabled(selectable);
    scrollPane.setPreferredSize(new Dimension(0,20));

    panel.setLayout(new GridLayout(1,1));
    panel.add(list);

    setLayout(new GridBagLayout());
    add(scrollPane,new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
  }

  public void setEnabled(boolean selectable)
  {
    list.setEnabled(selectable);
  }

  public void changeKeywords(int[] keywords)
  {
    list.setModel(new KeywordListModel(keywords,zql));
  }
}
