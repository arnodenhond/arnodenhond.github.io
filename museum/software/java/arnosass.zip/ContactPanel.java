import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class ContactPanel extends JPanel
{

  GridBagLayout gridBagLayout = new GridBagLayout();
  JLabel nameLabel = new JLabel("name:");
  JTextField nameTextField = new JTextField();
  JLabel emailLabel = new JLabel("e-mail:");
  JTextField emailTextField = new JTextField();
  JLabel addressLabel = new JLabel("address:");
  JTextField addressTextField = new JTextField();
  JLabel phoneLabel = new JLabel("phone:");
  JTextField phoneTextField = new JTextField();
  JLabel birthdayLabel = new JLabel("birthday:");
  JTextField birthdayTextField = new JTextField();
  JPanel malefemalePanel = new JPanel(new GridBagLayout());
  ButtonGroup malefemale = new ButtonGroup();
  JRadioButton male = new JRadioButton("male");
  JRadioButton female = new JRadioButton("female");

  public ContactPanel(boolean editable, String data)
  {
    nameTextField.setPreferredSize(new Dimension(50,(int) nameTextField.getPreferredSize().getHeight()));
    nameTextField.setHorizontalAlignment(JTextField.RIGHT);
    emailTextField.setPreferredSize(new Dimension(50,(int) emailTextField.getPreferredSize().getHeight()));
    emailTextField.setHorizontalAlignment(JTextField.RIGHT);
    addressTextField.setPreferredSize(new Dimension(50,(int) addressTextField.getPreferredSize().getHeight()));
    addressTextField.setHorizontalAlignment(JTextField.RIGHT);
    phoneTextField.setPreferredSize(new Dimension(50,(int) phoneTextField.getPreferredSize().getHeight()));
    phoneTextField.setHorizontalAlignment(JTextField.RIGHT);
    female.setHorizontalTextPosition(AbstractButton.LEFT);
    malefemale.add(male);
    malefemale.add(female);


    setEditable(editable);
    nameTextField.setText(data);
    emailTextField.setText("e-mail address");
    addressTextField.setText("address");
    phoneTextField.setText("+31-6-28736213");
    birthdayTextField.setText("31 aug 2002");
    male.setSelected(true);
    
    malefemalePanel.setBorder(BorderFactory.createEtchedBorder());
    malefemalePanel.add(male,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    malefemalePanel.add(female,new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.LINE_END,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

    setLayout(gridBagLayout);
    add(nameLabel,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(emailLabel,new GridBagConstraints(0,1,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(addressLabel,new GridBagConstraints(0,2,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(phoneLabel,new GridBagConstraints(0,3,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(birthdayLabel,new GridBagConstraints(0,4,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

    add(nameTextField,new GridBagConstraints(1,0,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    add(emailTextField,new GridBagConstraints(1,1,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    add(addressTextField,new GridBagConstraints(1,2,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    add(phoneTextField,new GridBagConstraints(1,3,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    add(birthdayTextField,new GridBagConstraints(1,4,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));

    add(malefemalePanel,new GridBagConstraints(0,5,2,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
  }

  void setEditable(boolean editable)
  {
    nameTextField.setEditable(editable);
    emailTextField.setEditable(editable);
    addressTextField.setEditable(editable);
    phoneTextField.setEditable(editable);
    birthdayTextField.setEditable(editable);
    male.setEnabled(editable);
    female.setEnabled(editable);
  }

}
