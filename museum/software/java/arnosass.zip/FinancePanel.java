import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.text.*;
import java.util.*;

public class FinancePanel extends JPanel
{

  GridBagLayout gridBagLayout = new GridBagLayout();
  GridBagLayout textFieldGridBagLayout = new GridBagLayout();
  JPanel textFieldPanel = new JPanel(textFieldGridBagLayout);
  JLabel amountLabel = new JLabel("amount:");
  JLabel dateLabel = new JLabel("date:");
  JLabel commentLabel = new JLabel("comment:");
  JTextField dateTextField = new JTextField();
  JTextField amountTextField = new JTextField();
  JTextField commentTextField = new JTextField();

  JPanel inoutPanel = new JPanel(new GridLayout(0,1));
  ButtonGroup inout = new ButtonGroup();
  JRadioButton in = new JRadioButton("incoming");
  JRadioButton out = new JRadioButton("outgoing");
  JPanel cashbankPanel = new JPanel(new GridLayout(0,1));
  ButtonGroup cashbank = new ButtonGroup();
  JRadioButton cash = new JRadioButton("cash");
  JRadioButton bank = new JRadioButton("bank");

  public FinancePanel(boolean editable, String data)
  {
    out.setHorizontalAlignment(SwingConstants.CENTER);
    in.setHorizontalAlignment(SwingConstants.CENTER);
    cash.setHorizontalAlignment(SwingConstants.CENTER);
    bank.setHorizontalAlignment(SwingConstants.CENTER);
    cash.setHorizontalTextPosition(AbstractButton.LEFT);
    bank.setHorizontalTextPosition(AbstractButton.LEFT);

    inout.add(out);
    inout.add(in);
    inoutPanel.setBorder(BorderFactory.createEtchedBorder());
    inoutPanel.add(out);
    inoutPanel.add(in);
    cashbank.add(cash);
    cashbank.add(bank);
    cashbankPanel.setBorder(BorderFactory.createEtchedBorder());
    cashbankPanel.add(cash);
    cashbankPanel.add(bank);
    commentTextField.setPreferredSize(new Dimension(50,(int) commentTextField.getPreferredSize().getHeight()));
    commentTextField.setText(data);
    commentTextField.setHorizontalAlignment(JTextField.RIGHT);

    textFieldPanel.add(amountLabel,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    textFieldPanel.add(dateLabel,new GridBagConstraints(0,1,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    textFieldPanel.add(commentLabel,new GridBagConstraints(0,2,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    textFieldPanel.add(amountTextField,new GridBagConstraints(1,0,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
    textFieldPanel.add(dateTextField,new GridBagConstraints(1,1,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
    textFieldPanel.add(commentTextField,new GridBagConstraints(1,2,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

    setEditable(editable);
    amountTextField.setText("1234.67");
    dateTextField.setText("31 aug 2002");
    commentTextField.setText(data);
    out.setSelected(true);
    cash.setSelected(true);

    setLayout(gridBagLayout);
    add(textFieldPanel, new GridBagConstraints(0,1,2,1,1.0,1.0,GridBagConstraints.NORTH,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(inoutPanel, new GridBagConstraints(0,2,1,1,1.0,1.0,GridBagConstraints.SOUTHWEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(cashbankPanel, new GridBagConstraints(1,2,1,1,1.0,1.0,GridBagConstraints.SOUTHEAST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
  }

  void setEditable(boolean editable)
  {
    out.setEnabled(editable);
    in.setEnabled(editable);
    cash.setEnabled(editable);
    bank.setEnabled(editable);
    amountTextField.setEditable(editable);
    dateTextField.setEditable(editable);
    commentTextField.setEditable(editable);
  }

}

