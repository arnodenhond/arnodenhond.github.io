import javax.swing.*;
import java.awt.*;

public class DataList extends JPanel
{

  ZQLClient zql = null;
  int[] datas = new int[0];
  JPanel contentPanel = new JPanel();
  JScrollPane scrollPane = new JScrollPane(contentPanel);

  public DataList(ZQLClient zql, int[] datas) throws Exception
  {
    this.zql = zql;
    this.datas = datas;

    contentPanel.setLayout(new GridBagLayout());
    setLayout(new GridBagLayout());
    add(scrollPane,new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    if (datas.length>0)
    for (int i = 0; i < 1; i++)
    {
      DiaryPanel dp = new DiaryPanel(false,zql.getData(datas[i]));

      JPanel panel = new JPanel(new GridBagLayout());
      contentPanel.add(panel,new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

      panel.setBorder(BorderFactory.createTitledBorder("Diary"));
      panel.add(dp,new GridBagConstraints(0,i,1,3,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      JPanel datakeywordslist = new JPanel(new GridBagLayout());
      datakeywordslist.add(new KeywordList(false,zql,zql.listDataKeywords(datas[i])),new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("edit"),new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(datakeywordslist,new GridBagConstraints(1,1,1,1,0.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("remove"),new GridBagConstraints(1,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    }
    if (datas.length>1)
    for (int i = 1; i < 2; i++)
    {
      FinancePanel fp = new FinancePanel(false,zql.getData(datas[i]));

      JPanel panel = new JPanel(new GridBagLayout());
      contentPanel.add(panel,new GridBagConstraints(0,i,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

      panel.setBorder(BorderFactory.createTitledBorder("Finance"));
      panel.add(fp,new GridBagConstraints(0,0,1,3,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      JPanel datakeywordslist = new JPanel(new GridBagLayout());
      datakeywordslist.add(new KeywordList(false,zql,zql.listDataKeywords(datas[i])),new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("edit"),new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(datakeywordslist,new GridBagConstraints(1,1,1,1,0.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("remove"),new GridBagConstraints(1,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    }
    if (datas.length>2)
    for (int i = 2; i < 3; i++)
    {
      ContactPanel cp = new ContactPanel(false,zql.getData(datas[i]));

      JPanel panel = new JPanel(new GridBagLayout());
      contentPanel.add(panel,new GridBagConstraints(0,i,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

      panel.setBorder(BorderFactory.createTitledBorder("Contact"));
      panel.add(cp,new GridBagConstraints(0,0,1,3,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      JPanel datakeywordslist = new JPanel(new GridBagLayout());
      datakeywordslist.add(new KeywordList(false,zql,zql.listDataKeywords(datas[i])),new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("edit"),new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(datakeywordslist,new GridBagConstraints(1,1,1,1,0.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("remove"),new GridBagConstraints(1,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    }
    if (datas.length>3)
    for (int i = 3; i < 4; i++)
    {
      DiaryPanel dp = new DiaryPanel(false,zql.getData(datas[i]));

      JPanel panel = new JPanel(new GridBagLayout());
      contentPanel.add(panel,new GridBagConstraints(0,i,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

      panel.setBorder(BorderFactory.createTitledBorder("Diary"));
      panel.add(dp,new GridBagConstraints(0,0,1,3,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      JPanel datakeywordslist = new JPanel(new GridBagLayout());
      datakeywordslist.add(new KeywordList(false,zql,zql.listDataKeywords(datas[i])),new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("edit"),new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(datakeywordslist,new GridBagConstraints(1,1,1,1,0.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
      panel.add(new JButton("remove"),new GridBagConstraints(1,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    }
  }

}