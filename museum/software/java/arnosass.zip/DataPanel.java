import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class DataPanel extends JPanel
{
  public DataPanel(ZQLClient zql, int[] datas) throws Exception
  {
    TitledBorder border = BorderFactory.createTitledBorder("Data");
    border.setTitleJustification(TitledBorder.CENTER);
    setBorder(border);
    setLayout(new GridBagLayout());
    add(new DataList(zql,datas),new GridBagConstraints(0,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

  }

}
