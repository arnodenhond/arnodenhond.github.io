import javax.swing.*;

class KeywordListModel extends AbstractListModel
{

  int[] keywords;
  ZQLClient zql;

  KeywordListModel(int[] keywords, ZQLClient zql)
  {
    this.keywords = keywords;
    this.zql = zql;
  }

  public Object getElementAt(int index)
  {
    String result ="null";
    try
    {
      result = zql.getKeyword(keywords[index]);
    }
    catch (Exception e)
    {
      System.out.println(e.toString());
      e.printStackTrace(System.out);
    }
    return result;
  }

  public int getSize()
  {
    return keywords.length;
  }

}
