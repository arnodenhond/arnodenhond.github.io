import javax.swing.*;
import javax.swing.border.*;

import java.awt.*;

public class SearchPanel extends JPanel
{
  public SearchPanel(ZQLClient zql, int[] keywords)
  {
    TitledBorder border = BorderFactory.createTitledBorder("Search Keys");
    border.setTitleJustification(TitledBorder.CENTER);
    setBorder(border);
    setLayout(new GridBagLayout());
    JButton other = new JButton("other");
    other.setToolTipText("Select a keyword which isn't listed in results");
    add(other,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
    add(new KeywordList(true,zql,keywords),new GridBagConstraints(0,1,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    JButton remove = new JButton("remove");
    remove.setToolTipText("Remove the selected keyword(s) from the search list");
    remove.setEnabled(false);
    add(remove,new GridBagConstraints(0,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
  }
}