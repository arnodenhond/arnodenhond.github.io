import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.awt.*;

public class ArnosAss extends JFrame implements ActionListener
{

  JMenuBar makeMenu()
  {
    JMenuBar menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    JMenu create = new JMenu("Create");
    JMenuItem creatediary = new JMenuItem("Diary");
    JMenuItem createfinance = new JMenuItem("Finance");
    JMenuItem createcontact = new JMenuItem("Contact");
    JMenuItem createkeyword = new JMenuItem("Keyword");
    create.add(creatediary);
    create.add(createfinance);
    create.add(createcontact);
    create.addSeparator();
    create.add(createkeyword);
    JMenu filter = new JMenu("Filter");
    JCheckBoxMenuItem filterdiary = new JCheckBoxMenuItem("Diary");
    JCheckBoxMenuItem filterfinance = new JCheckBoxMenuItem("Finance");
    JCheckBoxMenuItem filtercontact = new JCheckBoxMenuItem("Contact");
    filter.add(filterdiary);
    filter.add(filterfinance);
    filter.add(filtercontact);
    JMenu options = new JMenu("Options");
    JMenuItem birthdays = new JMenuItem("Birthdays");
    JMenuItem moneydata = new JMenuItem("Money data");
    JMenuItem sorteddiary = new JMenuItem("Sorted diary");
    options.add(sorteddiary);
    options.add(moneydata);
    options.add(birthdays);
    JMenu help = new JMenu("Help");
    JMenuItem contents = new JMenuItem("Contents");
    JMenuItem about = new JMenuItem("About");
    help.add(contents);
    help.add(about);
    menuBar.add(create);
    menuBar.add(filter);
    menuBar.add(options);
    menuBar.add(help);
    return menuBar;
  }

  ArnosAss() throws Exception
  {
    ZQLClient zql = new ZQLClient("localhost",3688,true);
    makeMenu();
    setTitle("ZQL-ASS Arno-DB Browser");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel panel = new JPanel(new GridBagLayout());
    panel.setPreferredSize(new Dimension(484,242));
    int[] inkeywords = new int[0];
    panel.add(new SearchPanel(zql,inkeywords),                              new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    panel.add(new DataPanel(zql,zql.listDatas(inkeywords,0)),               new GridBagConstraints(1,0,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    panel.add(new SuggestionPanel(zql,inkeywords),new GridBagConstraints(2,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    setContentPane(panel);
    pack();
    show();
  }

  public void actionPerformed(ActionEvent ae)
  {
  }

  public static void main(String[] args) throws Exception
  {
    new ArnosAss();
  }

}