import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

public class SuggestionPanel extends JPanel implements ListSelectionListener, ActionListener
{
  JPanel totalaveragePanel = new JPanel(new GridBagLayout());
  ButtonGroup totalaverage = new ButtonGroup();
  JRadioButton total = new JRadioButton("total");
  JRadioButton average = new JRadioButton("average");
  KeywordList kl;
  JButton add;
  ZQLClient zql;
  int[] inkeywords;

  public SuggestionPanel(ZQLClient zql, int[] inkeywords) throws Exception
  {
    this.inkeywords = inkeywords;
    int[] keywords = zql.listKeywords(inkeywords,false,0);
    this.zql=zql;
    total.setToolTipText("Total result mode");
    total.setHorizontalAlignment(SwingConstants.CENTER);
    total.addActionListener(this);
    average.setToolTipText("Average result mode");
    average.setHorizontalAlignment(SwingConstants.CENTER);
    average.addActionListener(this);
    average.setHorizontalTextPosition(AbstractButton.LEFT);
    totalaverage.add(total);
    totalaverage.add(average);
    totalaveragePanel.add(total,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    totalaveragePanel.add(average,new GridBagConstraints(1,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    totalaveragePanel.setBorder(BorderFactory.createEtchedBorder());
    TitledBorder border = BorderFactory.createTitledBorder("Suggestion Keywords");
    border.setTitleJustification(TitledBorder.CENTER);
    setBorder(border);
    setLayout(new GridBagLayout());
    total.setSelected(true);
    add(totalaveragePanel,new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    kl = new KeywordList(true,zql,keywords);
    kl.list.addListSelectionListener(this);
    add(kl,new GridBagConstraints(0,1,1,1,1.0,1.0,GridBagConstraints.CENTER,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));

    add = new JButton("add");
    add.setEnabled(false);
    add.setToolTipText("Move the selected keyword(s) to the search list");
    add(add,new GridBagConstraints(0,2,1,1,0.0,0.0,GridBagConstraints.CENTER,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
  }

  public void valueChanged(ListSelectionEvent e)
  {
    if (kl.list.getSelectedIndices().length>0)
    add.setEnabled(true);
  }

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      kl.changeKeywords(zql.listKeywords(inkeywords,(e.getActionCommand()=="average"),0));
      add.setEnabled(false);
    }
    catch (Exception e2)
    {
      System.out.println(e2.toString());
    }
  }

}
