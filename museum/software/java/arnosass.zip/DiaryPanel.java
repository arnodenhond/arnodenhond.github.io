import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class DiaryPanel extends JPanel
{

  GridBagLayout gridBagLayout = new GridBagLayout();
  GridBagLayout dateGridBagLayout = new GridBagLayout();
  JPanel datePanel = new JPanel(dateGridBagLayout);
  JLabel dateLabel = new JLabel("date:");
  JTextField dateTextField = new JTextField();
  JTextArea storyTextArea = new JTextArea();
  JScrollPane storyScrollPane = new JScrollPane(storyTextArea);

  public DiaryPanel(boolean editable,String data)
  {
    setEditable(editable);
    dateTextField.setText("31 aug 2002");
    storyTextArea.setText(data);

    storyTextArea.setLineWrap(true);
    storyTextArea.setWrapStyleWord(true);
    storyScrollPane.setPreferredSize(new Dimension(0,100));
    datePanel.add(dateLabel, new GridBagConstraints(0,0,1,1,0.0,0.0,GridBagConstraints.WEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    datePanel.add(dateTextField, new GridBagConstraints(1,0,1,1,1.0,1.0,GridBagConstraints.EAST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));

    setLayout(gridBagLayout);
    add(datePanel,new GridBagConstraints(0,0,1,1,0.0,1.0,GridBagConstraints.NORTH,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
    add(storyScrollPane, new GridBagConstraints(0,1,1,1,1.0,1.0,GridBagConstraints.SOUTH,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
  }

  void setEditable(boolean editable)
  {
    dateTextField.setEditable(editable);
    storyTextArea.setEditable(editable);
  }

}
