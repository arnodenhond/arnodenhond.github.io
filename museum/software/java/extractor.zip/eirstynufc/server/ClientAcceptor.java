package eirstynufc.server;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import eirstynufc.db.RealDB;

/**
 * the serverframe, containing the log
 * 
 * @author Arno den Hond
 *  
 */
public class ClientAcceptor extends JFrame {

    private JTextArea logTextArea;

    private RealDB source;

    private int portnumber;

    /**
     * loads the portnumber setting then sets up the frame and its log (but not the serversocket)
     * 
     * @param source
     *            the database to pass to clienthandlers
     */
    public ClientAcceptor(RealDB source) {
        super("CSRtool server");
        this.source = source;
        PortConfig portConfig = new PortConfig();
        Properties props = new Properties();
        try {
            FileInputStream fis = new FileInputStream("suncertify.properties");
            props.load(fis);
            fis.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(this, ioe.toString(), "Could not load properties, using default server port number", JOptionPane.ERROR_MESSAGE);
        }
        this.portnumber = Integer.parseInt(props.getProperty("portnumber", "3688"));
        ;

        this.logTextArea = new JTextArea();
        this.logTextArea.setEditable(false);
        getContentPane().add(new JScrollPane(this.logTextArea));
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     * opens the serversocket or shows a dialog then exits the program if unable. if the serversocket is openend, it continuously waits for connections and starts a clienthandler thread for each accepted connection
     * 
     * @see suncertify.server.ClientHandler
     */
    public void accept() {
        ServerSocket ss = null;
        try {
            ss = new ServerSocket(this.portnumber);
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(this, ioe.toString(), "Could not open server socket on port " + this.portnumber, JOptionPane.ERROR_MESSAGE);
            System.out.println("Could not open server socket on port " + this.portnumber + ": " + ioe.toString());
            System.exit(88);
        }
        this.logTextArea.append("Server waiting for clients..");
        while (true) {
            try {
                Socket s = ss.accept();
                this.logTextArea.insert("Client connected from " + s.getInetAddress().toString() + "\n", 0);
                new ClientHandler(s, this.source, this.logTextArea).start();
            } catch (IOException ioe) {
                this.logTextArea.insert(ioe.toString() + "\n", 0);
            }
        }
    }

}