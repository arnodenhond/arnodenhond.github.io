package eirstynufc.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.RecordNotFoundException;
import eirstynufc.networking.LockRequest;
import eirstynufc.networking.Request;
import eirstynufc.networking.UnlockRequest;

/**
 * receives requests from remotedata and executes them. returns the results to the client.
 * 
 * @see suncertify.db.RemoteData
 * @see suncertify.networking.Request
 * @see suncertify.db.Data
 * @author Arno den Hond
 *  
 */
public class ClientHandler extends Thread {

    private JTextArea logTextArea;

    private ObjectInputStream ois;

    private ObjectOutputStream oos;

    private RealDB source;

    /**
     * initializes the thread and opens the streams.
     * 
     * @param s
     *            the socket connected to the client
     * @param source
     *            the database holding the data the client wants to see
     * @param logTextArea
     *            the log to show all requests on
     * @throws IOException
     *             if the streams couldnt be openend
     */
    public ClientHandler(Socket s, RealDB source, JTextArea logTextArea) throws IOException {
        setName(s.getInetAddress().toString());
        this.oos = new ObjectOutputStream(s.getOutputStream());
        this.ois = new ObjectInputStream(s.getInputStream());
        this.logTextArea = logTextArea;
        this.source = source;
    }

    /**
     * waits for requests from client, shows requests on the log, executes requests on the database and returns results to client. If a client locks a record, a copy of the record number and lock cookie is stored here. If a client disconnects or locks another record while holding a lock, it is silently unlocked.
     *  
     */
    public void run() {
        long lockCookie = -1;
        int lockRecNo = -1;
        boolean dontstop = true;
        while (dontstop) {
            try {
                Request request = (Request) this.ois.readObject();
                this.logTextArea.insert(getName() + ": " + request.toString() + "\n", 0);

                if (request instanceof LockRequest && lockRecNo != -1) {
                    this.logTextArea.insert(getName() + ": auto-unlocking.\n", 0);
                    try {
                        //do this before execute to avoid deadlocks
                        this.source.ontgrendel(lockRecNo, lockCookie);
                        lockRecNo = -1;
                        lockCookie = -1;
                        //dont send the exception to the client because it isnt expecting this ontgrendel
                    } catch (RecordNotFoundException rnfe) {
                        this.logTextArea.insert(getName() + ": " + rnfe.toString() + "\n", 0);
                    } catch (SecurityException se) {
                        this.logTextArea.insert(getName() + ": " + se.toString() + "\n", 0);
                    }
                }

                Object response = request.execute(this.source, getName(), this.logTextArea);

                this.oos.writeObject(response);

                if (request instanceof LockRequest && response instanceof Long) {
                    lockRecNo = ((LockRequest) request).getRecNo();
                    lockCookie = ((Long) response).longValue();
                } else {
                    if (request instanceof UnlockRequest && response instanceof Boolean) {
                        lockRecNo = -1;
                        lockCookie = -1;
                    }
                }
            } catch (Exception e) {
                //connection was lost or the received object was not a request
                dontstop = false;
                this.logTextArea.insert(getName() + ": " + e.toString() + "\n", 0);
                if (lockRecNo != -1) { //client was holding a lock on a record, ontgrendel it.
                    this.logTextArea.insert(getName() + ": auto-unlocking.\n", 0);
                    try {
                        this.source.ontgrendel(lockRecNo, lockCookie);
                        //dont try to write any errors to the client because its probably disconnected
                    } catch (RecordNotFoundException rnfe) {
                        this.logTextArea.insert(getName() + ": " + rnfe.toString() + "\n", 0);
                    } catch (SecurityException se) {
                        this.logTextArea.insert(getName() + ": " + se.toString() + "\n", 0);
                    }
                }
            }
        }
        try {
            this.ois.close();
        } catch (IOException ioe) {
            this.logTextArea.insert(getName() + ": " + ioe.toString() + "\n", 0);
        }
        try {
            this.oos.close();
        } catch (IOException ioe) {
            this.logTextArea.insert(getName() + ": " + ioe.toString() + "\n", 0);
        }
        this.logTextArea.insert(getName() + ": disconnected. \n", 0);
    }

}