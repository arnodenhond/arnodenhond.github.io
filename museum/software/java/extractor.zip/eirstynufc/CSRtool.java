package eirstynufc;

import eirstynufc.client.GUI;
import eirstynufc.db.Data;
import eirstynufc.db.DuplicateKeyException;
import eirstynufc.db.RecordNotFoundException;
import eirstynufc.db.RemoteData;
import eirstynufc.server.ClientAcceptor;

/**
 * the main class contains only the main method. it is called when the programs starts
 * 
 * @author Arno den Hond
 *  
 */
public class CSRtool {

    /**
     * creates a GUI connected to RemoteData in clientmode or connected to Data in standalone mode. creates a ClientAcceptor connected to Data in servermode
     * 
     * @param args
     *            command line start up arguments: "alone" for standalone, "server" for server, none for client
     * @see suncertify.server.ClientAcceptor
     * @see suncertify.client.GUI
     * @see suncertify.db.RemoteData
     * @see suncertify.db.Data
     */

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Starting CSRtool in client mode");
            new GUI(new RemoteData());
        } else {
            if (args[0].equals("server")) {
                System.out.println("Starting CSRtool in server mode");
                new ClientAcceptor(new Data()).accept();
            } else {
                if (args[0].equals("alone")) {
                    System.out.println("Starting CSRtool in stand-alone mode");
                    new GUI(new Data());
                }
            }
        }
    }

}