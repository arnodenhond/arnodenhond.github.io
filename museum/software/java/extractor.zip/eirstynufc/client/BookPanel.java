package eirstynufc.client;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;

import eirstynufc.db.RealDB;
import eirstynufc.db.Record;
import eirstynufc.db.RecordNotFoundException;

/**
 * this panel allows the user to enter a booking id for a record. it contains an input field for owner ID and a book button. the actionPerformed method for the book button is also in this class.
 * 
 * @see suncertify.client.SearchPanel
 * @author Arno den Hond
 *  
 */
public class BookPanel extends JPanel implements ActionListener {

    private JTextField bookField;

    private RealDB source;

    private JTable table;

    /**
     * constructs the book panel. it contains a textfield and a button.
     * 
     * @param source
     *            the source that the button should send the booking requests to
     * @param table
     *            the table that should be updated after booking
     */
    public BookPanel(RealDB source, JTable table) {
        super(new GridBagLayout());
        this.source = source;
        this.table = table;
        this.bookField = new JTextField(25);
        //could be a FormattedTextField to accept only an 8 digit number
        JButton bookButton = new JButton("Book");
        bookButton.addActionListener(this);
        setBorder(new TitledBorder("Book"));
        add(new JLabel((String) this.table.getColumnModel().getColumn(Record.OWNER).getHeaderValue()), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(this.bookField, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(bookButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    }

    /**
     * locks the record selected in the table, checks if it isnt booked already, updates and unlocks. finally the table's gui is updated. popups are shown if any exceptions occur during these operations
     * 
     * 
     * 
     * 
     * 
     * @param ae
     *            the action event
     * @see suncertify.db.DBvergrendelk(int)
     * @see suncertify.db.DB#lees(int)
     * @see suncertify.db.DBwijzige(int, String[], long)
     * @see suncertify.db.DBontgrendelk(int, long)
     */
    public void actionPerformed(ActionEvent ae) {
        if (this.table.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(this.table, "Select a row in the table", "Whoops!", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Integer.parseInt(this.bookField.getText().trim());
            if (this.bookField.getText().trim().length() > 8)
                throw new NumberFormatException();//if its less than 8, zeros will be prepended
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this.table, "The booking-ID must be an 8-digit number", "Uh-Oh!", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ResultTableModel rtm = (ResultTableModel) this.table.getModel();
        int recNo = rtm.getRecords()[this.table.getSelectedRow()];
        long cookie = -1;

        try { //vergrendel the record
            cookie = this.source.vergrendel(recNo);
        } catch (RecordNotFoundException rnfe) {
            JOptionPane.showMessageDialog(this.table, rnfe.toString(), "Could not lock record", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String[] data = null;
        //lees record again to check booking and name/location
        try {
            data = this.source.lees(recNo);
        } catch (RecordNotFoundException rnfe) {
            unlock(recNo, cookie);//keep record locked as short as possible: ontgrendel it before showing a modal dialog
            JOptionPane.showMessageDialog(this.table, rnfe.toString(), "Could not read record", JOptionPane.ERROR_MESSAGE);
            return;
        }

        //check if the record is not already booked
        if (data.length < rtm.getColumnCount() || !data[Record.OWNER].trim().equals("")) {
            unlock(recNo, cookie);
            JOptionPane.showMessageDialog(this.table, "Too late, record already booked!", "Oh-No!", JOptionPane.ERROR_MESSAGE);
            this.table.tableChanged(new TableModelEvent(rtm));
            return;
        }

        //check if name and location of re-lees data are still the same as what was already in the table model
        if (!data[Record.NAME].trim().equals(rtm.getValueAt(this.table.getSelectedRow(), Record.NAME)) || !data[Record.LOCATION].trim().equals(rtm.getValueAt(this.table.getSelectedRow(), Record.LOCATION))) {
            unlock(recNo, cookie);
            JOptionPane.showMessageDialog(this.table, "Record was modified. Check new data and try again.", "What?!", JOptionPane.ERROR_MESSAGE);
            //flush the cache and wijzig table
            rtm.setRecords(rtm.getRecords());
            this.table.tableChanged(new TableModelEvent(rtm));
            return;
        }

        data[Record.OWNER] = this.bookField.getText().trim();

        try { //wijzig the record
            this.source.wijzig(recNo, data, cookie);
            unlock(recNo, cookie);
        } catch (RecordNotFoundException rnfe) {
            unlock(recNo, cookie);
            JOptionPane.showMessageDialog(this.table, rnfe.toString(), "Could not update record", JOptionPane.ERROR_MESSAGE);
        } catch (SecurityException se) {
            unlock(recNo, cookie);
            JOptionPane.showMessageDialog(this.table, se.toString(), "Could not update record", JOptionPane.ERROR_MESSAGE);
        }

        this.bookField.setText("");
        //flushing the cache is not necessary to show the new booking as that field is never cached
        this.table.tableChanged(new TableModelEvent(rtm));
    }

    /**
     * unlocks a record and shows a pop-up if an error occurs
     * 
     * 
     * 
     * @param recNo
     *            the index of the record toontgrendelk
     * @param cookie
     *            the vergrendel cookie
     * @see suncertify.db.DBontgrendelk(int, long)
     */
    private void unlock(int recNo, long cookie) {
        try {
            this.source.ontgrendel(recNo, cookie);
        } catch (RecordNotFoundException rnfe) {
            JOptionPane.showMessageDialog(this.table, rnfe.toString(), "Could not unlock record", JOptionPane.ERROR_MESSAGE);
        } catch (SecurityException se) {
            JOptionPane.showMessageDialog(this.table, se.toString(), "Could not unlock record", JOptionPane.ERROR_MESSAGE);
        }
    }

}