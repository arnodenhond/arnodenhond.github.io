package eirstynufc.client;

import java.awt.event.ActionEvent;
import java.util.Hashtable;

import javax.swing.table.AbstractTableModel;

import eirstynufc.db.RealDB;
import eirstynufc.db.Record;
import eirstynufc.db.RecordNotFoundException;

/**
 * the tablemodel that feeds data to the table. this class also caches records.
 * 
 * @author Arno den Hond
 *  
 */
public class ResultTableModel extends AbstractTableModel {

    private Hashtable cache;

    private RealDB source;

    private int[] records;

    private String[] columnNames;

    /**
     * constructs the table model and cache
     * 
     * @param source
     *            the source to load the data from
     * @param records
     *            the initial record numbers to show in the table
     */
    public ResultTableModel(RealDB source, int[] records) {
        this.source = source;
        this.setRecords(records);
    }

    /**
     * sets a new recordset and empties the cache. does not update the GUI of the table.
     * 
     * @param records
     *            the record numbers to show in the table
     * @see suncertify.client.SearchPanel#actionPerformed(ActionEvent)
     */
    public void setRecords(int[] records) {
        this.records = records;
        this.cache = new Hashtable();
    }

    /**
     * gets the private records array. the numbers in this array represent record indexes in the actual database.
     * 
     * @return the private records array
     * @see suncertify.client.BookPanel#actionPerformed(ActionEvent)
     */
    public int[] getRecords() {
        return this.records;
    }

    /**
     * gets the number of fields specified in the header of the datafile.
     * 
     * @return the number of fields specified in the header of the datafile
     * @see javax.swing.table.TableModel#getColumnCount()
     * @see suncertify.db.RealDB#getColumns()
     */
    public int getColumnCount() {
        if (this.columnNames == null)
            this.columnNames = this.source.getColumns();
        return this.columnNames.length;
    }

    /**
     * gets the number of rows to be shown in the table.
     * 
     * @return the length of the array set by setRecords
     * @see suncertify.client.ResultTableModel#setRecords(int[])
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
        return this.records.length;
    }

    /**
     * feeds a field of a record to a cell of the table. tries to load data from cache, saves to cache if unable. the owner column is always reloaded from the data layer.
     * 
     * 
     * @param rowNo
     *            (not reCno!) index in the array set by setRecords
     * @param colNo
     *            field index
     * @return the cell data
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     * @see suncertify.db.DB#lees(int)
     */
    public Object getValueAt(int rowNo, int colNo) {
        try {
            if (rowNo >= getRowCount() || colNo >= getColumnCount())
                return (Object) new String("no data for cell " + rowNo + "," + colNo);
            String[] row = null;
            //dont get the booking field of the record from cache, always reload:
            if (colNo == Record.OWNER) {
                row = this.source.lees(this.records[rowNo]);
            } else {
                //if not in cache, put in cache:
                row = (String[]) this.cache.get(new Integer(rowNo));
                if (row == null) {
                    row = this.source.lees(this.records[rowNo]);
                    this.cache.put(new Integer(rowNo), row);
                }
            }
            if (colNo < row.length) {
                return (Object) row[colNo].trim();
            } else {
                return (Object) new String("no data for cell " + rowNo + "," + colNo);
            }
        } catch (RecordNotFoundException rnfe) {
            //probably the user requests many records at once so
            //dont show popups but put the error message in the table
            return (Object) rnfe.toString();
        }
    }

    /**
     * feeds the name of a column to the table
     * 
     * @param colNo
     *            column index
     * @return the name of the column
     * @see javax.swing.table.TableModel#getColumnName(int)
     * @see suncertify.db.RealDB#getColumns()
     */
    public String getColumnName(int colNo) {
        //columnNames should already be cached by getColumnCount but check it anyway:
        if (this.columnNames == null)
            this.columnNames = this.source.getColumns();
        return this.columnNames[colNo];
    }

}