package eirstynufc.client;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.TableModelEvent;

import eirstynufc.db.RealDB;
import eirstynufc.db.Record;

/**
 * this panel allows the user to search on name and/or location. it contains the input fields for name and location aswell as a search button. the actionPerformed method for the search button is also in this class.
 * 
 * @see suncertify.client.BookPanel
 * @author Arno den Hond
 *  
 */
public class SearchPanel extends JPanel implements ActionListener {

    private RealDB source;

    private JTable table;

    private JTextField nameField;

    private JTextField locationField;

    /**
     * constructs the search panel. it contains textfields for name and location and a search button.
     * 
     * @param source
     *            the source that the button should send the findrequest to
     * @param table
     *            the table that should hold the result of the findrequest
     */
    public SearchPanel(RealDB source, JTable table) {
        super(new GridBagLayout());
        this.source = source;
        this.table = table;
        this.nameField = new JTextField(25);
        this.locationField = new JTextField(25);
        JButton twoButton = new JButton("Search");
        twoButton.addActionListener(this);
        setBorder(new TitledBorder("Search"));
        add(new JLabel((String) this.table.getColumnModel().getColumn(Record.NAME).getHeaderValue()), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(new JLabel((String) this.table.getColumnModel().getColumn(Record.LOCATION).getHeaderValue()), new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(this.nameField, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(this.locationField, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        add(twoButton, new GridBagConstraints(2, 0, 1, 2, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
    }

    /**
     * queries the database on name and/or location fields and sends results to the table's model.
     * 
     * @param ae
     *            the action event
     * @see suncertify.db.RealDB#exactFind(String[])
     * @see suncertify.client.ResultTableModel#setRecords(int[])
     */
    public void actionPerformed(ActionEvent ae) {
        ResultTableModel rtm = (ResultTableModel) this.table.getModel();
        String[] query = new String[rtm.getColumnCount()];
        if (!this.nameField.getText().trim().equals("")) {
            query[Record.NAME] = this.nameField.getText().trim();
        }
        if (!this.locationField.getText().trim().equals("")) {
            query[Record.LOCATION] = this.locationField.getText().trim();
        }
        int[] records = this.source.exactFind(query);
        rtm.setRecords(records);
        this.table.tableChanged(new TableModelEvent(rtm));
        if (records.length == 0) {
            JOptionPane.showMessageDialog(this.table, "No results", "Search completed", JOptionPane.INFORMATION_MESSAGE);
        }
    }

}