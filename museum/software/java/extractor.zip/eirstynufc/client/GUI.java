package eirstynufc.client;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

import eirstynufc.db.RealDB;
import eirstynufc.db.Record;

/**
 * the client frame, containing the searchpanel, bookpanel and result-table (and its model). this class is also the ActionListener for both menu items.
 * 
 * @author Arno den Hond
 *  
 */
public class GUI extends JFrame implements ActionListener {

    private RealDB source;

    private JTable table;

    /**
     * constructs the frame (searchpanel, table and bookpanel) then sets the source to send requests to, and load data from. the table is filled with all records by searching on an empty query
     * 
     * @param source
     *            the data access layer - RemoteData in client mode, Data in standalone mode
     */
    public GUI(RealDB source) {
        super("CSRtool");
        this.source = source;
        //load all data (the results of an empty search) into the table
        ResultTableModel rtm = new ResultTableModel(source, source.exactFind(new String[source.getColumns().length]));
        rtm.addTableModelListener(this.table);
        this.table = new JTable(rtm);
        this.table.setSize(250, 250);
        this.table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.table.getColumnModel().getColumn(Record.SPECIALTIES).setPreferredWidth(150);
        this.table.getColumnModel().getColumn(Record.SIZE).setPreferredWidth(25);
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Contractor");
        JMenuItem createItem = new JMenuItem("Create");
        createItem.addActionListener(this);
        JMenuItem deleteItem = new JMenuItem("Delete");
        deleteItem.addActionListener(this);
        menu.add(createItem);
        menu.add(deleteItem);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.add(new SearchPanel(source, this.table), new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(new JScrollPane(this.table), new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(new BookPanel(source, this.table), new GridBagConstraints(0, 2, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));

        getContentPane().add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    /**
     * displays a dialog showing nothing is here yet.
     * 
     * @param ae
     *            the action event
     *  
     */
    public void actionPerformed(ActionEvent ae) {
        JOptionPane.showMessageDialog(this.table, "this option has only been provided to support future functionality.", "Nothing!", JOptionPane.INFORMATION_MESSAGE);
    }

}