package eirstynufc.client;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 * the server address and port configuration dialog and its actionPerformed method. called by RemoteData to get the address to reach the server on.
 * 
 * @see suncertify.db.DataConfig
 * @see suncertify.server.PortConfig
 * @see suncertify.db.RemoteData
 * @author Arno den Hond
 *  
 */
public class ServerConfig extends JDialog implements ActionListener {

    private Properties props;

    private JTextField addressTF;

    private JTextField portTF;

    private JTable table;

    /**
     * creates the dialog and loads the address and port number settings from the properties file into it. shows a dialog if unable to load.
     *  
     */
    public ServerConfig() {
        super((Frame) null, "Server address and port number", true);
        this.props = new Properties();
        try {
            FileInputStream fis = new FileInputStream("suncertify.properties");
            this.props.load(fis);
            fis.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not load properties", JOptionPane.WARNING_MESSAGE);
        }
        //put the last saved server address and port number in the JTextFields
        this.addressTF = new JTextField(this.props.getProperty("hostname", "127.0.0.1"), 25);
        this.portTF = new JTextField(this.props.getProperty("portnumber", "3688"), 5);
        //portTF could be a formatted textfield so it only accepts numbers
        JButton okButton = new JButton("OK");
        okButton.addActionListener(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.add(new JLabel("Server address"), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(this.addressTF, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(new JLabel("Port number"), new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(this.portTF, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(okButton, new GridBagConstraints(2, 0, 1, 2, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        getContentPane().add(panel);
        pack();
        setVisible(true);
    }

    /**
     * called when the user hits the OK button. saves the server address and port number to suncertify.properties or shows a dialog if unable to save.uses the same property as the server uses to accept clients on.
     * 
     * @param ae
     *            the action event
     * @see suncertify.server.PortConfig#actionPerformed(ActionEvent)
     */
    public void actionPerformed(ActionEvent ae) {
        try {
            Integer.parseInt(this.portTF.getText());
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "port number must be a NUMBER.");
            return;
        }

        this.props.setProperty("hostname", this.addressTF.getText());
        this.props.setProperty("portnumber", this.portTF.getText());
        try {
            FileOutputStream fos = new FileOutputStream("suncertify.properties");
            this.props.store(fos, "CSRtool");
            fos.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not save properties", JOptionPane.ERROR_MESSAGE);
        }
        dispose();
    }

}