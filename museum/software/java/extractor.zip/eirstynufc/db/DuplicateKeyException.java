package eirstynufc.db;

/**
 * only thrown if a record is created (which is never done by the client) which has name and location equal to an existing record
 * 
 * @author Arno den Hond
 *  
 */
public class DuplicateKeyException extends Exception {

    /**
     * calls the constructor of the superclass
     *  
     */
    public DuplicateKeyException() {
        super();
    }

    /**
     * calls the constructor of the superclass
     * 
     * @param message
     *            the error message (could contain the key of the record which was attempted to create)
     */
    public DuplicateKeyException(String message) {
        super(message);
    }

}