package eirstynufc.db;

import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * the datafilename configuration dialog and its actionPerformed method. called by Data to get the name of the file to load the data from.
 * 
 * @see suncertify.client.ServerConfig
 * @see suncertify.server.PortConfig
 * @see suncertify.db.Data
 * @author Arno den Hond
 *  
 */
public class DataConfig extends JDialog implements ActionListener {

    private Properties props;

    private JTextField nameTF;

    /**
     * creates the dialog and loads the datafile filename setting from the properties file into it. shows a dialog if unable to load.
     *  
     */
    public DataConfig() {
        super((Frame) null, "Database filename", true);
        this.props = new Properties();
        try {
            FileInputStream fis = new FileInputStream("suncertify.properties");
            this.props.load(fis);
            fis.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not load properties", JOptionPane.WARNING_MESSAGE);
        }
        //put the last saved datafile filename in the JTextField
        this.nameTF = new JTextField(this.props.getProperty("filename", "db-2x2.db"), 25);
        JButton okButton = new JButton("OK");
        okButton.addActionListener(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.add(new JLabel("Database filename"), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(this.nameTF, new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        panel.add(okButton, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 5, 5, 5), 0, 0));
        getContentPane().add(panel);
        pack();
        setVisible(true);
    }

    /**
     * called when the user hits the OK button. saves the datafile filename to suncertify.properties or shows a dialog if unable to save
     * 
     * @param ae
     *            the action event
     */
    public void actionPerformed(ActionEvent ae) {
        this.props.setProperty("filename", this.nameTF.getText());
        try {
            FileOutputStream fos = new FileOutputStream("suncertify.properties");
            this.props.store(fos, "CSRtool");
            fos.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not save properties", JOptionPane.ERROR_MESSAGE);
        }
        dispose();
    }

}