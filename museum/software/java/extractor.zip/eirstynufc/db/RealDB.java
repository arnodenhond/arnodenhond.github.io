package eirstynufc.db;

/**
 * this interface extends DB. its defines additional methods for getting the column names and for searching the database for exactly matching records
 * 
 * @author Arno den Hond
 *  
 */
public interface RealDB extends DB {

    /**
     * gets the column names
     * 
     * @return the column names
     */
    public String[] getColumns();

    /**
     * searches the database for exactly matching records
     * 
     * @param criteria
     *            the search query
     * @return record numbers of matching records
     */
    public int[] exactFind(String[] criteria);

}