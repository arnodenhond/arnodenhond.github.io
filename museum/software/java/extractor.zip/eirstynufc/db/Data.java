package eirstynufc.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JOptionPane;

/**
 * the data access class. loads and saves the datafile. finds, creates, deletes, updates, locks and unlocks records.
 * 
 * @author Arno den Hond
 *  
 */
public class Data implements RealDB {

    private String filename;

    private int offset;

    private int recordLength;

    private String[] fieldNames;

    private int[] fieldLengths;

    private Record[] records;

    private static long curLockCookie;

    /**
     * loads the database filename setting then loads the data into the private records array. Terminates with errorlevel 36 if file could not be read or if magicCookie in database is not 514.
     *  
     */
    public Data() {
        curLockCookie = System.currentTimeMillis();
        //allow the user to set a new datafilename
        DataConfig dataConfig = new DataConfig();
        Properties props = new Properties();
        try {
            FileInputStream fis = new FileInputStream("suncertify.properties");
            props.load(fis);
            fis.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not load settings, using default database filename", JOptionPane.ERROR_MESSAGE);
        }
        this.filename = props.getProperty("filename", "db-2x2.db");
        //check if the file exists
        File f = new File(this.filename);
        if (!f.canRead()) {
            JOptionPane.showMessageDialog(null, "Could not read \"" + this.filename + "\"", "Datafile error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Could not read \"" + this.filename + "\"");
            System.exit(36);
        }
        RandomAccessFile raf = null;
        //read the header
        try {
            raf = new RandomAccessFile(this.filename, "rw");
            if (raf.readInt() != 514) {
                JOptionPane.showMessageDialog(null, "Magic cookie incorrect!", "Datafile  error", JOptionPane.ERROR_MESSAGE);
                System.out.println("Magic cookie incorrect!");
                System.exit(36);
            }
            //recordlength should include deleted flag which is 2 bytes
            this.recordLength = 2;
            this.offset = raf.readInt();
            int fields = raf.readShort();
            this.fieldNames = new String[fields];
            this.fieldLengths = new int[fields];
            //read the field names and lengths
            for (int i = 0; i < fields; i++) {
                byte[] temp = new byte[raf.readShort()];
                raf.read(temp);
                this.fieldNames[i] = new String(temp);
                this.fieldLengths[i] = raf.readShort();
                this.recordLength += this.fieldLengths[i];
            }
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not read datafile header", JOptionPane.ERROR_MESSAGE);
            System.out.println("Could not read datafile header: " + ioe.toString());
            System.exit(36);
        }
        //read the records into a growable list because it is not known how many records will be read
        ArrayList al = new ArrayList();
        try {
            while (true) {
                al.add(new Record(raf, this.fieldLengths));
            }
        } catch (IOException ioe) {
            //end of file reached, no problem
        }
        //convert al to records[]
        this.records = new Record[al.size()];
        for (int i = 0; i < this.records.length; i++) {
            this.records[i] = (Record) al.get(i);
        }
    }

    private void validateRecNo(int recNo) throws RecordNotFoundException {
        if (recNo < 0) {
            throw new RecordNotFoundException(recNo + " is an invalid record number");
        }
        if (recNo >= this.records.length) {
            throw new RecordNotFoundException("Record " + recNo + " does not exist");
        }
        if (this.records[recNo].isDeleted()) {
            throw new RecordNotFoundException("Record " + recNo + " has been deleted");
        }
    }

    private void validateCookie(int recNo, long lockCookie) throws SecurityException {
        if (recNo < 0 || recNo >= this.records.length) {
            throw new SecurityException(recNo + " is an invalid record number");
        }
        if (lockCookie != this.records[recNo].getLockCookie() || lockCookie < 0) {
            throw new SecurityException(lockCookie + " is invalid an lock cookie for record " + recNo);
        }
    }

    /**
     * concatenates the first two elements of a String[] to a single String. used in create() to check for duplicates
     * 
     * @param data
     *            the string[]
     * @return the first to elements of data concatenated to a single String.
     * @see suncertify.db.Data#create(String[])
     */
    private String recToKey(String[] data) {
        String keyString = new String();
        keyString += data[Record.NAME].trim();
        keyString += data[Record.LOCATION].trim();
        return keyString;
    }

    /**
     * locks a record. if record already locked, waits for record to become unlocked. returns a new lockCookie and stores it in the record for unlocking
     * 
     * @param recNo
     *            the record number to lock
     * @return the lockCookie needed to update, delete or unlock the record
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @see suncertify.db.Record#setLockCookie(long)
     */
    public long vergrendel(int recNo) throws RecordNotFoundException {
        validateRecNo(recNo);
        synchronized (this.records[recNo]) {
            validateRecNo(recNo);
            while (this.records[recNo].getLockCookie() != -1) {
                try {
                    this.records[recNo].wait();
                } catch (InterruptedException ie) {
                    //thread has been interrupted, we dont care.
                }
                //the record could have been deleted while waiting
                if (this.records[recNo].isDeleted()) {
                    //wake up any thread waiting for this record
                    this.records[recNo].notifyAll();
                    throw new RecordNotFoundException("Record " + recNo + " has been deleted");
                }
            }
            this.records[recNo].setLockCookie(++curLockCookie);
        }
        return this.records[recNo].getLockCookie();
    }

    /**
     * unlocks a record and notifies other threads waiting for this record.
     * 
     * @param recNo
     *            the record number to unlock
     * @param cookie
     *            the code needed to access this record
     * @throws RecordNotFoundException
     *             if the recNo was invalid. unlocking a deleted is allowed
     * @throws SecurityException
     *             if the lockCookie was invalid.
     * @see suncertify.db.Record #setLockCookie(long)
     */
    public void ontgrendel(int recNo, long cookie) throws RecordNotFoundException, SecurityException {
        //unlocking a deleted record is allowed
        if (recNo < 0) {
            throw new RecordNotFoundException(recNo + " is an invalid record number");
        }
        if (recNo >= this.records.length) {
            throw new RecordNotFoundException("Record " + recNo + " does not exist");
        }
        validateCookie(recNo, cookie);
        synchronized (this.records[recNo]) {
            this.records[recNo].setLockCookie(-1);
            this.records[recNo].notifyAll();
        }
    }

    /**
     * reads a record
     * 
     * @param recNo
     *            the record number to read
     * @return the fields of the record
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @see suncertify.db.Record#getData()
     */
    public String[] lees(int recNo) throws RecordNotFoundException {
        validateRecNo(recNo);
        return this.records[recNo].getData();
    }

    /**
     * updates a record and stores to disk. method is synchronized to avoid possible concurrent writing errors. overwrites a record which is already booked, checking should be done in the gui.
     * 
     * @param recNo
     *            the record number to update
     * @param data
     *            the actual data to set in this record
     * @param lockCookie
     *            the code needed to access this record
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @throws SecurityException
     *             if the lockCookie was invalid.
     * @see suncertify.db.Record#setData(String[])
     * @see suncertify.db.Record#save(RandomAccessFile)
     */
    synchronized public void wijzig(int recNo, String[] data, long lockCookie) throws RecordNotFoundException, SecurityException {
        validateRecNo(recNo);
        validateCookie(recNo, lockCookie);
        this.records[recNo].setData(data);
        try {
            RandomAccessFile raf = new RandomAccessFile(this.filename, "rw");
            raf.seek(this.offset + (this.recordLength * recNo));
            this.records[recNo].save(raf);
            raf.close();
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Could not save update because " + ioe.toString());
        }
    }

    /**
     * sets the deleted boolean to true and saves flag to disk. method is synchronized to avoid possible concurrent writing errors.
     * 
     * @param recNo
     *            the record number to delete
     * @param lockCookie
     *            the code needed to access this record
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @throws SecurityException
     *             if the lockCookie was invalid.
     * @see suncertify.db.Record#setDeleted(boolean)
     */
    synchronized public void verwijder(int recNo, long lockCookie) throws RecordNotFoundException, SecurityException {
        validateRecNo(recNo);
        validateCookie(recNo, lockCookie);
        try {
            RandomAccessFile raf = new RandomAccessFile(this.filename, "rw");
            raf.seek(this.offset + (this.recordLength * recNo));
            raf.writeShort(0x8000);
            raf.close();
            this.records[recNo].setDeleted(true);
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Could not save deleted flag because " + ioe.toString());
        }
    }

    /**
     * adds a new record to the records array. re-uses a deleted record if one is available.
     * 
     * @param data
     *            the data for the new record
     * @throws DuplicateKeyException
     *             if the database already contains a non-deleted record with the same name and location as the new record.
     * @return the index (recNo) of the new record
     * @see suncertify.db.Record#setData(String[])
     * @see suncertify.db.Record#setDeleted(boolean)
     * @see suncertify.db.Record#save(RandomAccessFile)
     */
    synchronized public int maak(String[] data) throws DuplicateKeyException {
        //all fields must be specified
        if (data.length < this.fieldNames.length)
            return -1;
        //first check if this record does not already exist
        for (int recNo = 0; recNo < this.records.length; recNo++) {
            if (!this.records[recNo].isDeleted() && recToKey(this.records[recNo].getData()).equals(recToKey(data))) {
                throw new DuplicateKeyException("A record with name \"" + data[Record.NAME] + " and location \"" + data[Record.LOCATION] + " already exists");
            }
        }
        //try to find a deleted unlocked record to re-use
        for (int recNo = 0; recNo < this.records.length; recNo++) {
            if (this.records[recNo].isDeleted() && (this.records[recNo].getLockCookie() == -1)) {
                this.records[recNo].setData(data);
                this.records[recNo].setDeleted(false);
                try {
                    RandomAccessFile raf = new RandomAccessFile(this.filename, "rw");
                    raf.seek(this.offset + (this.recordLength * recNo));
                    this.records[recNo].save(raf);
                    raf.close();
                } catch (IOException ioe) {
                    throw new DuplicateKeyException("Could not re-use deleted record because " + ioe.toString());
                }
                return recNo;
            }
        }
        //an available record could not be found, append to record array
        Record[] newRecords = new Record[this.records.length + 1];
        System.arraycopy(this.records, 0, newRecords, 0, this.records.length);
        newRecords[this.records.length] = new Record(data, this.fieldLengths);
        this.records = newRecords;
        try {
            RandomAccessFile raf = new RandomAccessFile(this.filename, "rw");
            raf.seek(raf.length());
            this.records[this.records.length - 1].save(raf);
            raf.close();
        } catch (IOException ioe) {
            throw new DuplicateKeyException("Could not append new record because " + ioe.toString());
        }
        return this.records.length;
    }

    /**
     * gets the names of the fields specified in the header of the datafile
     * 
     * @return the names of the fields specified in the header of the datafile
     */
    public String[] getColumns() {
        return this.fieldNames;
    }

    /**
     * finds records that match the query according to startsMatch
     * 
     * @param criteria
     *            the search terms. if array length is 0, no results else criteria number must match field number. if all fields are null all records will be returned
     * @return an array of record numbers of matching records
     * @see suncertify.db.Record#startsMatch(String[])
     */
    public int[] zoek(String[] criteria) {
        if (criteria.length == 0) {
            return new int[0];
        }
        ArrayList resultAL = new ArrayList();
        for (int recNo = 0; recNo < this.records.length; recNo++) {
            if (this.records[recNo].startsMatch(criteria)) {
                resultAL.add(new Integer(recNo));
            }
        }
        //convert Integer-ArrayList to int[]:
        int[] result = new int[resultAL.size()];
        for (int recNo = 0; recNo < resultAL.size(); recNo++) {
            Integer I = (Integer) resultAL.get(recNo);
            result[recNo] = I.intValue();
        }
        return result;
    }

    /**
     * finds records that match the query according to equalsMatch
     * 
     * @param criteria
     *            the search terms. if array length is 0, no results else criteria number must match field number. if all fields are null all records will be returned
     * @return an array of record numbers of matching records
     * @see suncertify.db.Record#equalsMatch(String[])
     */
    public int[] exactFind(String[] criteria) {
        if (criteria.length == 0) {
            return new int[0];
        }
        ArrayList resultAL = new ArrayList();
        for (int recNo = 0; recNo < this.records.length; recNo++) {
            if (this.records[recNo].equalsMatch(criteria)) {
                resultAL.add(new Integer(recNo));
            }
        }
        //convert Integer-ArrayList to int[]:
        int[] result = new int[resultAL.size()];
        for (int recNo = 0; recNo < resultAL.size(); recNo++) {
            Integer I = (Integer) resultAL.get(recNo);
            result[recNo] = I.intValue();
        }
        return result;
    }

}