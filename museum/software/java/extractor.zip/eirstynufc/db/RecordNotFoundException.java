package eirstynufc.db;

/**
 * thrown when any attempt is made to access a non-existing record. recNo could be out of range or the record could be deleted
 * 
 * @author Arno den Hond
 *  
 */
public class RecordNotFoundException extends Exception {

    /**
     * calls the constructor of the superclass
     */
    public RecordNotFoundException() {
        super();
    }

    /**
     * calls the constructor of the superclass
     * 
     * @param message
     *            the error message (could contain the record number which was attempted to access)
     */
    public RecordNotFoundException(String message) {
        super(message);
    }

}