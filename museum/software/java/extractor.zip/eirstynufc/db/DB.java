package eirstynufc.db;

public interface DB {
    public String[] lees(int recNo) throws RecordNotFoundException;

    public void wijzig(int recNo, String[] data, long lockCookie) throws RecordNotFoundException, SecurityException;

    public void verwijder(int recNo, long lockCookie) throws RecordNotFoundException, SecurityException;

    public int[] zoek(String[] criteria);

    public int maak(String[] data) throws DuplicateKeyException;

    public long vergrendel(int recNo) throws RecordNotFoundException;

    public void ontgrendel(int recNo, long cookie) throws RecordNotFoundException, SecurityException;
}