package eirstynufc.db;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * this class represents a record. it holds the data (all fields) for a single record
 * 
 * @author Arno den Hond
 *  
 */
public class Record {

    private long lockCookie;

    private boolean deleted;

    private String[] data;

    private int[] fieldLengths;

    /**
     * the index of the name field in String[] data
     */
    public static final int NAME = 0;

    /**
     * the index of the location field in String[] data
     */
    public static final int LOCATION = 1;

    /**
     * the index of the specialties field in String[] data
     */
    public static final int SPECIALTIES = 2;

    /**
     * the index of the size field in String[] data
     */
    public static final int SIZE = 3;

    /**
     * the index of the rate field in String[] data
     */
    public static final int RATE = 4;

    /**
     * the index of the owner field in String[] data
     */
    public static final int OWNER = 5;

    /**
     * reads data from datafile and places it in itself
     * 
     * @param raf
     *            the file to read this record from
     * @throws IOException
     *             if the record could not be fully read
     */
    public Record(RandomAccessFile raf, int[] fieldLengths) throws IOException {
        this.lockCookie = -1;
        this.deleted = (raf.readShort() == 0x8000);
        this.fieldLengths = fieldLengths;
        this.data = new String[fieldLengths.length];
        this.data[NAME] = read(raf, fieldLengths[NAME]);
        this.data[LOCATION] = read(raf, fieldLengths[LOCATION]);
        this.data[SPECIALTIES] = read(raf, fieldLengths[SPECIALTIES]);
        this.data[SIZE] = read(raf, fieldLengths[SIZE]);
        this.data[RATE] = read(raf, fieldLengths[RATE]);
        this.data[OWNER] = read(raf, fieldLengths[OWNER]);
    }

    /**
     * constructs a new record and places the data in itself
     * 
     * @param data
     *            the data to put into this record
     */
    public Record(String[] data, int[] fieldLengths) {
        setData(data);
        this.deleted = false;
        this.lockCookie = -1;
        this.fieldLengths = fieldLengths;
    }

    /**
     * checks if this record is deleted
     * 
     * @return true if this record is deleted, false if it is .... not!
     */
    public boolean isDeleted() {
        return this.deleted;
    }

    /**
     * sets this record deleted (or undeleted).
     * 
     * @param deleted
     *            true if this record should be deleted, false if it should not
     * @see suncertify.db.Data#delete(int, long)
     * @see suncertify.db.Data#create(String[])
     */
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    /**
     * gets the lock cookie for this record
     * 
     * @return the lock cookie for this record (or -1 if not locked)
     */
    public long getLockCookie() {
        return this.lockCookie;
    }

    /**
     * sets the lock cookie for this record.
     * 
     * @param lockCookie
     *            the lock cookie for this record (or -1 to unlock)
     * @see suncertify.db.Data#lock(int)
     * @see suncertify.db.Data#unlock(int, long)
     */
    public void setLockCookie(long lockCookie) {
        this.lockCookie = lockCookie;
    }

    /**
     * makes all fields of proper length. cuts off if too long, streches out if too short
     * 
     * @param data
     *            the record whose fields to check
     * @return the same record with all fields at proper lengths
     */
    private String[] validateFieldLengths(String[] data) {
        String[] result = new String[this.fieldLengths.length];
        for (int i = 0; i < this.fieldLengths.length; i++) {
            //make sure we have a field left to validate
            if (i > data.length) {
                result[i] = new String();
            } else {
                result[i] = data[i];
            }
            //cut if off if its too long
            if (result[i].length() > this.fieldLengths[i]) {
                if (i == Record.OWNER)//cut off the beginning if its the owner field
                    result[i] = result[i].substring(result[i].length() - this.fieldLengths[i], this.fieldLengths[i]);
                else
                    result[i] = result[i].substring(0, this.fieldLengths[i]);
            } else {
                //strech it out if its too short
                while (result[i].length() < this.fieldLengths[i]) {
                    if (i == Record.OWNER) {//prepend zeros if its the owner field
                        result[i] = "0" + result[i];
                    } else {
                        result[i] = result[i] + " ";
                    }
                }
            }
        }
        return result;
    }

    /**
     * validates fields and sets new data into this record.
     * 
     * @param data
     *            the new data to set into this record
     * @see suncertify.db.Record#getData()
     * @see suncertify.db.Data#create(String[])
     * @see suncertify.db.Data#update(int, String[], long)
     */
    public void setData(String[] data) {
        this.data = validateFieldLengths(data);
    }

    /**
     * this record as an array of Strings
     * 
     * @return the array of fields set by Set(java.lang.String[])
     * @see suncertify.db.Record#setData(java.lang.String[])
     * @see suncertify.db.Data#create(String[])
     * @see suncertify.db.Data#read(int)
     */
    public String[] getData() {
        return this.data;
    }

    /**
     * reads a field from the file
     * 
     * @param raf
     *            the file to read from
     * @param maxlength
     *            the maximum length of this field
     * @return the field as it was in the file
     * @throws IOException
     *             if the field could not be read
     */
    private String read(RandomAccessFile raf, int maxlength) throws IOException {
        StringBuffer result = new StringBuffer();
        int curlength = 0;
        while (maxlength > curlength) {
            byte b = raf.readByte();
            if (b == 0) {
                raf.skipBytes(maxlength - curlength);//+/- 1?
                break;
            }
            result.append((char) b);
            curlength++;
        }
        return result.toString();
    }

    /**
     * saves a record to the datafile
     * 
     * @param raf
     *            the file to write to. pointer should already be set to proper location in datafile
     * @throws IOException
     *             if the record could not be saved
     * @see suncertify.db.Data#create(String[])
     * @see suncertify.db.Data#update(int, String[], long)
     *  
     */
    public void save(RandomAccessFile raf) throws IOException {
        raf.writeShort(this.deleted ? 0x8000 : 0);
        raf.writeBytes(this.data[NAME]);
        raf.writeBytes(this.data[LOCATION]);
        raf.writeBytes(this.data[SPECIALTIES]);
        raf.writeBytes(this.data[SIZE]);
        raf.writeBytes(this.data[RATE]);
        raf.writeBytes(this.data[OWNER]);
    }

    /**
     * does this record match to the criteria with startsWith().
     * 
     * @param criteria
     *            the search terms
     * @return true if matching, false if... not!
     * @see suncertify.db.Data#find(String[])
     */
    public boolean startsMatch(String[] criteria) {
        //a deleted record can obviously not be found
        if (this.deleted) {
            return false;
        }
        boolean match = false;
        for (int j = 0; j < criteria.length; j++) {
            //dont keep checking criteria if there are no more fields
            if (this.data.length <= j)
                break;
            //if this criteria is null, it matches this field. else they must match by startsWith
            if (criteria[j] == null || this.data[j].trim().startsWith(criteria[j])) {
                match = true;
            } else {
                match = false;
                break;
            }
        }
        return match;
    }

    /**
     * does this record match to the criteria with equals().
     * 
     * @param criteria
     *            the search terms
     * @return true if matching, false if... not!
     * @see suncertify.db.Data#exactFind(String[])
     */
    public boolean equalsMatch(String[] criteria) {
        //a deleted record can obviously not be found
        if (this.deleted) {
            return false;
        }
        boolean match = false;
        for (int j = 0; j < criteria.length; j++) {
            //dont keep checking criteria if there are no more fields
            if (this.data.length <= j)
                break;
            //if this criteria is null, it matches this field. else they must match by equals
            if (criteria[j] == null || this.data[j].trim().equals(criteria[j])) {
                match = true;
            } else {
                match = false;
                break;
            }
        }
        return match;
    }

}