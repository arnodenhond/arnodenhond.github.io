package eirstynufc.db;

import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Properties;

import javax.swing.JOptionPane;

import eirstynufc.client.ServerConfig;
import eirstynufc.networking.ColumnsRequest;
import eirstynufc.networking.FindRequest;
import eirstynufc.networking.LockRequest;
import eirstynufc.networking.ReadRequest;
import eirstynufc.networking.UnlockRequest;
import eirstynufc.networking.UpdateRequest;

/**
 * The remote version of RealDB. it is used by the GUI in client/server mode. sends requests to ClientHandler and passes results back to the gui. some methods wrap client/server errors into RecordNotFoundExceptions
 * 
 * @see suncertify.server.ClientHandler
 * 
 * @author Arno den Hond
 *  
 */
public class RemoteData implements RealDB {

    ObjectOutputStream oos;

    ObjectInputStream ois;

    /**
     * loads the server address and port number settings then sets up the connection and its streams. Terminates with errorlevel 88 if unable to connect to server
     *  
     */
    public RemoteData() {
        ServerConfig serverConfig = new ServerConfig();
        Properties props = new Properties();
        try {
            FileInputStream fis = new FileInputStream("suncertify.properties");
            props.load(fis);
            fis.close();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not load properties, using default server address and port number", JOptionPane.ERROR_MESSAGE);
        }
        String hostname = props.getProperty("hostname", "127.0.0.1");
        int portnumber = Integer.parseInt(props.getProperty("portnumber", "3688"));
        try {
            Socket s = new Socket(hostname, portnumber);
            this.oos = new ObjectOutputStream(s.getOutputStream());
            this.ois = new ObjectInputStream(s.getInputStream());
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Could not  connect to " + hostname + " on port " + portnumber, JOptionPane.ERROR_MESSAGE);
            System.out.println("Could not connect to " + hostname + " on port " + portnumber + ": " + ioe.toString());
            System.exit(88);
        }
    }

    /**
     * sends a ReadRequest to the server to read a record from the database.
     * 
     * @param recNo
     *            the record number of which to retreive the data
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @return the fields of the record
     * @see suncertify.networking.ReadRequest
     * @see suncertify.client.ResultTableModel#getValueAt(int, int)
     * @see suncertify.client.BookPanel#actionPerformed(ActionEvent)
     */
    public String[] lees(int recNo) throws RecordNotFoundException {
        try {
            this.oos.writeObject(new ReadRequest(recNo));
            Object o = this.ois.readObject();
            if (o instanceof String[]) {
                return (String[]) o;
            } else {
                if (o instanceof RecordNotFoundException) {
                    throw (RecordNotFoundException) o;
                }
            }
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Could not read record because: " + ioe.toString());
        } catch (ClassNotFoundException cnfe) {
            throw new RecordNotFoundException("Unexpected response from server: " + cnfe.toString());
        } catch (NullPointerException npe) {
            throw new RecordNotFoundException("Bad response from server: " + npe.toString());
        }
        throw new RecordNotFoundException("Could not read record");
    }

    /**
     * sends an UpdateRequest to the server to update a record in the database.
     * 
     * @param recNo
     *            the record number to be updated
     * @param data
     *            the actual data to place in the record
     * @param lockCookie
     *            the access code needed to update it
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @throws SecurityException
     *             if the lockCookie was invalid.
     * @see suncertify.networking.UpdateRequest
     * @see suncertify.client.BookPanel#actionPerformed(ActionEvent)
     */
    public void wijzig(int recNo, String[] data, long lockCookie) throws RecordNotFoundException, SecurityException {
        try {
            this.oos.writeObject(new UpdateRequest(recNo, data, lockCookie));
            Object o = this.ois.readObject();
            if (o instanceof Boolean) {
                if (!((Boolean) o).booleanValue()) {
                    throw new RecordNotFoundException("Server gracefully declined to update record");
                }
                return;
            } else {
                if (o instanceof RecordNotFoundException) {
                    throw (RecordNotFoundException) o;
                } else {
                    if (o instanceof SecurityException) {
                        throw (SecurityException) o;
                    }
                }
            }
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Error while communicating to server: " + ioe.toString());
        } catch (ClassNotFoundException cnfe) {
            throw new RecordNotFoundException("Unexpected response from server: " + cnfe.toString());
        } catch (NullPointerException npe) {
            throw new RecordNotFoundException("Bad response from server: " + npe.toString());
        }
        throw new RecordNotFoundException("Could not update record");
    }

    /**
     * this method should find records in the database matching the query by startsWith. this method is never called by the gui (it uses exactFind instead) so there is no implementation.
     * 
     * @param criteria
     *            the search query
     * @return record numbers of matching records when implemented. currently always returns an empty array of ints
     * @see suncertify.db.RemoteData#exactFind(java.lang.String[])
     */
    public int[] zoek(String[] criteria) {
        return new int[0];
    }

    /**
     * sends a FindRequest to the server to find records in the database matching the query exactly. shows a dialog if an error occurs.
     * 
     * @param criteria
     *            the search query
     * @return record numbers of matching records
     * @see suncertify.networking.FindRequest
     * @see suncertify.client.SearchPanel#actionPerformed(ActionEvent)
     */
    public int[] exactFind(String[] criteria) {
        try {
            this.oos.writeObject(new FindRequest(criteria));
            return (int[]) this.ois.readObject();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Error while communicating to server", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(null, cnfe.toString(), "Unexpected response from server", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException npe) {
            JOptionPane.showMessageDialog(null, npe.toString(), "Bad response from server", JOptionPane.ERROR_MESSAGE);
        }//show dialogs here because this method does not throw exceptions
        return new int[0];
    }

    /**
     * sends a ColumnsRequest to the server to get the names of the fields specified in the header of the datafile. shows a dialog if an error occurs.
     * 
     * @return the names of the fields specified in the header of the datafile.
     * @see suncertify.networking.ColumnsRequest
     * @see suncertify.client.ResultTableModel#getColumnCount()
     * @see suncertify.client.ResultTableModel#getColumnName(int)
     */
    public String[] getColumns() {
        try {
            this.oos.writeObject(new ColumnsRequest());
            return (String[]) this.ois.readObject();
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(null, ioe.toString(), "Error while communicating to server", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(null, cnfe.toString(), "Unexpected response from server", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException npe) {
            JOptionPane.showMessageDialog(null, npe.toString(), "Bad response from server", JOptionPane.ERROR_MESSAGE);
        }//show dialogs here because this method does not throw exceptions
        return new String[0];
    }

    /**
     * sends a LockRequest to the server to lock a record in the database.
     * 
     * @param recNo
     *            the record to lock
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @return the access code needed to update, delete or unlock this record
     * @see suncertify.networking.LockRequest
     * @see suncertify.client.BookPanel#actionPerformed(ActionEvent)
     */
    public long vergrendel(int recNo) throws RecordNotFoundException {
        try {
            this.oos.writeObject(new LockRequest(recNo));
            Object o = this.ois.readObject();
            if (o instanceof Long) {
                if (((Long) o).longValue() < 0) {
                    throw new RecordNotFoundException("Server returned invalid lockcookie");
                }
                return ((Long) o).longValue();
            } else {
                if (o instanceof RecordNotFoundException) {
                    throw (RecordNotFoundException) o;
                }
            }
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Error while communicating to server: " + ioe.toString());
        } catch (ClassNotFoundException cnfe) {
            throw new RecordNotFoundException("Unexpected response from server: " + cnfe.toString());
        } catch (NullPointerException npe) {
            throw new RecordNotFoundException("Bad response from server: " + npe.toString());
        }
        throw new RecordNotFoundException("Could not lock record");
    }

    /**
     * sends an UnlockRequest to the server to unlock a record in the database.
     * 
     * @param recNo
     *            the record to unlock
     * @param cookie
     *            the access code needed to unlock it
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @throws SecurityException
     *             if the lockCookie was invalid.
     * @see suncertify.networking.UnlockRequest
     * @see suncertify.client.BookPanel#actionPerformed(ActionEvent)
     */
    public void ontgrendel(int recNo, long cookie) throws RecordNotFoundException, SecurityException {
        try {
            this.oos.writeObject(new UnlockRequest(recNo, cookie));
            Object o = this.ois.readObject();
            if (o instanceof Boolean) {
                if (!((Boolean) o).booleanValue()) {
                    throw new RecordNotFoundException("Server gracefully declined to unlock record");
                }
                return;
            } else {
                if (o instanceof RecordNotFoundException) {
                    throw (RecordNotFoundException) o;
                } else {
                    if (o instanceof SecurityException) {
                        throw (SecurityException) o;
                    }
                }
            }
        } catch (IOException ioe) {
            throw new RecordNotFoundException("Error while communicating to server: " + ioe.toString());
        } catch (ClassNotFoundException cnfe) {
            throw new RecordNotFoundException("Unexpected response from server: " + cnfe.toString());
        } catch (NullPointerException npe) {
            throw new RecordNotFoundException("Bad response from server: " + npe.toString());
        }
        throw new RecordNotFoundException("Could not unlock record");
    }

    /**
     * this method should delete a record in the database. this method is never called from the gui so there is no implementation
     * 
     * @param recNo
     *            the record to delete
     * @param lockCookie
     *            the accesscode needed to delete it
     * @throws RecordNotFoundException
     *             if the recNo was invalid or if the record was deleted.
     * @throws SecurityException
     *             if the lockCookie was invalid.
     */
    public void verwijder(int recNo, long lockCookie) throws RecordNotFoundException, SecurityException {
        throw new RecordNotFoundException("Could not delete record. Method not implemented.");
    }

    /**
     * this method should create a record in the database. this method is never called from the gui so there is no implementation
     * 
     * @param data
     *            the data to place in the new record
     * @throws DuplicateKeyException
     *             if the database already contains a non-deleted record with the same name and location as the new record.
     * @return the record number of the new record
     */
    public int maak(String[] data) throws DuplicateKeyException {
        throw new DuplicateKeyException("Could not create record. Method not implemented.");
    }

}