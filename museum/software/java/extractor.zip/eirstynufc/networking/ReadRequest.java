package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.RecordNotFoundException;

/**
 * 
 * A serializable class represeting a call to lees. it holds the number of the record to lees. This class looks like LockRequest but is a different class because if it wasnt the server wouldnt be able to distinguish between the two. So actually this class not only stores the record number but also tells the server what to do with the number.
 * 
 * 
 * @author Arno den Hond
 */
public class ReadRequest implements Request, Serializable {

    private int recNo;

    /**
     * this constructor sets up the request
     * 
     * 
     * @param recNo
     *            the record number to lees
     */
    public ReadRequest(int recNo) {
        this.recNo = recNo;
    }

    /**
     * calls the lees method on the specified database
     * 
     * 
     * @param data
     *            the database to call the lees method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * @return the record as a leesng array
     * @see suncertify.db.DB#read(int)
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        try {
            return data.lees(this.recNo);
        } catch (RecordNotFoundException rnfe) {
            logTextArea.insert(name + ": " + rnfe.toString() + "\n", 0);
            return rnfe;
        }
    }

    /**
     * returns this request as a string
     * 
     * @return "ReadRequest for record" followed by the record number
     */
    public String toString() {
        return "ReadRequest for record " + this.recNo;
    }

}