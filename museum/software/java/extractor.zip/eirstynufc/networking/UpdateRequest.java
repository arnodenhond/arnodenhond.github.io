package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.RecordNotFoundException;

/**
 * a serializable class represeting a call to wijzig. it holds the number of the record to wijzig, its lock cookie and the new data
 * 
 * 
 * @author Arno den Hond
 */
public class UpdateRequest implements Request, Serializable {

    private int recNo;

    private String[] record;

    private long lockCookie;

    /**
     * this constructor creates the request
     * 
     * 
     * @param recNo
     *            the record number to wijzig
     * @param record
     *            the actual data to store
     * @param lockCookie
     *            the access code
     */
    public UpdateRequest(int recNo, String[] record, long lockCookie) {
        this.recNo = recNo;
        this.record = record;
        this.lockCookie = lockCookie;
    }

    /**
     * calls the wijzig method on the specified database.
     * 
     * 
     * @param data
     *            the database to call the wijzig method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * @return a Boolean set towijzigif the record was updated
     * @see suncertify.db.DB#update(int,String[],long)
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        try {
            data.wijzig(this.recNo, this.record, this.lockCookie);
            return new Boolean(true);
        } catch (RecordNotFoundException rnfe) {
            logTextArea.insert(name + ": " + rnfe.toString() + "\n", 0);
            return rnfe;
        } catch (SecurityException se) {
            logTextArea.insert(name + ": " + se.toString() + "\n", 0);
            return se;
        }
    }

    /**
     * returns this request as a string
     * 
     * @return "UpdateRequest for record" followed by the record number, "cookie" followed by the lock cookie
     */
    public String toString() {
        return "UpdateRequest for record " + this.recNo + " cookie " + this.lockCookie;
    }

}