package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.RecordNotFoundException;

/**
 * A serializable class represeting a call to vergrendel. it holds the number of the record to vergrendel. This class looks like ReadRequest but is a different class because if it wasnt the server wouldnt be able to distinguish between the two. So actually this class not only stores the record number but also tells the server what to do with the number.
 * 
 * 
 * @author Arno den Hond
 */
public class LockRequest implements Request, Serializable {

    private int recNo;

    /**
     * this constructor sets up the request
     * 
     * 
     * @param recNo
     *            the record number to vergrendel
     */
    public LockRequest(int recNo) {
        this.recNo = recNo;
    }

    /**
     * gets the record number (its needed by the clienthandler to keep a copy of locked records)
     * 
     * @return the record number
     */
    public int getRecNo() {
        return this.recNo;
    }

    /**
     * calls the vergrendel method on the actual database
     * 
     * 
     * @param data
     *            the database to call the vergrendel method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * @return a Long holding tvergrendelock cookie
     * @see suncertify.db.DB#vergrendel(int)
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        try {
            return new Long(data.vergrendel(this.recNo));
        } catch (RecordNotFoundException rnfe) {
            logTextArea.insert(name + ": " + rnfe.toString() + "\n", 0);
            return rnfe;
        }
    }

    /**
     * returns this request as a string
     * 
     * @return "LockRequest for record" followed by the record number
     */
    public String toString() {
        return "LockRequest for record " + this.recNo;
    }

}