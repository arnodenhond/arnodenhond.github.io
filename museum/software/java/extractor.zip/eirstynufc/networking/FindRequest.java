package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.Record;

/**
 * a serializable class represeting a call to exactFind. it holds the search criteria. there is no request for the normal find method since it is never used by the client
 * 
 * @author Arno den Hond
 *  
 */
public class FindRequest implements Request, Serializable {

    private String[] criteria;

    /**
     * this constructor sets up the request
     * 
     * @param criteria
     *            the search term(s)
     */
    public FindRequest(String[] criteria) {
        this.criteria = criteria;
    }

    /**
     * calls the find method on the specified database
     * 
     * @param data
     *            the database to call the find method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * 
     * @see suncertify.db.RealDB#exactFind(java.lang.String[])
     * @return an array of ints holding numbers of records matching search query
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        return data.exactFind(this.criteria);
    }

    /**
     * returns this request as a string
     * 
     * @return "FindRequest" followed by name and/or location, if specified.
     */
    public String toString() {
        String name = new String();
        if (this.criteria[Record.NAME] != null && this.criteria[Record.NAME].trim().equals("")) {
            name = " Name \"" + this.criteria[Record.NAME] + "\"";
        }
        String location = new String();
        if (this.criteria[Record.LOCATION] != null && this.criteria[Record.LOCATION].trim().equals("")) {
            name = " Location \"" + this.criteria[Record.LOCATION] + "\"";
        }
        return "FindRequest" + name + location;
    }

}