package eirstynufc.networking;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;

/**
 * this interface defines what methods any request sent by remotedata should have and is used by clienthandler to treat all request equally
 * 
 * @author Arno den Hond
 * 
 * @see suncertify.db.RemoteData
 * @see suncertify.server.ClientHandler
 */
public interface Request {

    /**
     * execute this request on the server
     * 
     * @param data
     *            the database to execute this request on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * 
     * @return whatever result the database gave
     * @see suncertify.server.ClientHandler#run()
     *  
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea);

    /**
     * show this exception as a string on the server log
     * 
     * @return this exception as a string
     * @see suncertify.server.ClientHandler#run()
     */
    public String toString();

}