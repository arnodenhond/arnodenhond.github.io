package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;
import eirstynufc.db.RecordNotFoundException;

/**
 * a serializable class represeting a call to ontgrendel. it holds the number of the record to ontgrendel and its lock cookie
 * 
 * 
 * @author Arno den Hond
 */
public class UnlockRequest implements Request, Serializable {

    private int recNo;

    private long lockCookie;

    /**
     * this constructor sets up the request
     * 
     * 
     * @param recNo
     *            the record number to ontgrendel
     * @param lockCookie
     *            the access code needed to ontgrendel it
     */
    public UnlockRequest(int recNo, long lockCookie) {
        this.recNo = recNo;
        this.lockCookie = lockCookie;
    }

    /**
     * calls the ontgrendel method on the specified database
     * 
     * 
     * @param data
     *            the database to call the ontgrendel method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * @return a Boolean set toontgrendelif the record was unlocked
     * @see suncertify.db.DB#unlock(int,long)
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        try {
            data.ontgrendel(this.recNo, this.lockCookie);
            return new Boolean(true);
        } catch (RecordNotFoundException rnfe) {
            logTextArea.insert(name + ": " + rnfe.toString() + "\n", 0);
            return rnfe;
        } catch (SecurityException se) {
            logTextArea.insert(name + ": " + se.toString() + "\n", 0);
            return se;
        }
    }

    /**
     * returns this request as a string
     * 
     * @return "UnlockRequest for record" followed by the record number, "cookie" followed by the lock cookie
     */
    public String toString() {
        return "UnlockRequest for record " + this.recNo + " cookie " + this.lockCookie;
    }

}