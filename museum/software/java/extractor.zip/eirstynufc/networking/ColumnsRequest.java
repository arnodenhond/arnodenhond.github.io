package eirstynufc.networking;

import java.io.Serializable;

import javax.swing.JTextArea;

import eirstynufc.db.RealDB;

/**
 * a serializable class representing a request for an array of column names
 * 
 * @author Arno den Hond
 *  
 */
public class ColumnsRequest implements Request, Serializable {

    /**
     * calls the getColumns method on the specified database
     * 
     * @param data
     *            the database to call the getColumns method on
     * @param name
     *            the title to append to any log messages
     * @param logTextArea
     *            the JTextArea to show any log messages on
     * 
     * @see suncertify.db.RealDB#getColumns()
     * @return an array of strings holding the column names
     */
    public Object execute(RealDB data, String name, JTextArea logTextArea) {
        return data.getColumns();
    }

    /**
     * returns this request as a string
     * 
     * @return "Columns request"
     */
    public String toString() {
        return "Columns request";
    }

}