import java.net.*;
import java.io.*;

/**
 * A toolkit for communicating with a ZodQueryLanguage-Server
 * @author noBSoft
 * @version 1.0
 */
public class ZQLClient
{

  Socket socket;
  DataInputStream dis;
  DataOutputStream dos;
  StringList keywordBuffer;
  StringList dataBuffer;

/**
 * Connect to the ZQL-Server
 * @param host  the internet address where the server is running
 * @param port  the port number on which the server is listening
 * @exception Exception if the connection to the server is lost
 */
  public ZQLClient(String host, int port, boolean useBuffer) throws Exception
  {
    socket = new Socket(host,port);
    dis = new DataInputStream(socket.getInputStream());
    dos = new DataOutputStream(socket.getOutputStream());
    if (useBuffer)
    {
      keywordBuffer = new StringList();
      dataBuffer = new StringList();
    }
  }
/**
 * Close connection to ZQL-Server
 * @exception Exception if the connection to the server is lost
 */
  public void finalize() throws Exception
  {
    dis.close();
    dos.close();
    socket.close();
  }

/**
 * Add a new keyword to database
 * @param keyword the name of the new keyword
 * @return the index of the new keyword
 * @exception Exception if the connection to the server is lost
 */
  public int addKeyword(String keyword) throws Exception
  {
    dos.writeByte(0);
    dos.writeUTF(keyword);
    int index = dis.readInt();
    if (keywordBuffer!=null)
      keywordBuffer.set(index,keyword);
    return index;
  }

/**
 * Add a new data to database
 * @param data the content of the new data
 * @param keyword_ids indexes of keywords linked to the new data
 * @return the index of the new data
 * @exception Exception if the connection to the server is lost
 */
  public int addData(String data, int[] keyword_ids) throws Exception
  {
    dos.writeByte(1);
    dos.writeUTF(data);
    dos.writeInt(keyword_ids.length);
    for (int i = 0; i < keyword_ids.length; i++)
      dos.writeInt(keyword_ids[i]);
    int index = dis.readInt();
    if (dataBuffer!=null)
      dataBuffer.set(index,data);
    return index;
  }

/**
 * Remove a keyword from database
 * @param keyword_id index of the keyword to be removed
 * @return true
 * @exception Exception if the connection to the server is lost
 */
  public boolean delKeyword(int keyword_id) throws Exception
  {
    dos.writeByte(2);
    dos.writeInt(keyword_id);
    if (keywordBuffer!=null)
      keywordBuffer.set(keyword_id,null);
    return dis.readBoolean();
  }

/**
 * Remove a data from database
 * @param data_id index of the data to be removed
 * @return true
 * @exception Exception if the connection to the server is lost
 */
  public boolean delData(int data_id) throws Exception
  {
    dos.writeByte(3);
    dos.writeInt(data_id);
    if (keywordBuffer!=null)
      dataBuffer.set(data_id,null);
    return dis.readBoolean();
  }

/**
 * List keywords associated to keyword_ids
 * @param keyword_ids the search query, if empty all keywords are returned
 * @param average average/total score calculation method (read documentation), if keyword_ids is empty, it becomes aplhabetically/popularity result sorting
 * @param result_length maximum amount of results returned, all if 0
 * @return an array of indexes to keywords
 * @exception Exception if the connection to the server is lost
 */
  public int[] listKeywords(int[] keyword_ids, boolean average, int result_length) throws Exception
  {
    dos.writeByte(4);
    dos.writeInt(keyword_ids.length);
    for (int i = 0; i < keyword_ids.length; i++)
      dos.writeInt(keyword_ids[i]);
    dos.writeBoolean(average);
    dos.writeInt(result_length);
    int[] resultkeyword_ids = new int[dis.readInt()];
    for (int i = 0; i < resultkeyword_ids.length; i++)
      resultkeyword_ids[i] = dis.readInt();
    return resultkeyword_ids;
  }

/**
 * List datas associated to keyword_ids
 * @param keyword_ids the search query
 * @param result_length maximum amount of results returned, all if 0
 * @return an array of indexes to datas
 * @exception Exception if the connection to the server is lost
 */
  public int[] listDatas(int[] keyword_ids, int result_length) throws Exception
  {
    dos.writeByte(5);
    dos.writeInt(keyword_ids.length);
    for (int i = 0; i < keyword_ids.length; i++)
      dos.writeInt(keyword_ids[i]);
    dos.writeInt(result_length);
    int[] data_ids = new int[dis.readInt()];
    for (int i = 0; i < data_ids.length; i++)
      data_ids[i] = dis.readInt();
    return data_ids;
  }

/**
 * List keywords linked to data_id
 * @param data_id the search query
 * @return an array of indexes to keywords
 * @exception Exception if the connection to the server is lost
 */
  public int[] listDataKeywords(int data_id) throws Exception
  {
    dos.writeByte(6);
    dos.writeInt(data_id);
    int[] keyword_ids = new int[dis.readInt()];
    for (int i = 0; i < keyword_ids.length; i++)
      keyword_ids[i] = dis.readInt();
    return keyword_ids;
  }

/**
 * get the name of a keyword
 * @param keyword_id the search query
 * @return the name of the keyword
 * @exception Exception if the connection to the server is lost
 */
  public String getKeyword(int keyword_id) throws Exception
  {
    if (keywordBuffer!=null && keywordBuffer.get(keyword_id)!=null)
      return keywordBuffer.array[keyword_id];
    dos.writeByte(7);
    dos.writeInt(keyword_id);
    String result = dis.readUTF();
    if (keywordBuffer!=null)
      keywordBuffer.set(keyword_id,result);
    return result;
  }

/**
 * get the content of a data
 * @param data_id the search query
 * @return the content of the data
 * @exception Exception if the connection to the server is lost
 */
  public String getData(int data_id) throws Exception
  {
    if (dataBuffer!=null && dataBuffer.get(data_id)!=null)
      return dataBuffer.array[data_id];
    dos.writeByte(8);
    dos.writeInt(data_id);
    String result = dis.readUTF();
    if (dataBuffer!=null)
      dataBuffer.set(data_id,result);
    return result;
  }

/**
 * search for a keyword
 * @param keyword the search query
 * @return an array of indexes to keywords containing the search query
 * @exception Exception if the connection to the server is lost
 */
  public int[] searchKeyword(String keyword) throws Exception
  {
    dos.writeByte(9);
    dos.writeUTF(keyword);
    int[] keyword_ids = new int[dis.readInt()];
    for (int i = 0; i < keyword_ids.length; i++)
      keyword_ids[i] = dis.readInt();
    return keyword_ids;
  }

}
