class StringList
{

  String[] array;

  StringList()
  {
    array = new String[0];
  }

  String get(int index)
  {
    if (array.length>index)
      return array[index];
    else
      return null;
  }

  void set(int index, String string)
  {
    if (array.length<=index)
    {
      String[] newarray = new String[index+1];
      System.arraycopy(array,0,newarray,0,array.length);
      array=newarray;
    }
    array[index]=string;
  }

}