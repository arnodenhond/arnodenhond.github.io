import java.io.*;
import java.util.*;

class AdminTool
{

  static String helpScreen()
  {
    String result = new String();
    result+="ZQL-TestClient v1.0 \n";
    result+=" \n";
    result+="addkeyword <keyword> \n";
    result+="adddata <data>,<keyword_id>,<keyword_id> \n";
    result+="delkeyword <keyword_id> \n";
    result+="deldata <data_id> \n";
    result+="getdata <data_id> \n";
    result+="getkeyword <keyword_id> \n";
    result+="listkeywords <average>,<result_length>,<keyword_id>,<keyword_id> \n";
    result+="listdatas <result_length>,<keyword_id>,<keyword_id> \n";
    result+="listdatakeywords <data_id> \n";
    result+="searchkeyword <query> \n";
    result+="getdb <filename> \n";
    result+="putdb <filename> \n";
    result+="help \n";
    result+="quit \n";
    result+=" \n";
    return result;
  }

  public static void main(String args[]) throws Exception
  {
    ZQLClient zql = new ZQLClient("localhost",3688,false);
    System.out.println("connected");
    System.out.println(helpScreen());
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String line = new String();
    while (!line.equals("quit"))
    {
      System.out.print("> ");
      line = br.readLine();
      if (line.equals("help"))
        System.out.println(helpScreen());
      if (line.indexOf(" ")==-1)
        continue;
      StringTokenizer st = new StringTokenizer(line);
      String cmd = st.nextToken();
      if (cmd.equals("addkeyword"))
        System.out.println("keyword #"+zql.addKeyword(st.nextToken())+" added");
      if (cmd.equals("adddata"))
      {
        String data = st.nextToken(",");
        data = data.substring(1);
        int[] keywords = new int[st.countTokens()];
        for (int i = 0; i < keywords.length; i++)
          keywords[i]=new Integer(st.nextToken()).intValue();
        System.out.println("data #"+zql.addData(data,keywords)+" added");
      }
      if (cmd.equals("delkeyword"))
        System.out.println(zql.delKeyword(new Integer(st.nextToken()).intValue())?"keyword deleted":"failed");
      if (cmd.equals("deldata"))
        System.out.println(zql.delData(new Integer(st.nextToken()).intValue())?"data deleted":"failed");
      if (cmd.equals("getkeyword"))
        System.out.println(zql.getKeyword(new Integer(st.nextToken()).intValue()));
      if (cmd.equals("getdata"))
        System.out.println(zql.getData(new Integer(st.nextToken()).intValue()));
      if (cmd.equals("listkeywords"))
      {
        boolean average = st.nextToken(",").equals(" true");
        int result_length = new Integer(st.nextToken()).intValue();
        int[] keywords = new int[st.countTokens()];
        for (int i = 0; i < keywords.length; i++)
          keywords[i]=new Integer(st.nextToken()).intValue();
        keywords = zql.listKeywords(keywords,average,result_length);
        if (keywords.length>0)
          for (int i = 0; i < keywords.length; i++)
            System.out.println(keywords[i]);
        else
          System.out.println("no results");
      }
      if (cmd.equals("listdatas"))
      {
        String s =st.nextToken(",");
        s=s.substring(1,s.length());
        int result_length = new Integer(s).intValue();
        int[] keywords = new int[st.countTokens()];
        for (int i = 0; i < keywords.length; i++)
          keywords[i]=new Integer(st.nextToken()).intValue();
        int[] datas = zql.listDatas(keywords,result_length);
        if (datas.length>0)
          for (int i = 0; i < datas.length; i++)
            System.out.println(datas[i]);
        else
          System.out.println("no results");
      }
      if (cmd.equals("listdatakeywords"))
      {
        int[] keywords = zql.listDataKeywords(new Integer(st.nextToken()).intValue());
        if (keywords.length>0)
          for (int i = 0; i < keywords.length; i++)
            System.out.println(keywords[i]);
        else
          System.out.println("no results");
      }
      if (cmd.equals("searchkeyword"))
      {
        int[] keywords = zql.searchKeyword(st.nextToken());
        if (keywords.length>0)
          for (int i = 0; i < keywords.length; i++)
            System.out.println(keywords[i]);
        else
          System.out.println("no results");
      }
      if (cmd.equals("getdb"))
      {
        String filename = st.nextToken();
        filename = filename.substring(1);
        System.out.println("database saved to "+filename);
      }
      if (cmd.equals("putdb"))
      {
        //clear current db
      }
    }
  }

}