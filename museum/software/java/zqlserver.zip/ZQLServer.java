import java.io.*;
import java.net.*;
/**
 * ZodQueryLanguage server
 * <BR>
 * no information about this program is given. just use ZQLClient to connect to it.
 * @see ZQLClient
 * @author noBSoft
 * @version 1.0
 */
class ZQLServer extends Thread
{

  Socket socket;
  ASS ass;

  ZQLServer(Socket socket, ASS ass)
  {
    this.socket = socket;
    this.ass = ass;
  }

  public void run()
  {
    try
    {
      System.out.println("connected");
      DataInputStream dis = new DataInputStream(socket.getInputStream());
      DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
      while (true)
      {
        switch (dis.readByte())
        {
          case 0:
          {
            System.out.println("adding keyword");
            Keyword k = ass.addKeyword(dis.readUTF());
            dos.writeInt(ass.keywords.indexOf(k));
            break;
          }
          case 1:
          {
            System.out.println("adding data");
            String data = dis.readUTF();
            KeywordList kl = new KeywordList();
            int length = dis.readInt();
            for (int i = 0; i < length; i++)
            {
              int index = dis.readInt();
              if (ass.keywords.array.length > index && ass.keywords.array[index] != null)
                kl.add(ass.keywords.array[index]);
            }
            Data d = ass.addData(data,kl);
            dos.writeInt(ass.datas.indexOf(d));
            break;
          }
          case 2:
          {
            System.out.println("deleting keyword");
            int index = dis.readInt();
            if (ass.keywords.array.length > index)
              dos.writeBoolean(ass.delKeyword(ass.keywords.array[index]));
            else
              dos.writeBoolean(false);
            break;
          }
          case 3:
          {
            System.out.println("deleting data");
            int index = dis.readInt();
            if (ass.datas.array.length > index)
              dos.writeBoolean(ass.delData(ass.datas.array[index]));
            else
              dos.writeBoolean(false);
            break;
          }
          case 4:
          {
            System.out.println("getting keyword results");
            int length = dis.readInt();
            KeywordList kl = new KeywordList();
            for (int i = 0; i < length; i++)
            {
              int index = dis.readInt();
              if (ass.keywords.array.length > index && ass.keywords.array[index] != null)
                kl.add(ass.keywords.array[index]);
            }
            boolean average = dis.readBoolean();
            KeywordList result = ass.listKeywordResults(kl,average);
            int result_length = dis.readInt();
            if (result.array.length<result_length | result_length==0)
              result_length=result.array.length;
            dos.writeInt(result_length);
            for (int i = 0; i < result_length; i++)
              dos.writeInt(ass.keywords.indexOf(result.array[i]));
            break;
          }
          case 5:
          {
            System.out.println("getting data results");
            int length = dis.readInt();
            KeywordList kl = new KeywordList();
            for (int i = 0; i < length; i++)
            {
              int index = dis.readInt();
              if (ass.keywords.array.length > index && ass.keywords.array[index] != null)
                kl.add(ass.keywords.array[index]);
            }
            DataList result = ass.listDataResults(kl);
            int result_length = dis.readInt();
            if (result.array.length<result_length | result_length==0)
              result_length=result.array.length;
            dos.writeInt(result_length);
            for (int i = 0; i < result_length; i++)
              dos.writeInt(ass.datas.indexOf(result.array[i]));
            break;
          }
          case 6:
          {
            System.out.println("getting data keywords");
            int index = dis.readInt();
            if (ass.datas.array.length > index && ass.datas.array[index] != null)
            {
              Data data = ass.datas.array[index];
              dos.writeInt(data.keywords.array.length);
              for (int i = 0; i < data.keywords.array.length; i++)
                dos.writeInt(ass.keywords.indexOf(data.keywords.array[i]));
            }
            else
              dos.writeInt(0);
            break;
          }
          case 7:
          {
            System.out.println("getting keyword");
            int index = dis.readInt();
            if (ass.keywords.array.length > index && ass.keywords.array[index] != null)
              dos.writeUTF(ass.keywords.array[index].keyword);
            else
              dos.writeUTF("");
            break;
          }
          case 8:
          {
            System.out.println("getting data");
            int index = dis.readInt();
            if (ass.datas.array.length > index && ass.datas.array[index] != null)
              dos.writeUTF(ass.datas.array[index].data);
            else
              dos.writeUTF("");
            break;
          }
          case 9:
          {
            System.out.println("searching keyword");
            KeywordList kl = ass.searchKeyword(dis.readUTF());
            dos.writeInt(kl.array.length);
            for (int i = 0; i < kl.array.length; i++)
              dos.writeInt(ass.keywords.indexOf(kl.array[i]));
            break;
          }
        }
        dos.flush();
      }
    }
    catch (Exception e)
    {
      System.out.println(e.toString());
      e.printStackTrace(System.out);
    }
  }

  public static void main(String[] args) throws Exception
  {
    String assfile;
    if (args.length>0)
      assfile = args[0];
    else
      assfile = "ass1.db";
    int port = 3688;
    System.out.println("Starting up ZQL-Server v1.0 {noBSoft}");
    System.out.println("loading ASS "+assfile);
    ASS ass = new ASS(assfile);
    System.out.println("opening port "+port);
    ServerSocket ss = new ServerSocket(port);
    Socket socket = null;
    while (true)
      new ZQLServer(ss.accept(), ass).start();
  }

}

