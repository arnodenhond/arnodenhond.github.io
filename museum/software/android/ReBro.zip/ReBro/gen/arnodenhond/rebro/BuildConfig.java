/** Automatically generated file. DO NOT MODIFY */
package arnodenhond.rebro;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}