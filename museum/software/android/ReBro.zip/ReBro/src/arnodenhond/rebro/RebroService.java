package arnodenhond.rebro;

import java.util.ArrayList;
import java.util.List;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.Parcel;

import com.samsung.chord.ChordManager;
import com.samsung.chord.IChordChannel;
import com.samsung.chord.IChordChannelListener;
import com.samsung.chord.IChordManagerListener;

public class RebroService extends Service {

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	public int onStartCommand(Intent intent, int flags, int startId) {
		handleIntent(intent);
		return START_STICKY;
	}

	NotificationManager mNM;

	@Override
	public void onCreate() {
		mNM = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Notification notif = new Notification(R.drawable.ic_launcher,
				"service running", System.currentTimeMillis());
		notif.setLatestEventInfo(this, "service started", "service started",
				null);
		mNM.notify(3688, notif);
	}

	@Override
	public void onDestroy() {
		mNM.cancel(3688);
		for (BroadcastReceiver receiver : receivers) {
			unregisterReceiver(receiver);
		}
	}

	private ArrayList<IntentFilter> scanReceivers() {
		ArrayList<IntentFilter> result = new ArrayList<IntentFilter>();
		PackageManager pm = getPackageManager();
		List<PackageInfo> packages = pm
				.getInstalledPackages(PackageManager.GET_META_DATA);
		for (PackageInfo packageInfo : packages) {
			if (packageInfo.applicationInfo.metaData == null)
				continue;
			String action = packageInfo.applicationInfo.metaData
					.getString("rebro");
			if (action == null)
				continue;
			result.add(new IntentFilter(action));
		}
		return result;
	}

	ArrayList<BroadcastReceiver> receivers = new ArrayList<BroadcastReceiver>();
	ChordManager mChordManager;
	IChordChannel channel;

	protected void handleIntent(Intent intent) {
		NotificationManager mgr = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		mChordManager = ChordManager.getInstance(this);
		mChordManager.setHandleEventLooper(getMainLooper());
		List<Integer> interfaceList = mChordManager
				.getAvailableInterfaceTypes();
		if (interfaceList.isEmpty()) {
			// There is no connection.
			return;
		}

		int nError = mChordManager.start(interfaceList.get(0).intValue(),
				mManagerListener);

		for (IntentFilter filter : scanReceivers()) {
			BroadcastReceiver receiver = new BroadcastReceiver() {
				@Override
				public void onReceive(Context context, Intent intent) {
					if (intent.getExtras().containsKey("fromRebro")) {
						// dont receive rebroadcasts
						return;
					}
					String action = intent.getAction();
					Parcel parcel = Parcel.obtain();
					intent.getExtras().writeToParcel(parcel, 0);
					//parcel.writeBundle(intent.getExtras());
					parcel.marshall();
					byte[][] data = new byte[2][];
					data[0] = action.getBytes();
					data[1] = parcel.marshall();
					channel.sendDataToAll("rebro", data);
					parcel.recycle();
				}
			};
			registerReceiver(receiver, filter);
		}

	}

	private IChordManagerListener mManagerListener = new IChordManagerListener() {
		@Override
		public void onStarted(String name, int reason) {
			if (STARTED_BY_USER == reason) {

				channel = mChordManager.joinChannel("rebro", mChannelListener);
			}
		}

		@Override
		public void onStopped(int reason) {
		}

		@Override
		public void onError(int arg0) {
		}

		@Override
		public void onNetworkDisconnected() {
		};

	};

	private IChordChannelListener mChannelListener = new IChordChannelListener() {

		@Override
		public void onDataReceived(String arg0, String arg1, String arg2,
				byte[][] arg3) {
			// TODO only broadcast if the intent is also sent from here
			Intent intent = new Intent(new String(arg3[0]));
			Parcel parcel = Parcel.obtain();
			String extras = new String(arg3[1]);
			parcel.unmarshall(arg3[1], 0, arg3[1].length);
			parcel.setDataPosition(0);
			intent.putExtras(parcel.readBundle());
			intent.putExtra("fromRebro", true);
			sendBroadcast(intent);
		}

		@Override
		public void onFileChunkReceived(String arg0, String arg1, String arg2,
				String arg3, String arg4, String arg5, long arg6, long arg7) {
		}

		@Override
		public void onFileChunkSent(String arg0, String arg1, String arg2,
				String arg3, String arg4, String arg5, long arg6, long arg7,
				long arg8) {
		}

		@Override
		public void onFileFailed(String arg0, String arg1, String arg2,
				String arg3, String arg4, int arg5) {
		}

		@Override
		public void onFileReceived(String arg0, String arg1, String arg2,
				String arg3, String arg4, String arg5, long arg6, String arg7) {
		}

		@Override
		public void onFileSent(String arg0, String arg1, String arg2,
				String arg3, String arg4, String arg5) {
		}

		@Override
		public void onFileWillReceive(String arg0, String arg1, String arg2,
				String arg3, String arg4, String arg5, long arg6) {
		}

		@Override
		public void onMultiFilesChunkReceived(String arg0, String arg1,
				String arg2, String arg3, int arg4, String arg5, long arg6,
				long arg7) {
		}

		@Override
		public void onMultiFilesChunkSent(String arg0, String arg1,
				String arg2, String arg3, int arg4, String arg5, long arg6,
				long arg7, long arg8) {
		}

		@Override
		public void onMultiFilesFailed(String arg0, String arg1, String arg2,
				String arg3, int arg4, int arg5) {
		}

		@Override
		public void onMultiFilesFinished(String arg0, String arg1, String arg2,
				int arg3) {
		}

		@Override
		public void onMultiFilesReceived(String arg0, String arg1, String arg2,
				String arg3, int arg4, String arg5, long arg6, String arg7) {
		}

		@Override
		public void onMultiFilesSent(String arg0, String arg1, String arg2,
				String arg3, int arg4, String arg5) {
		}

		@Override
		public void onMultiFilesWillReceive(String arg0, String arg1,
				String arg2, String arg3, int arg4, String arg5, long arg6) {
		}

		@Override
		public void onNodeJoined(String arg0, String arg1) {
		}

		@Override
		public void onNodeLeft(String arg0, String arg1) {
		}

	};
}
