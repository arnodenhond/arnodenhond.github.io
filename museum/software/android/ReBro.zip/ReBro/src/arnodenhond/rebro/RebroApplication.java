package arnodenhond.rebro;

import android.app.Application;
import android.content.Intent;

public class RebroApplication extends Application {
	public void onCreate() {
		super.onCreate(); 
		Intent intent = new Intent(this, RebroService.class);
		startService(intent);
	};
}
