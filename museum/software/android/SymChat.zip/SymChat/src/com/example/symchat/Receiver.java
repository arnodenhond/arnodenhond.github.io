package com.example.symchat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class Receiver extends BroadcastReceiver {

	public static final String FROM = "from";
	public static final String MESSAGE = "message";
	
	@Override
	public void onReceive(Context context, Intent intent) {
		String from = intent.getStringExtra(FROM);
		String message = intent.getStringExtra(MESSAGE);
		
		SymChat symChat = (SymChat) context.getApplicationContext();
		symChat.newMessage(from,message);

	}

}
