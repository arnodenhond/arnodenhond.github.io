package com.example.symchat;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;

public class SymChat extends Application {

	private ChatBox chatBox;

	public void setChatBox(ChatBox chatBox) {
		this.chatBox = chatBox;
	}

	public void unsetChatBox() {
		chatBox = null;
	}

	public void newMessage(String from, String message) {
		if (chatBox != null) {
			chatBox.incomingMessage(from, message);
		} else {
			//TODO activity wasn't running, show a notification
		}
	}

}
