package com.example.symchat;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChatBox extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_chat_box);
	}

	@Override
	protected void onStart() {
		super.onStart();
		SymChat symChat = (SymChat) getApplication();
		symChat.setChatBox(this);
	}

	@Override
	protected void onStop() {
		super.onStop();
		SymChat symChat = (SymChat) getApplication();
		symChat.unsetChatBox();
	}

	public void sendMessage(View v) {
		EditText from = (EditText) findViewById(R.id.name);
		EditText message = (EditText) findViewById(R.id.message);
		Intent intent = new Intent("symchat.message");
		intent.putExtra(Receiver.FROM, from.getText().toString());
		intent.putExtra(Receiver.MESSAGE, message.getText().toString());
		sendBroadcast(intent);
		message.setText("");
	}

	public void incomingMessage(String from, String message) {
		String time = SimpleDateFormat.getTimeInstance().format(new Date());
		TextView line = new TextView(this);
		line.setText(time + " " + from + " : " + message);
		LinearLayout incoming = (LinearLayout) findViewById(R.id.incoming);
		incoming.addView(line, 0);
	}

}
