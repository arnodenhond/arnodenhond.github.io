package TaalGids;

import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class ZoekResults extends LocMenu implements CommandListener {
    
    Command backCmd;
    Command bookMarkCmd;
    Image noZrImg;
    
    public ZoekResults(Vector locs, Data data) {
        super(locs, data);
        
        backCmd = new Command("terug",Command.BACK,0);
        bookMarkCmd = new Command("bookmark", Command.ITEM,0);
        
        addCommand(backCmd);
        addCommand(bookMarkCmd);
        setCommandListener(this);
    }
    
    protected void paint(Graphics graphics) {
        if (getLocs().size()==0) {
            graphics.setColor(Integer.parseInt("006699",16));
            graphics.fillRect(0,0,getWidth(),getHeight());
            graphics.drawImage(noZrImg,getWidth()/2,getHeight()/2,graphics.HCENTER|graphics.VCENTER);
        }
        else
            super.paint(graphics);
    }
    
    public void commandAction(Command command, Displayable displayable) {
        if (command==backCmd)
            data.display.setCurrent(data.zoekMenu);
        if (command==bookMarkCmd) {
            data.bookMarks.addBookMark((Loc) getLocs().elementAt(pos));
            repaint();
        }
    }
    
    public void zoek(String query, boolean bron) {
        query = query.toUpperCase();
        Vector locs = new Vector();
        for (int trunk = 0; trunk < data.bron.length; trunk++) {
            for (int branch = 0; branch < data.bron[trunk].length; branch++) {
                for (int leaf = 0; leaf < data.bron[trunk][branch].length; leaf++) {
                    for (int item = 0; item < data.bron[trunk][branch][leaf].length; item++) {
                        if (bron) {
                            if (data.bron[trunk][branch][leaf][item].toUpperCase().indexOf(query)!=-1) {
                                locs.addElement(new Loc(trunk,branch,leaf,item));
                            }
                        } else {
                            if (data.doel[trunk][branch][leaf][item].toUpperCase().indexOf(query)!=-1) {
                                locs.addElement(new Loc(trunk,branch,leaf,item));
                            }
                        }
                    }
                }
            }
        }
        setLocs(locs);
    }
    
}
