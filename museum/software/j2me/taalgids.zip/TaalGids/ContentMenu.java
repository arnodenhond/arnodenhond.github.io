package TaalGids;

import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;


public class ContentMenu extends LocMenu implements CommandListener {
    
        Command backCmd;
    Command bookMarkCmd;

    
    public ContentMenu(Data data) {
        super(null,data);
        backCmd = new Command("terug",Command.BACK,0);
        bookMarkCmd = new Command("bookmark", Command.ITEM,0);
        
        addCommand(backCmd);
        addCommand(bookMarkCmd);
        setCommandListener(this);

    }

    void setLocs(int trunk, int branch, int leaf) {
        Vector locs = new Vector();
        for (int i = 0; i < data.bron[trunk][branch][leaf].length; i++)
            locs.addElement(new Loc(trunk,branch,leaf,i));
        pos=0;
        top=0;
        setLocs(locs);
    }
    
    public void commandAction(Command command, Displayable displayable) {
        if (command==backCmd)
            data.display.setCurrent(data.treeMenu);
        if (command==bookMarkCmd) {
            data.bookMarks.addBookMark((Loc) getLocs().elementAt(pos));
            repaint();
        }
    }    
}

