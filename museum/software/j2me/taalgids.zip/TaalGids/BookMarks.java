package TaalGids;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;

public class BookMarks extends LocMenu  implements CommandListener {
    
    Command backCmd;
    Command delCmd;
    Image noBmImg;
    
    public BookMarks(Data data) {
        super(null,data);
        load();
        backCmd = new Command("terug",Command.BACK,0);
        delCmd = new Command("verwijderen", Command.ITEM,0);
        
        addCommand(backCmd);
        addCommand(delCmd);
        setCommandListener(this);
    }
    
    protected void paint(Graphics graphics) {
        if (getLocs().size()==0){
            graphics.setColor(Integer.parseInt("006699",16));
            graphics.fillRect(0,0,getWidth(),getHeight());
            graphics.drawImage(noBmImg,getWidth()/2,getHeight()/2,graphics.HCENTER|graphics.VCENTER);
        }
        else
            super.paint(graphics);
    }
    
    public void commandAction(Command command, Displayable displayable) {
        if (command==backCmd)
            data.display.setCurrent(data.treeMenu);
        if (command==delCmd)
            delBookMark(pos);
    }
    
    public void addBookMark(Loc loc) {
        if (isBookMarked(loc))
            return;
        getLocs().addElement(loc);
        save();
    }
    
    private void delBookMark(int index) {
        if (index>=getLocs().size())
            return;
        getLocs().removeElementAt(index);
        save();
        pos=0;
        top=0;
        repaint();
    }
    
    public boolean isBookMarked(Loc loc) {
        for (int i = 0; i < getLocs().size(); i++) {
            Loc temp = (Loc) getLocs().elementAt(i);
            if (temp.equals(loc))
                return true;
        }
        return false;
    }
    
    private void load() {
        Vector locs = new Vector();
        try {
            RecordStore rs = RecordStore.openRecordStore("bookmarks",true);
            int num = rs.getNumRecords();
            RecordEnumeration re = rs.enumerateRecords(null,null,false);
            while (re.hasNextElement()) {
                byte[] rec = re.nextRecord();
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(rec));
                locs.addElement(new Loc(dis.readInt(),dis.readInt(),dis.readInt(),dis.readInt()));
            }
            rs.closeRecordStore();
        } catch (Exception e) {
            System.out.println("loading bookmarks: "+e.toString());
        }
        setLocs(locs);
    }
    
    private void save() {
        try {
            RecordStore.deleteRecordStore("bookmarks");
            RecordStore rs = RecordStore.openRecordStore("bookmarks",true);
            for (int i = 0; i < getLocs().size(); i++) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                Loc loc = (Loc) getLocs().elementAt(i);
                dos.writeInt(loc.trunk);
                dos.writeInt(loc.branch);
                dos.writeInt(loc.leaf);
                dos.writeInt(loc.item);
                rs.addRecord(baos.toByteArray(),0,baos.toByteArray().length);
            }
            rs.closeRecordStore();
        } catch (Exception e) {
            System.out.println("saving bookmarks: "+e.toString());
        }
    }
    
}
