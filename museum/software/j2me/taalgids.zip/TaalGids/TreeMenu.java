package TaalGids;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class TreeMenu extends Canvas {
    
    int trunk;
    int branch;
    
    int max;
    int top;
    int pos;
    int lh;
    Data data;
    Image branchImg;
    Image leafImg;
    ContentMenu contentMenu;
    
    public TreeMenu(Data data) {
        this.data=data;
        data.treeMenu=this;
        top=0;
        pos=0;
        trunk=-1;
        branch=-1;
        contentMenu = new ContentMenu(data);
    }
    
    protected void paint(Graphics graphics) {
        lh = graphics.getFont().getHeight()+2;
        graphics.setColor(Integer.parseInt("FFCC33",16));
        graphics.fillRect(0,0,getWidth(),super.getHeight());
        graphics.setColor(Integer.parseInt("CC0000",16));
        data.drawBorder(graphics,getWidth(),getHeight());
        int item=0;
        for (int a = 0; a < data.alpha.length; a++) {
            addString(graphics, item, 0, data.alpha[a]);
            item++;
            if (trunk==a) {
                for (int b = 0; b < data.beta[trunk].length; b++) {
                    addString(graphics, item, 1, data.beta[trunk][b]);
                    item++;
                    if (branch==b) {
                        for (int c = 0; c < data.gamma[trunk][branch].length; c++) {
                            addString(graphics, item, 2, data.gamma[trunk][branch][c]);
                            item++;
                        }
                    }
                }
            }
        }
    }
    
    private void addString(Graphics graphics,  int item, int level, String string) {
        if (item<top || item>((top-1)+((getHeight()-20)/lh)))
            return;
        Image img = Image.createImage(getWidth()-20,lh);
        Graphics gfx = img.getGraphics();
        if (item==pos) {
            gfx.setColor(Integer.parseInt("CC0000",16));
            gfx.fillRect(0,0,img.getWidth(),img.getHeight());
            gfx.setColor(Integer.parseInt("FFFFFF",16));
        } else {
            gfx.setColor(Integer.parseInt("FFCC33",16));
            gfx.fillRect(0,0,getWidth(),super.getHeight());
            gfx.setColor(Integer.parseInt("CC0000",16));
        }
        switch (level) {
            case 0:gfx.drawString(string,0,0,Graphics.TOP|Graphics.LEFT);break;
            case 1:gfx.drawImage(branchImg,0,lh/2,graphics.LEFT|graphics.VCENTER);gfx.drawString(string,10,0,Graphics.TOP|Graphics.LEFT);break;
            case 2:gfx.drawImage(leafImg,0,lh/2,graphics.LEFT|graphics.VCENTER);gfx.drawString(string,20,0,Graphics.TOP|Graphics.LEFT);break;
        }
        graphics.drawImage(img,10,10+((item-top)*img.getHeight()),Graphics.TOP|Graphics.LEFT);
    }
    
    private void collapseBranch() {
        if (branch!=-1 && pos>(trunk+branch+1)) {
            if (pos<(trunk+branch+1+data.gamma[trunk][branch].length)) {
                pos=trunk;
            }
            pos-=data.gamma[trunk][branch].length;
        }
        branch=-1;
    }
    
    private void collapseTrunk() {
        if (trunk!=-1) {
            if (pos>trunk) {
                if (branch!=-1) {
                    collapseBranch();
                }
                if (pos>=(trunk+1+data.beta[trunk].length)) {
                    pos-=data.beta[trunk].length;
                }
            }
        }
        branch=-1;
        trunk=-1;
    }
    
    private void openTrunk() {
        collapseTrunk();
        this.trunk=pos;
    }
    
    private void openBranch() {
        collapseBranch();
        this.branch=pos-(trunk+1);
    }
    
    private boolean onLeaf() {
        if (trunk==-1 || branch==-1) {
            return false;
        }
        if (pos>(trunk+branch+1) && pos < (trunk+1+branch+1+data.gamma[trunk][branch].length)) {
            return true;
        } else {
            return false;
        }
    }
    
    private boolean onBranch() {
        if (trunk==-1 || pos<=trunk) {
            return false;
        }
        if (branch==-1) {
            if (pos <= (trunk+data.beta[trunk].length)) {
                return true;
            } else {
                return false;
            }
        } else {
            if (onLeaf())
                return false;
            if (pos <= (trunk+data.beta[trunk].length)+data.gamma[trunk][branch].length) {
                return true;
            } else {
                return false;
            }
        }
    }
    
    private boolean onTrunk() {
        if (onBranch()||onLeaf()) {
            return false;
        } else {
            return true;
        }
    }
    
    private int getMax() {
        if (trunk==-1) {
            return data.alpha.length-1;
        } else {
            if (branch==-1) {
                return data.alpha.length+data.beta[trunk].length-1;
            } else {
                return data.alpha.length+data.beta[trunk].length+data.gamma[trunk][branch].length-1;
            }
        }
    }
    
    protected void keyPressed(int aKeyCode) {
        if (aKeyCode==getKeyCode(FIRE) || getGameAction(aKeyCode)==FIRE) {
            if (pos==0) {
                data.display.setCurrent(data.zoekMenu);
                return;
            }
            if (pos==1) {
                data.display.setCurrent(data.bookMarks);
                return;
            }
            if (trunk!=-1) {//collapse
                if (pos==trunk) {
                    collapseTrunk();
                    repaint();
                    return;
                }
                if (branch!=-1 && pos==trunk+branch+1) {
                    collapseBranch();
                    repaint();
                    return;
                }
            }
            
            if (onTrunk()) {
                openTrunk();
            }
            
            if (onBranch()) {
                openBranch();
            }
            
            if (onLeaf()) {
                int leaf = pos-(trunk+1+branch+1);
                contentMenu.setLocs(trunk,branch,leaf);
                data.display.setCurrent(contentMenu);
            }
            repaint();
            return;
        }
        if (aKeyCode==getKeyCode(DOWN) || getGameAction(aKeyCode)==DOWN) {
            if (pos<getMax())
                pos++;
            if (pos>(top-1)+((getHeight()-20)/lh))
                top++;
            repaint();
        }
        if (aKeyCode==getKeyCode(UP) || getGameAction(aKeyCode)==UP) {
            if (pos>0)
                pos--;
            if (pos<top)
                top--;
            repaint();
        }
    }
    
}

