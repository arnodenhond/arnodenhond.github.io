package TaalGids;

import java.util.Vector;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

public class ZoekMenu extends Form implements CommandListener {
    
    TextField input;
    ChoiceGroup cg ;
    Command backCmd;
    Command zoekCmd;
    Data data;
    ZoekResults zoekResults;
    
    public ZoekMenu(Data data) {
        super("zoeken");
        this.data=data;
        input = new TextField("zoek woord","dokter!",100,TextField.ANY);
        cg = new ChoiceGroup("talen",ChoiceGroup.EXCLUSIVE,new String[] {"Nederlands","Spaans"},null);
        backCmd = new Command("terug",Command.BACK,0);
        zoekCmd = new Command("zoeken",Command.OK,0);
        zoekResults = new ZoekResults(null,data);
        append(input);
        append(cg);
        addCommand(backCmd);
        addCommand(zoekCmd);
        setCommandListener(this);
    }
    
    public void commandAction(Command command, Displayable displayable) {
        if (command==backCmd)
            data.display.setCurrent(data.treeMenu);
        if (command==zoekCmd) {
            zoekResults.zoek(input.getString(),cg.getSelectedIndex()==0);
            data.display.setCurrent(zoekResults);
        }
    }
        
}
