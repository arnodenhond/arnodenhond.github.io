package TaalGids;

public class Loc {
    

    int trunk;
    int branch;
    int leaf;
    int item;
    
    public Loc(int rubriek,int subrubriek,int zwr,int item) {
        this.trunk=rubriek;
        this.branch=subrubriek;
        this.leaf=zwr;
        this.item=item;
    }
    

    public boolean equals(Object object) {
        Loc loc = (Loc) object;
        if (loc.trunk!=trunk)
            return false;
        if (loc.branch!=branch)
            return false;
        if (loc.leaf!=leaf)
            return false;
        if (loc.item!=item)
            return false;
        return true;
    }
}
