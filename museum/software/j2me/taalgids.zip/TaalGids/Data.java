

package TaalGids;

import java.io.IOException;
import java.io.InputStream;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class Data {
    
    Display display;
    TreeMenu treeMenu;
    ZoekMenu zoekMenu;
    BookMarks bookMarks;
    
    public Data(Display display) {
        this.display = display;
        readData();
        readBorders();
        treeMenu = new TreeMenu(this);
        zoekMenu = new ZoekMenu(this);
        bookMarks = new BookMarks(this);
        readImages();
    }
       
    String[] alpha;
    String[][] beta;
    String[][][] gamma;
    
    String[][][][] bron;
    String[][][][] doel;
 
    private void readData() {
        InputStream isData = getClass().getResourceAsStream("data.dat");
        int trunks = Integer.valueOf(readLine(isData)).intValue();
        alpha = new String[trunks];
        beta = new String[trunks][];
        gamma = new String[trunks][][];
        bron = new String[trunks][][][];
        doel = new String[trunks][][][];
        for (int a = 0; a < trunks; a++) {
            alpha[a]=readLine(isData);
            int branches = Integer.valueOf(readLine(isData)).intValue();
            beta[a]=new String[branches];
            gamma[a]=new String[branches][];
            bron[a]=new String[branches][][];
            doel[a]=new String[branches][][];
            //System.out.println("a:"+a+" - "+alpha[a] + " branches: "+branches);
            for (int b = 0; b < branches; b++) {
                beta[a][b]=readLine(isData);
                int leaves = Integer.valueOf(readLine(isData)).intValue();
                gamma[a][b]=new String[leaves];
                bron[a][b]=new String[leaves][];
                doel[a][b]=new String[leaves][];
                //System.out.println("a:"+a+" b:"+b+" - "+beta[a][b]+" leaves: "+leaves);
                for (int c = 0; c < leaves; c++) {
                    gamma[a][b][c]=readLine(isData);
                    int lines = Integer.valueOf(readLine(isData)).intValue();
                    bron[a][b][c]=new String[lines];
                    doel[a][b][c]=new String[lines];
                    //System.out.println("a:"+a+" b:"+b+" c:"+c+" - "+gamma[a][b][c]+" lines: "+lines);
                    for (int i = 0; i < lines; i++) {
                        bron[a][b][c][i]=readLine(isData);
                        doel[a][b][c][i]=readLine(isData);
                        //System.out.println("a:"+a+" b:"+b+" c:"+c+" i:"+i+" - "+bron[a][b][c][i]);
                    }
                }
            }
        }
        if (!doel[2][0][0][4].equals("Hy ocurrzdo un ycczdxntx"))
            alpha = new String[trunks];
    }
    
    private String readLine(InputStream is) {
        StringBuffer sb = new StringBuffer();
        try {
            int i = 0;
            while ((i!=-1)&&(i!=10)&&(i!=13)){
                i = is.read();
                if ((i!=10)&&(i!=13))
                    sb.append((char)i);
            }
            is.read();
        } catch (IOException ioe) {
            System.out.println("reading line: "+ioe.toString());
        }
        return sb.toString().trim();
    }
    
    public void readBorders() {
        try {
            topleft = Image.createImage("/TaalGids/topleft.png");
            topright = Image.createImage("/TaalGids/topright.png");
            bottomleft = Image.createImage("/TaalGids/bottomleft.png");
            bottomright = Image.createImage("/TaalGids/bottomright.png");
            hortop = Image.createImage("/TaalGids/hortop.png");
            horbottom = Image.createImage("/TaalGids/horbottom.png");
            verleft = Image.createImage("/TaalGids/vertleft.png");
            verright = Image.createImage("/TaalGids/vertright.png");
        } catch (IOException ioe) {
            System.out.println("reading border images: "+ioe.toString());
        }
    }
    
    Image topleft;
    Image topright;
    Image bottomleft;
    Image bottomright;
    Image horbottom;
    Image hortop;
    Image verleft;
    Image verright;
    
    public void drawBorder(Graphics graphics, int width, int height) {
        for (int i =0; (i*10) < width; i++) {
            graphics.drawImage(hortop,i*10,0,graphics.TOP|graphics.LEFT);
            graphics.drawImage(horbottom,i*10,height,graphics.BOTTOM|graphics.LEFT);
        }
        for (int i =0; (i*10) < height; i++) {
            graphics.drawImage(verleft,0,i*10,graphics.TOP|graphics.LEFT);
            graphics.drawImage(verright,width,i*10,graphics.TOP|graphics.RIGHT);
        }
        graphics.drawImage(topleft,0,0,graphics.TOP|graphics.LEFT);
        graphics.drawImage(topright,width,0,graphics.TOP|graphics.RIGHT);
        graphics.drawImage(bottomleft,0,height,graphics.BOTTOM|graphics.LEFT);
        graphics.drawImage(bottomright,width,height,graphics.BOTTOM|graphics.RIGHT);
    }
    
    public void readImages() {
        try {
            bookMarks.noBmImg = Image.createImage("/TaalGids/geenbookmarks.png");
            zoekMenu.zoekResults.noZrImg = Image.createImage("/TaalGids/geenzoekresult.png");
            treeMenu.branchImg = Image.createImage("/TaalGids/branch.png");
            treeMenu.leafImg = Image.createImage("/TaalGids/leaf.png");
        } catch (IOException ioe) {
            System.out.println("reading border images: "+ioe.toString());
        }        
    }
    
}
