package TaalGids;

import java.util.Vector;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class LocMenu extends Canvas {
    Data data;
    int pos=0;//the currently selected menu option
    int top=0;//the menu option at the top of the visible list
    int max=3;//the number of simultaniously visible options
    int lh;
    private Vector locs;
    
    public LocMenu(Vector locs, Data data) {
        this.locs=locs;
        this.data=data;
    }
    
    public void setLocs(Vector locs) {
        this.locs=locs;
        top=0;
        pos=0;
    }
    
    public Vector getLocs() {
        return locs;
    }
    
    protected void paint(Graphics graphics) {
        lh = graphics.getFont().getHeight()*2;
        graphics.setColor(Integer.parseInt("FFCC33",16));        
        graphics.fillRect(0,0,getWidth(),super.getHeight());
        graphics.setColor(Integer.parseInt("CC0000",16));
        data.drawBorder(graphics,getWidth(),getHeight());
        int item=0;
        for (int i = 0; i < locs.size(); i++) {
            Loc loc = (Loc) locs.elementAt(i);
            addString(graphics,item,data.bron[loc.trunk][loc.branch][loc.leaf][loc.item]);
            item++;
        }
        Loc loc = (Loc) locs.elementAt(pos);
        //graphics.drawString(data.doel[loc.trunk][loc.branch][loc.leaf][loc.item],10,(getHeight()-10)-lh,Graphics.TOP|Graphics.LEFT);
        String string = data.doel[loc.trunk][loc.branch][loc.leaf][loc.item];
        graphics.drawImage(makeString(string,getWidth()-20,graphics.getFont(),true,lh/2,true),10,(getHeight()-10)-lh,Graphics.TOP|Graphics.LEFT);
    }
    
    private void addString(Graphics graphics,  int item, String string) {
        if (item<top || item>((top-1)+(getScrollHeight()/lh)))
            return;
        /*Image img = Image.createImage(getWidth()-20,lh);
        Graphics gfx = img.getGraphics();
        if (item==pos) {
            gfx.setColor(Integer.parseInt("CC0000",16));
            gfx.fillRect(0,0,img.getWidth(),img.getHeight());
            gfx.setColor(Integer.parseInt("FFFFFF",16));
        } else {
            gfx.setColor(Integer.parseInt("006699",16));
            gfx.fillRect(0,0,img.getWidth(),img.getHeight());
            gfx.setColor(Integer.parseInt("FFFFFF",16));
        }
        gfx.drawString(string,0,0,Graphics.TOP|Graphics.LEFT);
        if (data.bookMarks.isBookMarked((Loc) locs.elementAt(item)))
            gfx.drawString("BM",img.getWidth(),0,Graphics.TOP|Graphics.RIGHT);
        graphics.drawImage(img,10,10+((item-top)*img.getHeight()),Graphics.TOP|Graphics.LEFT);
         */

        boolean bm = data.bookMarks.isBookMarked((Loc) locs.elementAt(item));
        graphics.drawImage(makeString(string,getWidth()-20,graphics.getFont(),item!=pos,lh/2,false,bm),10,10+((item-top)*lh),Graphics.TOP|Graphics.LEFT);
    
    }
    
    protected void keyPressed(int aKeyCode) {
        if (aKeyCode==getKeyCode(DOWN) || getGameAction(aKeyCode)==DOWN) {
            if (pos<locs.size()-1)
                pos++;
            else {
                pos=0;
                top=0;
            }
            if (pos>(top-1)+(getScrollHeight()/lh))
                top++;
            repaint();
        }
        if (aKeyCode==getKeyCode(UP) || getGameAction(aKeyCode)==UP) {
            if (pos>0)
                pos--;
            else {
                pos=locs.size()-1;
                top=(pos+1)-(getScrollHeight()/lh);
                if (top<0)
                    top=0;
            }
            if (pos<top)
                top--;
            repaint();
        }
    }
    
    public int getScrollHeight() {
        return ((getHeight()-lh)-20);
    }
    
    
    private int wordWidth(String s, Font font) {
        int result=0;
        for (int i = 0; i < s.length(); i++) {
            result+=font.charWidth(s.charAt(i));
        }
        return result;
    }
    
    public Image makeString(String string, int maxwidth, Font font, boolean normal,int lh, boolean vertaling, boolean isBookmarked) {
        if (string==null)
            return Image.createImage(maxwidth,lh*2);
        Image img = Image.createImage(maxwidth,(lh*2));
        Graphics imggfx = img.getGraphics();
        if (normal) {
            imggfx.setColor(Integer.parseInt("006699",16));
            imggfx.fillRect(0,0,maxwidth,(lh*2));
            imggfx.setColor(Integer.parseInt("FFFFFF",16));
        } else {
            imggfx.setColor(Integer.parseInt("CC0000",16));
            imggfx.fillRect(0,0,maxwidth,(lh*2));
            imggfx.setColor(Integer.parseInt("FFFFFF",16));
        }
        if (vertaling){//overwrite!
            imggfx.setColor(Integer.parseInt("FFCC33",16));
            imggfx.fillRect(0,0,maxwidth,(lh*2));
            imggfx.setColor(Integer.parseInt("CC0000",16));
        }
        if (isBookmarked) //overwrite
            imggfx.setColor(Integer.parseInt("FFCC33",16));
        int line=0;
        int pix=0;
        int pos=0;
        do {
            int i = string.indexOf(" ",pos);
            if (i==-1)
                i = string.length();
            String s = string.substring(pos,i);
            pos = i+1;
            s=s+" ";
            
            if (wordWidth(s,font)+pix>maxwidth) {
                if (pix>0)
                    line++;
                pix=0;
            }
            switch (line) {
                case 0:
                    imggfx.drawString(s,pix,0,Graphics.TOP|Graphics.LEFT);
                    break;
                case 1:
                    imggfx.drawString(s,pix,(lh*2),Graphics.BOTTOM|Graphics.LEFT);
                    break;
            }
            pix+=wordWidth(s,font);
            
        } while (pos < string.length());
        return img;
        
    }
    
    public Image makeString(String string, int maxwidth, Font font, boolean normal,int lh, boolean vertaling) {
        return makeString(string, maxwidth, font, normal, lh, vertaling, false);
    }    
    
}
