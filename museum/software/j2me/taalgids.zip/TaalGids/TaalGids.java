// Arno den Hond (c) 2007

// opstart progress bar
// afsluit knop+scherm
// ?vanuit treemenu->bookmarks vastloper
// diepte aangeven door achtergrond kleur ?
// tree links = inklappen (rechts=fire)

package TaalGids;

import java.io.IOException;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TaalGids extends MIDlet implements CommandListener {
    
    Data data;
    
    public TaalGids() {
        data = null;
    }
    
    public void startApp() {
        if (data==null) {
            Canvas splash =new Canvas() {
                protected void paint(Graphics graphics) {
                    graphics.setColor(Integer.parseInt("006699",16));
                    graphics.fillRect(0,0,getWidth(),getHeight());
                    try {
                        graphics.drawImage(Image.createImage("/TaalGids/splash.png"),getWidth()/2,getHeight()/2,graphics.HCENTER|graphics.VCENTER);
                    } catch (IOException ex) { }
                }
            };
            splash.setCommandListener(this);
            Display.getDisplay(this).setCurrent(splash);
            data = new Data(Display.getDisplay(this));
            splash.addCommand(new Command("Start",Command.BACK,0));
        }
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
        data=null;
    }

    public void commandAction(Command command, Displayable displayable) {
        data.display.setCurrent(data.treeMenu);
    }
    
}
