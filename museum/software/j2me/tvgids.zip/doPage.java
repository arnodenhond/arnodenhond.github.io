package TVGIDS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.*;
import java.lang.*;
import java.io.*;

public class doPage extends Thread {
    
    Vector vector;
    Gauge gauge;
    int i;
    String s;
    boolean done;
    boolean finished;
    
    doPage(Vector v, Gauge g, int ikan) {
        done=false;
        finished=false;
        vector = v;
        gauge = g;
        i = ikan;
        switch (ikan) {
            case 0: s="ned";break;
            case 1: s="rtl4";break;
            case 2: s="rtl5";break;
            case 3: s="sbs6";break;
            case 4: s="net5";break;
            case 5: s="yorin";break;
            case 6: s="v8";break;
            case 7: s="bbc1";break;
            case 8: s="bbc2";break;
            case 9: s="brt1";break;
            case 10: s="brt2";break;
            case 11: s="disco";break;
            case 12: s="geo";break;
            case 13: s="nic";break;
        }
    }
    
    public void run() {
        String page = getPage(s);
        System.out.println(page);
        process(page,i);
        gauge.setValue(gauge.getValue()+1);
        done = true;
        finished = true;
        try {
        join();
        } catch (Exception e) {}
    }

    void process(String tijden, int kanaal) {
        String vandaag = "";
        String morgen ="";
        String overmorgen ="";
        if (tijden.indexOf("-- Morgen --")!=-1) {
            vandaag = tijden.substring(13,tijden.indexOf("-- Morgen --")-5);
            if (tijden.indexOf("-- Overmorgen --")!=-1) {
                overmorgen = tijden.substring(tijden.indexOf("-- Overmorgen --")+16,tijden.length()-5);
                morgen = tijden.substring(tijden.indexOf("-- Morgen --")+12,tijden.indexOf("-- Overmorgen --")-5);
            }
            else
                morgen = tijden.substring(tijden.indexOf("-- Morgen --")+12,tijden.length()-5);
        }
        else
            vandaag = tijden.substring(13,tijden.length()-5);
        
        Calendar c = Calendar.getInstance();
        dodag(vandaag,c,kanaal);
        //        c.set(Calendar.DATE,c.get(Calendar.DATE)+1);
        //        dodag(morgen,c, kanaal);
        //        c.set(Calendar.DATE,c.get(Calendar.DATE)+1);
        //        dodag(overmorgen,c);
    }
    
    void dodag(String vandaag,Calendar c, int kanaal) {
        int index = 0;
        while (vandaag.indexOf("<br/>",index)!=-1) {
            index = vandaag.indexOf("<br/>",index)+1;
            String str;
            if (vandaag.indexOf("<br/>",index)!=-1)
                str = vandaag.substring(index+4,vandaag.indexOf("<br/>",index));
            else
                str = vandaag.substring(index+4,vandaag.length());
            c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(str.substring(1,3)));
            c.set(Calendar.MINUTE,Integer.parseInt(str.substring(4,6)));
            
            Show s=new Show();
            s.naam = str.substring(7,str.length());
            s.tijd = c.getTime().getTime();
            s.kanaal = kanaal;
            insert(s);
        }
    }
    
    void insert(Show ps) {
        for (int i2 = 0; i2 < vector.size(); i2++) {
            Show show = (Show) vector.elementAt(i2);
            if (show.tijd>ps.tijd) {
                vector.insertElementAt(ps,i2);
                return;
            }
        }
        vector.addElement(ps);
    }
    
    String getPage(String kanaal) {
        String result = new String();
        HttpConnection conn=null;
        try {
            conn = (HttpConnection) Connector.open("http://wap.sjeemz.nl/index.php?q="+kanaal);
            InputStream is = conn.openInputStream();
            int ch;
            while ((ch = is.read()) != -1)
                result+=(char) ch;
            is.close();
            conn.close();
        }
        catch (Exception e) {
            try {
                if (conn!=null);
                conn.close();
            }
            catch (Exception ex)
            {result="<p>-- Vandaag --<br/>[12:36] foutje!<br/></p>";}
        }
        finally {
            try {
                if (conn!=null);
                conn.close();
            }
            catch (Exception e)
            {result="<p>-- Vandaag --<br/>[12:36] foutje!<br/></p>";}
        }
        return result.substring(result.indexOf("<p>")+3,result.indexOf("</p>"));
    }
    
    
}
