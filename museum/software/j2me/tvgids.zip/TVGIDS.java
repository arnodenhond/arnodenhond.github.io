package TVGIDS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.*;

public class TVGIDS extends MIDlet implements CommandListener {
    
    List kanalen;
    Form programmas;
    Command zoek;
    Command verder; //-----
    Command films;  //-----
    Vector shows;
    String[] kanamen; //kanaal namen
    
    public TVGIDS() {
        zoek = new Command("Zoek",Command.BACK,0);
        kanamen = new String[14];
        kanamen[0]="Nederland 123";
        kanamen[1]="RTL 4";
        kanamen[2]="RTL 5";
        kanamen[3]="SBS 6";
        kanamen[4]="NET 5";
        kanamen[5]="YORIN";
        kanamen[6]="V8";
        kanamen[9]="BBC 1";
        kanamen[10]="BBC 2";
        kanamen[7]="BRT 1";
        kanamen[8]="BRT 2";
        kanamen[11]="Discovery";
        kanamen[12]="Geographic";
        kanamen[13]="Nickelodeon";
        programmas = new Form("Programmas");
        kanalen = new List("Kanalen",List.MULTIPLE);
        for (int i = 0; i < 14; i++)
            kanalen.append(kanamen[i],null);
        for (int i = 0; i < 7; i++) //alleen nederlandse zenders
            kanalen.setSelectedIndex(i,true);
        programmas.addCommand(zoek);
        programmas.setCommandListener(this);
        kanalen.addCommand(zoek);
        kanalen.setCommandListener(this);
        shows = new Vector();
    }
    
    public void startApp() {
        Gauge g = new Gauge("progress",false,14,0);
        Form f = new Form("downloading");
        f.append(g);
        Display.getDisplay(this).setCurrent(f);
        doPage[] draadjes = new doPage[14];
        for (int i = 0; i < draadjes.length; i++) {
            draadjes[i]=new doPage(shows,g,i);
        }
        boolean notdone = true;
        int counter;
        for (counter = 0; counter < 4; counter++)
            draadjes[counter].start();
        while (notdone) {
            try {
            wait(100);
            } catch (Exception e) {}
//            System.gc();
            notdone = false;
            for (int i = 0; i < draadjes.length; i++) {
                if (!draadjes[i].done) {
                    notdone = true;
                }
                if (draadjes[i].finished) {
                    if (counter<draadjes.length) {
                        draadjes[counter].start();
                        counter++;
                    }
                    draadjes[i].finished=false;
                }
            
            }
        }
        //Display.getDisplay(this).setCurrent(new Form("refreshing"));
        programmas = refresh();
        Display.getDisplay(this).setCurrent(programmas);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
    public void commandAction(Command c, Displayable s) {
        if (s==kanalen) {
            programmas = refresh();
            Display.getDisplay(this).setCurrent(programmas);
        }
        else
            Display.getDisplay(this).setCurrent(kanalen);
    }
    
    Form refresh() {
        Form result = new Form("Programmas");
        boolean[] flags = new boolean[kanalen.size()];
        kanalen.getSelectedFlags(flags);
        int counter=0;
        for (int i = 0; i < shows.size(); i++) {
            Show s = (Show) shows.elementAt(i);
            if (flags[s.kanaal]) {
                if (counter++==50) 
                    break;
                result.append(new StringItem(s.naam,kanamen[s.kanaal]+" "+tijd(s.tijd)));
            }
        }
        result.addCommand(zoek);
        result.setCommandListener(this);
        return result;
    }
    
    String tijd(long tijd) { // (over)morgen   tijd vanaf nu
        Calendar c = Calendar.getInstance();
        c.setTime(new Date(tijd));
        String s = c.get(Calendar.MINUTE)+"";
        if (s.length()==1)
            s="0"+s;
        return c.get(Calendar.HOUR_OF_DAY)+":"+s;
    }
    
}
