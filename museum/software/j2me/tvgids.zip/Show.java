package TVGIDS;

public class Show {

    public int kanaal;
    public long tijd;
    public String naam;

}
