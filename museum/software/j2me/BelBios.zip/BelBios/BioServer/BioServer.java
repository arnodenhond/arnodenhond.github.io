
package BioServer;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
import WapSpider.*;

public class BioServer {
    
    static ArrayList loadDB() throws Exception{
        FileInputStream fis = new FileInputStream("F:\\NEWDATA\\NOBSOFT\\BelBios\\BioServer\\belbios.db");
        ObjectInputStream ois = new ObjectInputStream(fis);
        ArrayList result = (ArrayList) ois.readObject();
        fis.close();
        return result;
    }
    
    public BioServer() {
    }
    
    
    public static void main(String[] args) throws Exception {
        ArrayList steden = loadDB();
        for (int i = 0; i < steden.size(); i++) {
            Stad s = (Stad) steden.get(i);
            s.shows = rastaSort(s.shows);
        }
        ServerSocket ss = new ServerSocket(80);
        ss.setSoTimeout(1000);
        while (true) {
            try {
                Socket s = ss.accept();
                new UserInterface(s, steden).start();
            }
            catch (Exception e) {
            }
        }
    }
    
            /*
             *
             *  RASTA SORT STARTS ERE MON
             *
             */
    
    static ArrayList rastaSort(ArrayList shows) {
        ArrayList sorted = new ArrayList();
        for (int i = 0; i < shows.size(); i++) {
            Show s1 = (Show) shows.get(i);
            Date d1 = new Date(s1.date);
            //System.out.println("s1: "+d1.toString());
            boolean done = false;
            for (int j = 0; j < sorted.size(); j++) {
                Show s2 = (Show) sorted.get(j);
                Date d2 = new Date(s2.date);
                //System.out.println("s2: "+d2.toString());
                if (d1.before(d2)) {
                    //System.out.println("found!, inserting at "+j);
                    done = true;
                    sorted.add(j,s1);
                    break;
                }
            }
            if (!done) {
                sorted.add(s1);
                //System.out.println("not found, appending");
            }
        }
        //System.out.println(shows.size());
        //System.out.println(sorted.size());
        return sorted;
    }
    
}
