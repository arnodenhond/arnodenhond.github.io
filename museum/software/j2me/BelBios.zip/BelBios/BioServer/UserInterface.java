package BioServer;

import java.net.*;
import java.util.*;
import java.io.*;
import WapSpider.*;

class UserInterface extends Thread {
    
    static String getRequesthdr(BufferedReader in) throws Exception {
        String templine = " ";
        String requesthdr = "";
        while (!templine.equals("")) {
            templine = in.readLine();
            requesthdr += templine+"|";
        }
        requesthdr = new URLDecoder().decode(requesthdr);
        return requesthdr;
    }
    
    Socket s;
    ArrayList steden;
    
    public UserInterface(Socket s, ArrayList steden) {
        this.s = s;
        this.steden = steden;
    }
    
    public void run() {
        System.out.println("connect");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String requesthdr = getRequesthdr(in);
            
            StringTokenizer st = new StringTokenizer(requesthdr," ");
            String URL = "";
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(),true);
            pw.println("HTTP/1.0 200 OK");
            pw.println();
            
            //System.out.println(requesthdr);
            URL = requesthdr.substring(5,requesthdr.indexOf("HTTP")-1);
            //System.out.println(URL);
            
            Stad stad = findStad(URL, steden);
            //Stad stad = (Stad) steden.get(7);//7=amsterdam, 57 = LEIDEN
            //System.out.println(stad.naam);
            
            ArrayList shows = new ArrayList();
            ArrayList bioses = new ArrayList();
            ArrayList films = new ArrayList();
            
            Calendar now = Calendar.getInstance();
            now.setTimeZone(TimeZone.getTimeZone("UTC"));
            now.set(Calendar.MONTH,Calendar.getInstance().get(Calendar.MONTH));
            now.set(Calendar.DATE,Calendar.getInstance().get(Calendar.DATE));
            now.set(Calendar.HOUR_OF_DAY,Calendar.getInstance().get(Calendar.HOUR_OF_DAY));
            Calendar end = Calendar.getInstance();
            end.setTimeZone(TimeZone.getTimeZone("UTC"));
            end.set(Calendar.DATE,Calendar.getInstance().get(Calendar.DATE)+1);
            end.set(Calendar.HOUR_OF_DAY,2);
            for (int i = 0; i < stad.shows.size(); i++) {
                Show s = (Show) stad.shows.get(i);
                Calendar temp = Calendar.getInstance();
                //temp.setTimeZone(TimeZone.getTimeZone("UTC"));
                temp.setTimeInMillis(s.date);
                if ((now.before(temp))&&(end.after(temp))) {
                    shows.add(s);
                    if (!bioses.contains(find(s.bios,stad.bioses)))
                        bioses.add(find(s.bios,stad.bioses));
                    if (!films.contains(find(s.film,stad.films)))
                        films.add(find(s.film,stad.films));
                }
            }
            
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            dos.writeInt(shows.size());
            for (int i = 0; i < shows.size(); i++) {
                Show show = (Show) shows.get(i);
                dos.writeLong(show.date);
                dos.writeInt(bioses.indexOf(find(show.bios,bioses)));
                dos.writeInt(films.indexOf(find(show.film,films)));
                //                System.out.println(films.indexOf(find(show.film,films)));
            }
            dos.writeInt(bioses.size());
            for (int i = 0; i < bioses.size(); i++) {
                NaamID n = (NaamID) bioses.get(i);
                dos.writeInt(n.id);
                dos.writeUTF(n.naam);
            }
            dos.writeInt(films.size());
            for (int i = 0; i < films.size(); i++) {
                NaamID n = (NaamID) films.get(i);
                dos.writeInt(n.id);
                dos.writeUTF(n.naam);
            }
            dos.flush();
            dos.close();
            s.close();
        }
        catch (Exception e) {
            System.out.println("error occurred while handling connection!");
            System.out.println(e.toString());
            e.printStackTrace(System.out);
        }
    }
    
    NaamID find(int id, ArrayList list) {
        for (int i = 0; i < list.size(); i++) {
            NaamID n = (NaamID) list.get(i);
            if (n.id==id)
                return n;
        }
        return null;
    }
    
    Stad findStad(String naam, ArrayList steden) {
        for (int i = 0 ; i < steden.size(); i++) {
            Stad s = (Stad) steden.get(i);
            if (s.naam.endsWith(naam))
                return s;
        }
        return null;
    }
    
}
