package BiosClient;

import java.util.*;
import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

public class BiosClient extends MIDlet implements CommandListener, ItemStateListener {
    
    long[] times;
    int[] movies;
    int[] cinemas;
    
    List movieList;
    List cinemaList;
    int[] movieIDs;
    int[] cinemaIDs;
    String[] cinemadesc;
    String[] moviedesc;
    
    Command movieCommand;
    Command cinemaCommand;
    Command okCommand;
    
    public BiosClient() {
        movieList = new List("Films",List.MULTIPLE);
        cinemaList = new List("Bioscopen",List.MULTIPLE);
        movieCommand = new Command("Films",Command.SCREEN,0);
        cinemaCommand = new Command("Bioscopen",Command.SCREEN,1);
        okCommand = new Command("Back",Command.BACK,0);
        movieList.addCommand(okCommand);
        cinemaList.addCommand(okCommand);
        movieList.setCommandListener(this);
        cinemaList.setCommandListener(this);
    }
    
    public void startApp() {
        List regionList = new List("kies een stad",List.IMPLICIT);
        regionList.append("Alblasserdam",null);
        regionList.append("Alkmaar",null);
        regionList.append("Almelo",null);
        regionList.append("Almere",null);
        regionList.append("Alphen a/d Rijn",null);
        regionList.append("Amersfoort",null);
        regionList.append("Amstelveen",null);
        regionList.append("Amsterdam",null);
        regionList.append("Apeldoorn",null);
        regionList.append("Arnhem",null);
        regionList.append("Assen",null);
        regionList.append("Bergen",null);
        regionList.append("Bergen op Zoom",null);
        regionList.append("Best",null);
        regionList.append("Beverwijk",null);
        regionList.append("Boxmeer",null);
        regionList.append("Breda",null);
        regionList.append("Brielle",null);
        regionList.append("Castricum",null);
        regionList.append("Cuyk",null);
        regionList.append("Delft",null);
        regionList.append("Den Bosch",null);
        regionList.append("Den Burg, Texel",null);
        regionList.append("Den Haag",null);
        regionList.append("Den Helder",null);
        regionList.append("Deventer",null);
        regionList.append("Doetinchem",null);
        regionList.append("Dordrecht",null);
        regionList.append("Drachten",null);
        regionList.append("Echt",null);
        regionList.append("Ede",null);
        regionList.append("Eindhoven",null);
        regionList.append("Emmeloord",null);
        regionList.append("Emmen",null);
        regionList.append("Enschede",null);
        regionList.append("Geertruidenberg",null);
        regionList.append("Geleen",null);
        regionList.append("Gorinchem",null);
        regionList.append("Gouda",null);
        regionList.append("Groningen",null);
        regionList.append("Haarlem",null);
        regionList.append("Harderwijk",null);
        regionList.append("Heerenveen",null);
        regionList.append("Heerhugowaard",null);
        regionList.append("Heerlen",null);
        regionList.append("Hellevoetsluis",null);
        regionList.append("Helmond",null);
        regionList.append("Hengelo",null);
        regionList.append("Hilversum",null);
        regionList.append("Hoofddorp",null);
        regionList.append("Hoogeveen",null);
        regionList.append("Hoorn",null);
        regionList.append("Huizen",null);
        regionList.append("Hulst",null);
        regionList.append("IJmuiden",null);
        regionList.append("Klazienaveen",null);
        regionList.append("Leeuwarden",null);
        regionList.append("Leiden",null);
        regionList.append("Lelystad",null);
        regionList.append("Maastricht",null);
        regionList.append("Malden",null);
        regionList.append("Meppel",null);
        regionList.append("Middelburg",null);
        regionList.append("Naaldwijk",null);
        regionList.append("Nieuwegein",null);
        regionList.append("Nijmegen",null);
        regionList.append("Oss",null);
        regionList.append("Oudenbosch",null);
        regionList.append("Purmerend",null);
        regionList.append("Reuver",null);
        regionList.append("Roermond",null);
        regionList.append("Roosendaal",null);
        regionList.append("Rotterdam",null);
        regionList.append("Sittard",null);
        regionList.append("Sneek",null);
        regionList.append("Spijkenisse",null);
        regionList.append("Stadskanaal",null);
        regionList.append("Steenwijk",null);
        regionList.append("Tiel",null);
        regionList.append("Tilburg",null);
        regionList.append("Utrecht",null);
        regionList.append("Veenendaal",null);
        regionList.append("Venlo",null);
        regionList.append("Venray",null);
        regionList.append("Vlissingen",null);
        regionList.append("Voorschoten",null);
        regionList.append("Waalwijk",null);
        regionList.append("Wageningen",null);
        regionList.append("Weert",null);
        regionList.append("Wijchen",null);
        regionList.append("Winschoten",null);
        regionList.append("Winterswijk",null);
        regionList.append("Zaandam",null);
        regionList.append("Zandvoort",null);
        regionList.append("Zeist",null);
        regionList.append("Zevenaar",null);
        regionList.append("Zoetermeer",null);
        regionList.append("Zutphen",null);
        regionList.append("Zwolle",null);
        regionList.setCommandListener(this);
        Display.getDisplay(this).setCurrent(regionList);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
    
    public void commandAction(Command c, Displayable d) {
        if (c == List.SELECT_COMMAND) {
            List list = (List) Display.getDisplay(this).getCurrent();
            String string = list.getString(list.getSelectedIndex());
            if (string.indexOf(" ")!=-1)
                downloadData(string.substring(string.lastIndexOf(' '),string.length()));
            else
                downloadData(string);
            Display.getDisplay(this).setCurrent(makeResultForm());
        }
        if (c == movieCommand)
            Display.getDisplay(this).setCurrent(movieList);
        if (c == cinemaCommand)
            Display.getDisplay(this).setCurrent(cinemaList);
        if (c == okCommand)
            Display.getDisplay(this).setCurrent(makeResultForm());
    }
    
    public void itemStateChanged(Item item) {
        Form viewForm = new Form("");
        viewForm.addCommand(okCommand);
        viewForm.setCommandListener(this);
        int index = getCGIndex(item);
        ChoiceGroup cg = (ChoiceGroup) item;
        boolean movie = cg.isSelected(0);
        int c = 0;
        for (int i = 0; i < times.length; i++)
            if (movieList.isSelected(movies[i]) && cinemaList.isSelected(cinemas[i]))
                if (c==index) {
                    c=i;
                    break;
                }
                else
                    c++;
        if (movie) {
            if (moviedesc[movies[c]]==null)
                moviedesc[movies[c]]=getDesc("http://mmm.belbios.nl/filminfo.wml?movie="+movieIDs[movies[c]]);
            viewForm.append(moviedesc[movies[c]]);
            viewForm.setTitle(movieList.getString(movies[c]));
        }
        else {
            if (cinemadesc[cinemas[c]]==null)
                cinemadesc[cinemas[c]]=getDesc("http://mmm.belbios.nl/ovinfo.wml?cinema="+cinemaIDs[cinemas[c]]);
            viewForm.append(cinemadesc[cinemas[c]]);
            viewForm.setTitle(cinemaList.getString(cinemas[c]));
        }
        Display.getDisplay(this).setCurrent(viewForm);
        if (movie)
            cg.setSelectedIndex(0,false);
        else
            cg.setSelectedIndex(1,false);
    }
    
    int getCGIndex(Item item) {
        int result = 0;
        int counter = 0;
        Form form = (Form) Display.getDisplay(this).getCurrent();
        for (int i = 0; i < form.size(); i++) {
            counter++;
            if (counter==3) {
                counter=0;
                result++;
            }
            if (item == form.get(i))
                return result;
        }
        return -1;
    }
    
    Form makeResultForm() {
        System.gc();
        Form result = new Form("");
        boolean[] movieflags = new boolean[movieList.size()];
        boolean[] cinemaflags = new boolean[cinemaList.size()];
        movieList.getSelectedFlags(movieflags);
        cinemaList.getSelectedFlags(cinemaflags);
        String[] movieSA = new String[movieList.size()];
        String[] cinemaSA = new String[cinemaList.size()];
        for (int i = 0; i < movieList.size(); i++)
            movieSA[i] = movieList.getString(i);
        for (int i = 0; i < cinemaList.size(); i++)
            cinemaSA[i] = cinemaList.getString(i);
        Calendar now = Calendar.getInstance();
        int addcounter = 0;
        for (int i = 0; i < times.length; i++)
            if (movieflags[movies[i]] && cinemaflags[cinemas[i]]) {
                addcounter++;
                if (addcounter>25)
                    break;
                ChoiceGroup cg = new ChoiceGroup("",Choice.MULTIPLE);
                cg.append(movieSA[movies[i]],null);
                cg.append(cinemaSA[cinemas[i]],null);
                Calendar c = Calendar.getInstance();
                c.setTime(new Date(times[i]));
                int mindif = c.get(Calendar.MINUTE) - now.get(Calendar.MINUTE);
                int hourdif = c.get(Calendar.HOUR_OF_DAY) - now.get(Calendar.HOUR_OF_DAY);
                if (mindif<0) {
                    mindif+=60;
                    hourdif--;
                }
                if ((c.before(now))&&((mindif!=0)&&(hourdif!=0))) {
                    mindif-=60;
                    hourdif++;
                }
                if (hourdif!=0)
                    result.append(hourdif+" uur en "+mindif+" minuten:");
                else
                    result.append(mindif+" minuten:");
                //result.append(c.toString());
                result.append(cg);
                try {
                    result.append(Image.createImage("/BiosClient/line.png"));
                } catch (Exception e)
                {}
            }
        if (result.size()==0)
            result.append("Geen voorstellingen ");

        result.setTitle("BiosClient");
        result.addCommand(movieCommand);
        result.addCommand(cinemaCommand);
        result.setCommandListener(this);
        result.setItemStateListener(this);
        return result;
    }
    
    
    void downloadData(String sstad) {
        Form form = new Form("bezig...");
        form.append("informatie word(t) ingeladen");
        Display.getDisplay(this).setCurrent(form);
        try {
            HttpConnection conn = (HttpConnection) Connector.open("http://nobsoft.com/"+sstad);
            DataInputStream dis = conn.openDataInputStream();
            int length=0;
            length=dis.readInt();
            times = new long[length];
            movies = new int[length];
            cinemas = new int[length];
            for (int i = 0; i < length; i++) {
                times[i] = dis.readLong();
                cinemas[i] = dis.readInt();
                movies[i] = dis.readInt();
            }
            length=dis.readInt();
            cinemaIDs = new int[length];
            cinemadesc = new String[length];
            for (int i = 0; i < length; i++) {
                cinemaIDs[i] = dis.readInt();
                cinemaList.append(dis.readUTF(),null);
                cinemaList.setSelectedIndex(i,true);
            }
            length=dis.readInt();
            movieIDs = new int[length];
            moviedesc = new String[length];
            for (int i = 0; i < length; i++) {
                movieIDs[i] = dis.readInt();
                movieList.append(dis.readUTF(),null);
                movieList.setSelectedIndex(i,true);
            }
            dis.close();
            conn.close();
        }
        catch (Exception e) {
            times = new long[0];
            movies = new int[0];
            cinemas = new int[0];
        }
    }
    
    String getDesc(String url) {
        Form form = new Form("bezig...");
        form.append("informatie word(t) ingeladen");
        Display.getDisplay(this).setCurrent(form);
        String result = new String();
        try {
            HttpConnection conn = (HttpConnection) Connector.open(url);
            InputStream is = conn.openInputStream();
            int ch;
            while ((ch = is.read()) != -1)
                result+=(char) ch;
        }
        catch (Exception e) {
            result+=".";
        }
        return result.substring(result.indexOf("<p align=\"left\"")+17,result.indexOf("<br />"));
    }
    
}
