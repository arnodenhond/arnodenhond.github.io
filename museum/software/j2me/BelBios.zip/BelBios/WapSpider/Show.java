package WapSpider;
import java.io.*;
public class Show implements Serializable {

    public long date;
    public int film;
    public int bios;
    
    public Show(long date, int film, int bios) {
        this.date=date;
        this.film=film;
        this.bios=bios;
    }
    
}
