package WapSpider;

import java.net.*;
import java.io.*;
import java.util.*;
import java.lang.*;

public class WapSpider {
    
    public WapSpider() {
    }

    public static void main(String[] args) throws Exception {
        ArrayList steden = doCities();
        for (int k = 0; k < steden.size(); k++) {
            wacht();
            Stad stad = (Stad) steden.get(k);
            stad.films = doMovies(stad.id);
            for (int i = 0; i < stad.films.size(); i++) {
                wacht();
                NaamID film = (NaamID) stad.films.get(i);
                ArrayList bioses = doBioscopen(stad.id, film.id);
                for (int j = 0; j < bioses.size(); j++) {
                    wacht();
                    NaamID bios = (NaamID) bioses.get(j);
                    if (findNaamID(bios.id, stad.bioses)==null)
                        stad.bioses.add(bios);
                    stad.shows.addAll(doShows(film.id, bios.id));
                    System.out.println("            "+k+"/"+steden.size());
                }
            }
        }
        
        savedb(steden);
        
        for (int i = 0; i < steden.size(); i++) {
            Stad stad = (Stad) steden.get(i);
            System.out.println(stad.naam+" bios:"+stad.bioses.size()+" film:"+stad.films.size()+" show:"+stad.shows.size());
        }
    }
    
    static void wacht() {
        for (int i = 0; i < 100000000; i++);
    }
    
    static ArrayList doCities() throws Exception {
        System.out.println("cities");
        ArrayList result = new ArrayList();
        String cities = new String();
        for (int i = 0; i < 11; i++)
            cities+=getPage("http://www.belbios.nl/orange/lijst.wml?item=stad&id=&q=&start="+(i*9));
        int index=0;
        while (cities.indexOf("<a href=\"zoek.wml",index)!=-1) {
            index = cities.indexOf("<a href=\"zoek.wml",index);
            String link = cities.substring(index,cities.indexOf("</a>",index));
            String id = link.substring(link.indexOf("id=")+3,link.indexOf("\">"));
            String stad = link.substring(link.indexOf("\">")+2);
            result.add(new Stad(stad,Integer.valueOf(id).intValue()));
            index++;
        }
        return result;
    }
    
    
    static ArrayList doMovies(int stadid) throws Exception {
        System.out.println("movies");
        ArrayList result = new ArrayList();
        String movies = getPage("http://www.belbios.nl/orange/lijst.wml?item=film&id="+stadid+"&q=&start=0");
        if (movies.indexOf("1-9 van")!=-1) { // meerdere paginas downen
            //uitzoeken hoeveel dan
            int startpos = movies.indexOf("1-9 van");
            int totalmovies = Integer.valueOf(movies.substring(startpos+8,movies.indexOf(" ",startpos+8))).intValue();
            //totalmovies-=9;
            int pages = totalmovies/9;
            for (int i = 0; i <pages; i++)
                movies+=getPage("http://www.belbios.nl/orange/lijst.wml?item=film&id="+stadid+"&q=&start="+((i+1)*9));
        }
        int index=0;
        while (movies.indexOf("<a href=\"/orange/lijst.wml?s=",index)!=-1) {
            index = movies.indexOf("<a href=\"/orange/lijst.wml?s=",index);
            String link = movies.substring(index,movies.indexOf("</a>",index));
            String id = link.substring(link.indexOf(";f=")+3,link.indexOf("\">"));
            String movie = link.substring(link.indexOf("\">")+2);
            if (movie.indexOf("&")!=-1) {
                //String decode = movie.substring(movie.indexOf("&")+2,movie.indexOf("&")+5);
                //char ch = (char) new Integer(decode).intValue();
                movie = movie.substring(0,movie.indexOf("&"))+movie.substring(movie.indexOf("&")+6);
            }
            NaamID n = new NaamID(movie,Integer.valueOf(id).intValue());
            result.add(n);
            index++;
        }
        return result;
    }
    
    static ArrayList doBioscopen(int stadid, int filmid) throws Exception {
        System.out.println("bioscopen");
        ArrayList result = new ArrayList();
        String bioscopen = getPage("http://mmm.belbios.nl/cinemas.wml?city="+stadid+"&movie="+filmid);
        int index=0;
        while (bioscopen.indexOf("<a href=\"times.wml",index)!=-1) {
            index = bioscopen.indexOf("<a href=\"times.wml",index);
            String link = bioscopen.substring(index,bioscopen.indexOf("</a>",index));
            String id = link.substring(link.indexOf(";cinema=")+8,link.indexOf("\">"));
            String bios = link.substring(link.indexOf("\">")+2);
            if (bios.indexOf("&")!=-1) {
//                String decode = bios.substring(bios.indexOf("&")+2,bios.indexOf("&")+5);
  //              char ch = (char) new Integer(decode).intValue();
                bios = bios.substring(0,bios.indexOf("&"))+bios.substring(bios.indexOf("&")+6);
            }
            NaamID n = new NaamID(bios,Integer.valueOf(id).intValue());
            result.add(n);
            index++;
        }
        return result;
    }
    
    static ArrayList doShows(int filmid, int biosid) throws Exception {
        System.out.println("show");
        ArrayList result = new ArrayList();
        String showstring = getPage("http://www.belbios.nl/orange/lijst.wml?&f="+filmid+"&b="+biosid);
        if (showstring.indexOf("1-9 van")!=-1) { // meerdere paginas downen
            //uitzoeken hoeveel dan
            int startpos = showstring.indexOf("1-9 van");
            int totalshows = Integer.valueOf(showstring.substring(startpos+8,showstring.indexOf(" ",startpos+8))).intValue();
            //totalmovies-=9;
            int pages = totalshows/9;
            for (int i = 0; i <pages; i++)
                showstring+=getPage("http://www.belbios.nl/orange/lijst.wml?&f="+filmid+"&b="+biosid+"&start="+((i+1)*9));
        }
        int index = 0;
        if (showstring.indexOf("input.wml?pid=")!=-1) {
            while (showstring.indexOf("input.wml?pid=",index)!=-1) {
                index = showstring.indexOf("input.wml?pid=",index);
                String date = showstring.substring(index+23, showstring.indexOf("</",index));
                Calendar c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("UTC"));
                c.set(Calendar.DATE,new Integer(date.substring(3,5)).intValue());
                c.set(Calendar.MONTH,new Integer(date.substring(6,8)).intValue()-1);
                c.set(Calendar.HOUR_OF_DAY,new Integer(date.substring(9,11)).intValue());
                c.set(Calendar.MINUTE,new Integer(date.substring(12,14)).intValue());
                c.set(Calendar.SECOND,0);
                result.add(new Show(c.getTimeInMillis(),filmid,biosid));
                index++;
            }
        }
        else {
            while (showstring.indexOf("&nbsp;&nbsp;(",index)!=-1) {
                index = showstring.indexOf("&nbsp;&nbsp;(",index);
                String date = showstring.substring(index+13, showstring.indexOf("<br />",index));
                Calendar c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("UTC"));
                c.set(Calendar.DATE,new Integer(date.substring(3,5)).intValue());
                c.set(Calendar.MONTH,new Integer(date.substring(6,8)).intValue()-1);
                c.set(Calendar.HOUR_OF_DAY,new Integer(date.substring(9,11)).intValue());
                c.set(Calendar.MINUTE,new Integer(date.substring(12,14)).intValue());
                c.set(Calendar.SECOND,0);
                result.add(new Show(c.getTimeInMillis(),filmid,biosid));
                index++;
            }
            
        }
        return result;
    }
    
    static String findNaamID(int id, ArrayList list) {
        for (int i = 0; i < list.size(); i++) {
            NaamID n = (NaamID) list.get(i);
            if (n.id==id)
                return n.naam;            Stad stad = new Stad("leiden",67);
                
        }
        return null;
    }
    
    static String getPage(String purl) throws Exception {
        URL url = new URL(purl);
        HttpURLConnection huc = (HttpURLConnection) url.openConnection();
        InputStreamReader isr = new InputStreamReader(huc.getInputStream());
        String content = new String();
        while (isr.ready())
            content+=(char) isr.read();
        return content;
    }
    
    static void savedb(ArrayList db) throws Exception {
        File f = new File("F:\\NEWDATA\\NOBSOFT\\BelBios\\WapSpider\\belbios.db");
        FileOutputStream fos = new FileOutputStream(f);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(db);
        oos.flush();
        fos.close();
    }
}
