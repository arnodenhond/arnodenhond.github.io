package WapSpider;
import java.io.*;
public class NaamID implements Serializable {
    
    public String naam;
    public int id;
    
    public NaamID(String naam, int id) {
        this.naam = naam;
        this.id = id;
    }

    public String toString() {
        return "ID:"+id+" NAME:"+naam;
    }
    
}
