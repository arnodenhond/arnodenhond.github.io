package WapSpider;
import java.util.*;
import java.lang.*;
import java.io.*;
public class Stad implements Serializable {
    
    public String naam;
    public int id;
    public ArrayList films;
    public ArrayList bioses;
    public ArrayList shows;
    
    public Stad(String naam, int id) {
        this.naam = naam;
        this.id = id;
        films = new ArrayList();
        bioses = new ArrayList();
        shows = new ArrayList();
    }
    
    public String toString() {
        return "ID:"+id+" NAME:"+naam;
    }
    
}
