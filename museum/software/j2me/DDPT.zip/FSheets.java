package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FSheets extends List implements CommandListener
{

  DDPT ddpt;

  Sheet[] sheets;
  FStats[] fstats;

  Command _new = new Command("New",Command.BACK,0);
  Command del = new Command("Delete",Command.SCREEN,0);

  FSheets(DDPT ddpt)
  {
    super("Select a sheet",List.IMPLICIT);
    this.ddpt=ddpt;
    sheets=new Sheet[0];
    fstats=new FStats[0];
    addCommand(_new);
    addCommand(del);
    setCommandListener(this);
    if (!loadRecords());
      Display.getDisplay(ddpt).setCurrent(new Alert("load error"));
    for (int i = 0; i < sheets.length; i++)
      append(sheets[i].name+" "+sheets[i].race+" "+sheets[i]._class, null);
  }

  boolean loadRecords()
  {
    try {
//    RecordStore.deleteRecordStore("Sheets");
    RecordStore rs = RecordStore.openRecordStore("Sheets",true);
    sheets = new Sheet[rs.getNumRecords()];
    fstats = new FStats[rs.getNumRecords()];
    for (int i = 1; i <= rs.getNumRecords(); i++)
    {
      byte[] data = rs.getRecord(i);
  		ByteArrayInputStream bais = new ByteArrayInputStream(data);
 		  DataInputStream dis  = new DataInputStream(bais);
      sheets[i-1] = new Sheet(dis);
      fstats[i-1] = new FStats(ddpt,sheets[i-1]);
      dis.close();
    }
    rs.closeRecordStore();
    return true;
    } catch (Exception e) {return false;}
  }

  boolean saveRecord(int index)
  {
  try {
    RecordStore rs = RecordStore.openRecordStore("Sheets",true);
   	ByteArrayOutputStream baos = new ByteArrayOutputStream();
   	DataOutputStream dos = new DataOutputStream(baos);
    sheets[index-1].write(dos);
   	byte[] data = baos.toByteArray();
    dos.close();
    if (index<=rs.getNumRecords())
      rs.setRecord(index,data,0,data.length);
    else
      rs.addRecord(data,0,data.length);
    rs.closeRecordStore();
    return true;
    } catch (Exception e) {return false;}
  }

  boolean deleteRecord(int index)
  {
    try {
    RecordStore.deleteRecordStore("Sheets");
    RecordStore rs = RecordStore.openRecordStore("Sheets",true);
    for (int i = 0; i < sheets.length; i++)
    {
     	ByteArrayOutputStream baos = new ByteArrayOutputStream();
     	DataOutputStream dos = new DataOutputStream(baos);
      sheets[i].write(dos);
     	byte[] data = baos.toByteArray();
      dos.close();
      rs.addRecord(data,0,data.length);
    }
    rs.closeRecordStore();
    return true;
    } catch (Exception e) {return false;}
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==_new)
    {
      Sheet[] temp = new Sheet[sheets.length+1];
      FStats[] ts = new FStats[sheets.length+1];
      System.arraycopy(sheets,0,temp,0,sheets.length);
      System.arraycopy(fstats,0,ts,0,sheets.length);
      temp[sheets.length] = new Sheet();
      ts[sheets.length] = new FStats(ddpt,temp[sheets.length]);
      append(temp[sheets.length].name+" "+temp[sheets.length].race+" "+temp[sheets.length]._class, null);
      sheets = temp;
      fstats = ts;
      if (!saveRecord(sheets.length))
        Display.getDisplay(ddpt).setCurrent(new Alert("save error"));
    }
    if (c==del)
    {
      int index = getSelectedIndex();
      if (index!=-1)
      {
        Sheet[] temp = new Sheet[sheets.length-1];
        FStats[] ts = new FStats[sheets.length-1];
        System.arraycopy(sheets,0,temp,0,index);
        System.arraycopy(sheets,index+1,temp,index,sheets.length-(index+1));
        System.arraycopy(fstats,0,ts,0,index);
        System.arraycopy(fstats,index+1,ts,index,sheets.length-(index+1));
        sheets=temp;
        fstats=ts;
        if (!deleteRecord(index+1))
          Display.getDisplay(ddpt).setCurrent(new Alert("delete error"));
        delete(index);
      }
    }
    if (c==List.SELECT_COMMAND)
    {
      Display.getDisplay(ddpt).setCurrent(fstats[getSelectedIndex()]);
    }
  }
}

