package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class DDPT extends MIDlet
{

  FSheets fsheets;

  public DDPT()
  {
  }

  public void startApp()
  {
    fsheets = new FSheets(this);
    Display.getDisplay(this).setCurrent(fsheets);
  }

  public void pauseApp()
  {
  }

  public void destroyApp(boolean b)
  {
  }

}