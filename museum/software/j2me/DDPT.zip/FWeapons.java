package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FWeapons extends List implements CommandListener
{

  DDPT ddpt;
  Sheet s;
  FEditweapon[] feditweapon;

  Command add = new Command("Add",Command.SCREEN,0);
  Command delete = new Command("Delete",Command.SCREEN,0);
  Command done = new Command("Done",Command.BACK,0);

  FWeapons(DDPT ddpt, Sheet s)
  {
    super("DDPT",List.IMPLICIT);
    this.ddpt = ddpt;
    this.s = s;
    setItems();
    addCommand(add);
    addCommand(delete);
    addCommand(done);
    setCommandListener(this);

    feditweapon = new FEditweapon[s.weapons.length];
    for (int i = 0; i < s.weapons.length; i++)
      feditweapon[i] = new FEditweapon(ddpt, s.weapons[i]);

  }

  void setItems()
  {
    while (size()>0)
      delete(0);
    for (int i = 0; i < s.weapons.length; i++)
      append(s.weapons[i].toString(),null);
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
    {
      Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat);
    }
    if (c==add)
    {
      Weapon w = new Weapon();
      FEditweapon fw = new FEditweapon(ddpt,w);
      Weapon[] tempweapons = new Weapon[s.weapons.length+1];
      FEditweapon[] tempfw = new FEditweapon[feditweapon.length+1];
      System.arraycopy(s.weapons,0,tempweapons,0,s.weapons.length);
      System.arraycopy(feditweapon,0,tempfw,0,feditweapon.length);
      tempweapons[s.weapons.length] = w;
      tempfw[feditweapon.length] = fw;
      s.weapons = tempweapons;
      feditweapon = tempfw;
      setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
    }
    if (c==delete)
    {
      Weapon[] tempweapons = new Weapon[s.weapons.length-1];
      FEditweapon[] tempfw = new FEditweapon[feditweapon.length-1];
      System.arraycopy(s.weapons,0,tempweapons,0,getSelectedIndex());
      System.arraycopy(feditweapon,0,tempfw,0,getSelectedIndex());
      System.arraycopy(s.weapons,getSelectedIndex()+1,tempweapons,getSelectedIndex(),s.weapons.length-(getSelectedIndex()+1));
      System.arraycopy(feditweapon,getSelectedIndex()+1,tempfw,getSelectedIndex(),feditweapon.length-(getSelectedIndex()+1));
      s.weapons = tempweapons;
      feditweapon = tempfw;
      setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
    }
    if (c==List.SELECT_COMMAND)
    {
      Display.getDisplay(ddpt).setCurrent(feditweapon[getSelectedIndex()]);
    }
  }

}