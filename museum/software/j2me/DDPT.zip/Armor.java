package DDPT;

import java.io.*;

  public class Armor
  {
    String name;
    int type;
    int armor_bonus;
    int max_dex_bonus;
    int check_penalty;
    int spell_failure;
    int speed;
    int weight;
    String special_properties;

    public Armor()
    {
      name = new String();
      type = 0;
      armor_bonus = 0;
      max_dex_bonus = 0;
      check_penalty = 0;
      spell_failure = 0;
      speed = 0;
      weight = 0;
      special_properties = new String();
    }

    public Armor(DataInputStream dis) throws Exception
    {
      name = dis.readUTF();
      type = dis.readInt();
      armor_bonus = dis.readInt();
      max_dex_bonus = dis.readInt();
      check_penalty = dis.readInt();
      spell_failure = dis.readInt();
      speed = dis.readInt();
      weight = dis.readInt();
      special_properties = dis.readUTF();
    }

    void write(DataOutputStream dos) throws Exception
    {
      dos.writeUTF(name);
      dos.writeInt(type);
      dos.writeInt(armor_bonus);
      dos.writeInt(max_dex_bonus);
      dos.writeInt(check_penalty);
      dos.writeInt(spell_failure);
      dos.writeInt(speed);
      dos.writeInt(weight);
      dos.writeUTF(special_properties);
    }

    public String toString()
    {
      return name+" ("+armor_bonus+")";
    }
  }
