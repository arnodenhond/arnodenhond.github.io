package DDPT;

import javax.microedition.lcdui.*;

public class FStats extends Form implements CommandListener
{
  DDPT ddpt;
  Sheet s;

  StringItem name = new StringItem("Name:",null);
  StringItem _class = new StringItem("Class:",null);
  StringItem race = new StringItem("Race:",null);
  StringItem alignment = new StringItem("Alignment:",null);
  StringItem deity = new StringItem("Deity:",null);
  Gauge level = new Gauge("Level:",false,1,0);
  StringItem size = new StringItem("Size:",null);
  StringItem age = new StringItem("Age:",null);
  StringItem gender = new StringItem("Gender:",null);
  StringItem copper = new StringItem("Money:",null);
  StringItem height = new StringItem("Height:",null);
  StringItem weight = new StringItem("Weight:",null);
  StringItem handed = new StringItem("Handed:",null);
  StringItem speed = new StringItem("Speed:",null);
  Gauge load = new Gauge("Load:",false,1,0);
  StringItem str = new StringItem(null,"Strength:");
  StringItem dex = new StringItem(null,"Dexterity:");
  StringItem con = new StringItem(null,"Constitution:");
  StringItem _int = new StringItem(null,"Intelligence:");
  StringItem wis = new StringItem(null,"Wisdom:");
  StringItem cha = new StringItem(null,"Charisma:");

  Command combat = new Command("Combat",Command.BACK,0);
  Command rolldice = new Command("Roll dice",Command.SCREEN,0);
  Command abilities = new Command("Abilities",Command.SCREEN,0);
  Command skills = new Command("Skills",Command.SCREEN,0);
  Command money = new Command("Money",Command.SCREEN,0);
  Command equipment = new Command("Equipment",Command.SCREEN,0);
  Command experience = new Command("Experience",Command.SCREEN,0);
  Command editstats = new Command("Edit",Command.SCREEN,0);
  Command sheets = new Command("Sheets",Command.SCREEN,0);

  FEditstats feditstats;
  FCombat fcombat;
  FAbilities fabilities;

  FStats(DDPT ddpt, Sheet s)
  {
    super("DDPT");
    this.ddpt=ddpt;
    this.s=s;

    setItems();

    append(name);
    append(_class);
    append(race);
    append(alignment);
    append(deity);
    append(level);
    append(size);
    append(age);
    append(gender);
    append(height);
    append(weight);
    append(copper);
    append(handed);
    append(speed);
    append(load);
    append(new StringItem("Abilities",null));
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(str);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(dex);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(con);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(_int);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(wis);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(cha);

    addCommand(combat);
    addCommand(rolldice);
    addCommand(abilities);
    addCommand(skills);
    addCommand(money);
    addCommand(equipment);
    addCommand(experience);
    addCommand(editstats);
    addCommand(sheets);
    setCommandListener(this);

    feditstats = new FEditstats(ddpt,s);
    fcombat = new FCombat(ddpt,s);
    fabilities = new FAbilities(ddpt,s);
  }

  void setItems()
  {
    name.setText(s.name);
    _class.setText(s._class);
    race.setText(s.race);
    String salignment = new String();
    switch (s.alignment1)
    {
      case 0:salignment="Chaotic-";break;
      case 1:salignment="Neutral-";break;
      case 2:salignment="Orderly-";break;
    }
    switch (s.alignment2)
    {
      case 0:salignment+="Evil";break;
      case 1:salignment+="Neutral";break;
      case 2:salignment+="Good";break;
    }
    if (s.alignment1==1 && s.alignment2==1)
      salignment="True Neutral";
    alignment.setText(salignment);
    deity.setText(s.deity);
    int remain = s.experience;
    int ilevel = 0;
    while (remain>=0)
    {
      ilevel++;
      remain-=(ilevel*1000);
    }
    level.setLabel("Level ("+ilevel+"):");
    level.setMaxValue((ilevel*1000)+1);
    level.setValue(s.experience-((ilevel-1)*1000));
    String ssize = new String();
    switch (s.size)
    {
      case 0:ssize="Small";break;
      case 1:ssize="Medium";break;
      case 2:ssize="Large";break;
    }
    size.setText(ssize);
    age.setText(String.valueOf(s.age));
    gender.setText((s.gender?"Male":"Female"));
    height.setText(s.height+" ft");
    weight.setText(s.weight+" lb");
    copper.setText(calc_copper());
    String shanded = new String();
    switch (s.handed)
    {
      case 0:shanded="Left";break;
      case 1:shanded="Right";break;
      case 2:shanded="Both";break;
    }
    handed.setText(shanded);
    speed.setText(String.valueOf(s.speed));
    load.setMaxValue((s.load)+1);
    int iload = 0;
    for (int i = 0; i < s.equipments.length; i++)
      iload += (s.equipments[i].weight * s.equipments[i].amount);
    load.setValue(iload);

    str.setText("Strength: "+s.curstr+" ["+modified(s.curstr)+"]");
    if (s.curstr!=s.str)
      str.setText(str.getText()+" ("+s.str+" ["+modified(s.str)+"])");
    dex.setText("Dexterity: "+s.curdex+" ["+modified(s.curdex)+"]");
    if (s.curdex!=s.dex)
      dex.setText(dex.getText()+" ("+s.dex+" ["+modified(s.dex)+"])");
    con.setText("Constitution: "+s.curcon+" ["+modified(s.curcon)+"]");
    if (s.curcon!=s.con)
      con.setText(con.getText()+" ("+s.con+" ["+modified(s.con)+"])");
    _int.setText("Intelligence: "+s.curint+" ["+modified(s.curint)+"]");
    if (s.curint!=s._int)
      _int.setText(_int.getText()+" ("+s._int+" ["+modified(s._int)+"])");
    wis.setText("Wisdom: "+s.curwis+" ["+modified(s.curwis)+"]");
    if (s.curwis!=s.wis)
      wis.setText(wis.getText()+" ("+s.wis+" ["+modified(s.wis)+"])");
    cha.setText("Charisma: "+s.curcha+" ["+modified(s.curcha)+"]");
    if (s.curcha!=s.cha)
      cha.setText(cha.getText()+" ("+s.cha+" ["+modified(s.cha)+"])");
  }

  int modified(int score)
  {
    if (score%2==1)
      score--;
    return (score-10)/2;
  }

  String calc_copper()
  {
    int topper = s.copper;
    String result = new String();
    int copper = topper % 10;
    int silver = ((topper % 100)-copper)/10;
    int gold = (((topper % 1000)-silver)-copper)/100;
    int platinum = ((((topper % 10000)-gold)-silver)-copper)/1000;;
    if (platinum!=0)
    {
      result+=platinum+" platinum";
      if (gold!=0)
        result+=", ";
      else
        result+=" ";
    }
    if (gold!=0)
    {
      result+=gold+" gold";
      if (silver!=0)
        result+=", ";
      else
        result+=" ";
    }
    if (silver!=0)
    {
      result+=silver+" silver";
      if (copper!=0)
        result+=", ";
      else
        result+=" ";
    }
    if (copper!=0 | result.equals(""))
      result+=copper+" copper";
    return result;
  }


  public void commandAction (Command c, Displayable d)
  {
    if (c==sheets)
    {
      ddpt.fsheets.saveRecord(ddpt.fsheets.getSelectedIndex()+1);
      Display.getDisplay(ddpt).setCurrent(ddpt.fsheets);
    }
    if (c==editstats)
      Display.getDisplay(ddpt).setCurrent(feditstats);
    if (c==combat)
      Display.getDisplay(ddpt).setCurrent(fcombat);
    if (c==abilities)
      Display.getDisplay(ddpt).setCurrent(fabilities);
  }

}

