package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FEditweapon extends Form implements CommandListener
{

  DDPT ddpt;
  Weapon w;

  TextField name = new TextField("Name:","",15,TextField.ANY);
  TextField attack_bonus = new TextField("Attack Bonus:","0",5,TextField.NUMERIC);
  TextField damage_sides = new TextField("Damage Sides:","0",5,TextField.NUMERIC);
  TextField damage_amount = new TextField("Damage Amount:","0",5,TextField.NUMERIC);
  TextField damage_modifier = new TextField("Damage Modifier:","0",5,TextField.NUMERIC);
  TextField crit_range = new TextField("Critical-hit Range:","0",5,TextField.NUMERIC);
  TextField crit_mult = new TextField("Critical-hit Multiplier:","0",5,TextField.NUMERIC);
  TextField range = new TextField("Range:","0",5,TextField.NUMERIC);
  TextField weight = new TextField("Weight:","0",5,TextField.NUMERIC);
  String[] stype = new String[] {"Piercing","Bludgeoning","Slashing"};
  ChoiceGroup type = new ChoiceGroup("Type:",ChoiceGroup.EXCLUSIVE,stype,null);
  String[] ssize = new String[] {"Small","Medium","Large"};
  ChoiceGroup size = new ChoiceGroup("Size:",ChoiceGroup.EXCLUSIVE,ssize,null);
  TextField special_properties = new TextField("Special Properties:","",30,TextField.ANY);

  Command done = new Command("Done",Command.BACK,0);
  Command cancel = new Command("Cancel",Command.SCREEN,0);

  FEditweapon(DDPT ddpt, Weapon w)
  {
    super("DDPT");
    this.ddpt = ddpt;
    this.w = w;

    append(name);
    append(attack_bonus);
    append(damage_sides);
    append(damage_amount);
    append(damage_modifier);
    append(crit_range);
    append(crit_mult);
    append(range);
    append(weight);
    append(type);
    append(size);
    append(special_properties);

    setItems();

    addCommand(done);
    addCommand(cancel);
    setCommandListener(this);
  }

  void setItems()
  {
    name.setString(w.name);
    attack_bonus.setString(String.valueOf(w.attack_bonus));
    damage_sides.setString(String.valueOf(w.damage_sides));
    damage_amount.setString(String.valueOf(w.damage_amount));
    damage_modifier.setString(String.valueOf(w.damage_modifier));
    crit_range.setString(String.valueOf(w.crit_range));
    crit_mult.setString(String.valueOf(w.crit_mult));
    range.setString(String.valueOf(w.range));
    weight.setString(String.valueOf(w.weight));
    type.setSelectedIndex(w.type,true);
    size.setSelectedIndex(w.size,true);
    special_properties.setString(w.special_properties);
  }

  void saveItems()
  {
    w.name=name.getString();
    w.attack_bonus = Integer.valueOf(attack_bonus.getString()).intValue();
    w.damage_sides = Integer.valueOf(damage_sides.getString()).intValue();
    w.damage_amount = Integer.valueOf(damage_amount.getString()).intValue();
    w.damage_modifier = Integer.valueOf(damage_modifier.getString()).intValue();
    w.crit_range = Integer.valueOf(crit_range.getString()).intValue();
    w.crit_mult = Integer.valueOf(crit_mult.getString()).intValue();
    w.range = Integer.valueOf(range.getString()).intValue();
    w.weight = Integer.valueOf(weight.getString()).intValue();
    w.type = type.getSelectedIndex();
    w.size = size.getSelectedIndex();
    w.special_properties = special_properties.getString();
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
    {
      saveItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.fweapons.setItems();
    }
    else
      setItems();
    Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.fweapons);
  }
}
