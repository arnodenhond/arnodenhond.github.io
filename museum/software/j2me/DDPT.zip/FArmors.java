package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FArmors extends List implements CommandListener
{

  DDPT ddpt;
  Sheet s;
  FEditarmor[] feditarmor;

  Command add = new Command("Add",Command.SCREEN,0);
  Command delete = new Command("Delete",Command.SCREEN,0);
  Command done = new Command("Done",Command.BACK,0);

  FArmors(DDPT ddpt, Sheet s)
  {
    super("DDPT",List.IMPLICIT);
    this.ddpt = ddpt;
    this.s = s;
    setItems();
    addCommand(add);
    addCommand(delete);
    addCommand(done);
    setCommandListener(this);

    feditarmor = new FEditarmor[s.armors.length];
    for (int i = 0; i < s.armors.length; i++)
      feditarmor[i] = new FEditarmor(ddpt, s.armors[i]);

  }

  void setItems()
  {
    while (size()>0)
      delete(0);
    for (int i = 0; i < s.armors.length; i++)
      append(s.armors[i].toString(),null);
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
    {
      Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat);
    }
    if (c==add)
    {
      Armor w = new Armor();
      FEditarmor fw = new FEditarmor(ddpt,w);
      Armor[] temparmors = new Armor[s.armors.length+1];
      FEditarmor[] tempfw = new FEditarmor[feditarmor.length+1];
      System.arraycopy(s.armors,0,temparmors,0,s.armors.length);
      System.arraycopy(feditarmor,0,tempfw,0,feditarmor.length);
      temparmors[s.armors.length] = w;
      tempfw[feditarmor.length] = fw;
      s.armors = temparmors;
      feditarmor = tempfw;
      setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
    }
    if (c==delete)
    {
      Armor[] temparmors = new Armor[s.armors.length-1];
      FEditarmor[] tempfw = new FEditarmor[feditarmor.length-1];
      System.arraycopy(s.armors,0,temparmors,0,getSelectedIndex());
      System.arraycopy(feditarmor,0,tempfw,0,getSelectedIndex());
      System.arraycopy(s.armors,getSelectedIndex()+1,temparmors,getSelectedIndex(),s.armors.length-(getSelectedIndex()+1));
      System.arraycopy(feditarmor,getSelectedIndex()+1,tempfw,getSelectedIndex(),feditarmor.length-(getSelectedIndex()+1));
      s.armors = temparmors;
      feditarmor = tempfw;
      setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
    }
    if (c==List.SELECT_COMMAND)
    {
      Display.getDisplay(ddpt).setCurrent(feditarmor[getSelectedIndex()]);
    }
  }

}