package DDPT;

import java.io.*;


public class Sheet
{

  String name;
  String _class;
  String race;
  int alignment1; // orderly, neutral, chaotic
  int alignment2; // good, neutral, evil
  String deity;
  int size;
  int age;
  boolean gender; // true(1)=male
  int height;
  int weight;
  int handed; //0=left 1=right 2=both
  int speed;
  int load;

  int str;
  int dex;
  int con;
  int _int;
  int wis;
  int cha;
  int curstr;
  int curdex;
  int curcon;
  int curint;
  int curwis;
  int curcha;

  int hitpoints;
  int curhitpoints;

  int experience;
  int copper;

  int initiative;
  int armor;
  int attack;
  int melee;
  int ranged;

  int fortitude;
  int curfortitude;
  int reflex;
  int curreflex;
  int willpower;
  int curwillpower;

  Weapon[] weapons;
  Armor[] armors;
  Equipment[] equipments;

  public class Equipment
  {

    String name;
    int amount;
    int weight;

    public Equipment()
    {
      name = new String();
      amount = 0;
      weight = 0;
    }

    public Equipment(DataInputStream dis) throws Exception
    {
      name = dis.readUTF();
      amount = dis.readInt();
      weight = dis.readInt();
    }

    public void write(DataOutputStream dos) throws Exception
    {
      dos.writeUTF(name);
      dos.writeInt(amount);
      dos.writeInt(weight);
    }

  }

  public Sheet()
  {
    name=new String("new sheet");
    _class=new String();
    race=new String();
    alignment1=0;
    alignment2=0;
    deity=new String();
    size=0;
    age=0;
    gender=true;
    height=0;
    weight=0;
    handed=0;
    speed=0;
    load=0;

    str=0;
    dex=0;
    con=0;
    _int=0;
    wis=0;
    cha=0;
    curstr=0;
    curdex=0;
    curcon=0;
    curint=0;
    curwis=0;
    curcha=0;

    hitpoints=0;
    curhitpoints=0;

    experience=0;
    copper=0;

    initiative=0;
    armor=0;
    attack=0;
    melee=0;
    ranged=0;

    fortitude=0;
    curfortitude=0;
    reflex=0;
    curreflex=0;
    willpower=0;
    curwillpower=0;

    weapons = new Weapon[0];
    armors = new Armor[0];
    equipments = new Equipment[0];
  }

  public Sheet(DataInputStream dis) throws Exception
  {
    name=dis.readUTF();
    _class=dis.readUTF();
    race=dis.readUTF();
    alignment1=dis.readInt();
    alignment2=dis.readInt();
    deity=dis.readUTF();
    size=dis.readInt();
    age=dis.readInt();
    gender=dis.readBoolean();
    height=dis.readInt();
    weight=dis.readInt();
    handed=dis.readInt();
    speed=dis.readInt();
    load=dis.readInt();

    str=dis.readInt();
    dex=dis.readInt();
    con=dis.readInt();
    _int=dis.readInt();
    wis=dis.readInt();
    cha=dis.readInt();
    curstr=dis.readInt();
    curdex=dis.readInt();
    curcon=dis.readInt();
    curint=dis.readInt();
    curwis=dis.readInt();
    curcha=dis.readInt();

    hitpoints=dis.readInt();
    curhitpoints=dis.readInt();

    experience=dis.readInt();
    copper=dis.readInt();

    initiative=dis.readInt();
    armor=dis.readInt();
    attack=dis.readInt();
    melee=dis.readInt();
    ranged=dis.readInt();

    fortitude=dis.readInt();
    curfortitude=dis.readInt();
    reflex=dis.readInt();
    curreflex=dis.readInt();
    willpower=dis.readInt();
    curwillpower=dis.readInt();

    weapons = new Weapon[dis.readInt()];
    for (int i = 0; i < weapons.length; i++)
      weapons[i] = new Weapon(dis);
    armors = new Armor[dis.readInt()];
    for (int i = 0; i < armors.length; i++)
      armors[i] = new Armor(dis);
    equipments = new Equipment[dis.readInt()];
    for (int i = 0; i < equipments.length; i++)
      equipments[i] = new Equipment(dis);
  }

  void write(DataOutputStream dos) throws Exception
  {
    dos.writeUTF(name);
    dos.writeUTF(_class);
    dos.writeUTF(race);
    dos.writeInt(alignment1);
    dos.writeInt(alignment2);
    dos.writeUTF(deity);
    dos.writeInt(size);
    dos.writeInt(age);
    dos.writeBoolean(gender);
    dos.writeInt(height);
    dos.writeInt(weight);
    dos.writeInt(handed);
    dos.writeInt(speed);
    dos.writeInt(load);

    dos.writeInt(str);
    dos.writeInt(dex);
    dos.writeInt(con);
    dos.writeInt(_int);
    dos.writeInt(wis);
    dos.writeInt(cha);
    dos.writeInt(curstr);
    dos.writeInt(curdex);
    dos.writeInt(curcon);
    dos.writeInt(curint);
    dos.writeInt(curwis);
    dos.writeInt(curcha);

    dos.writeInt(hitpoints);
    dos.writeInt(curhitpoints);

    dos.writeInt(experience);
    dos.writeInt(copper);

    dos.writeInt(initiative);
    dos.writeInt(armor);
    dos.writeInt(attack);
    dos.writeInt(melee);
    dos.writeInt(ranged);

    dos.writeInt(fortitude);
    dos.writeInt(curfortitude);
    dos.writeInt(reflex);
    dos.writeInt(curreflex);
    dos.writeInt(willpower);
    dos.writeInt(curwillpower);

    dos.writeInt(weapons.length);
    for (int i = 0; i < weapons.length; i++)
      weapons[i].write(dos);
    dos.writeInt(armors.length);
    for (int i = 0; i < armors.length; i++)
      armors[i].write(dos);
    dos.writeInt(equipments.length);
    for (int i = 0; i < equipments.length; i++)
      equipments[i].write(dos);
  }

/*
  int alchemy;
  int animal_empathy;
  int appraise;
  int balance;
  int bluff;
  int climb;
  int concentration;
  int craft;
  int dechiper_script;
  int diplomacy;
  int disable_device;
  int disguise;
  int escape_artist;
  int forgery;
  int gather_information;
  int handle_animal;
  int heal;
  int hide;
  int innuendo;
  int intimidate;
  int intuit_direction;
  int jump;
  int knowledge_arcana;
  int knowledge_engineering;
  int knowledge_geography;
  int knowledge_history;
  int knowledge_local;
  int knowledge_nature;
  int knowledge_nobility;
  int knowledge_planes;
  int knowledge_religion;
  int listen;
  int move_silently;
  int open_lock;
  int perform;
  int pick_pocket;
  int profession;
  int read_lips;
  int ride;
  int scry;
  int search;
  int sense_motive;
  int spellcraft;
  int spot;
  int swim;
  int tumble;
  int use_magic_device;
  int use_rope;
  int wilderness_lore;
*/

}
