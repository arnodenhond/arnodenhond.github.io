package DDPT;

import javax.microedition.lcdui.*;

public class FEditstats extends Form implements CommandListener
{

  DDPT ddpt;
  Sheet s;

  TextField   tfname;
  TextField   tfclass;
  TextField   tfrace;
  ChoiceGroup cgalignment1;
  ChoiceGroup cgalignment2;
  TextField   tfdeity;
  ChoiceGroup cgsize;
  TextField   tfage;
  ChoiceGroup cggender;
  TextField   tfheight;
  TextField   tfweight;
  ChoiceGroup cghanded;
  TextField   tfspeed;
  TextField   tfload;

  Command done = new Command("Done",Command.BACK,0);
  Command cancel = new Command("Cancel",Command.SCREEN,0);

  public FEditstats(DDPT ddpt, Sheet s)
  {
    super("DDPT");
    this.ddpt = ddpt;
    this.s = s;

    setItems();

    append(tfname);
    append(tfclass);
    append(tfrace);
    append(cgalignment1);
    append(cgalignment2);
    append(tfdeity);
    append(cgsize);
    append(tfage);
    append(cggender);
    append(tfheight);
    append(tfweight);
    append(cghanded);
    append(tfspeed);
    append(tfload);

    addCommand(done);
    addCommand(cancel);
    setCommandListener(this);
  }

  void setItems()
  {
    tfname = new TextField("Name:",s.name,15,TextField.ANY);
    tfclass = new TextField("Class:",s._class,15,TextField.ANY);
    tfrace = new TextField("Race:",s.race,15,TextField.ANY);
    String[] salignment1 = {"Chaotic","Neutral","Orderly"};
    cgalignment1 = new ChoiceGroup("Alignment 1:",ChoiceGroup.EXCLUSIVE,salignment1,null);
    cgalignment1.setSelectedIndex(s.alignment1,true);
    String[] salignment2 = {"Evil","Neutral","Good"};
    cgalignment2 = new ChoiceGroup("Aligmnent 2:",ChoiceGroup.EXCLUSIVE,salignment2,null);
    cgalignment2.setSelectedIndex(s.alignment2,true);
    tfdeity = new TextField("Deity:",s.deity,15,TextField.ANY);
    String[] ssize = {"Small","Medium","Large"};
    cgsize = new ChoiceGroup("Size:",ChoiceGroup.EXCLUSIVE,ssize,null);
    cgsize.setSelectedIndex(s.size,true);
    tfage = new TextField("Age:",String.valueOf(s.age),5,TextField.NUMERIC);
    String[] sgender = {"Male","Female"};
    cggender = new ChoiceGroup("Gender:",ChoiceGroup.EXCLUSIVE,sgender,null);
    cggender.setSelectedIndex((s.gender?0:1),true);
    tfheight = new TextField("Height:",String.valueOf(s.height),5,TextField.NUMERIC);
    tfweight = new TextField("Weight:",String.valueOf(s.weight),5,TextField.NUMERIC);
    String[] shanded = {"Left","Right"};
    cghanded = new ChoiceGroup("Handed:",ChoiceGroup.MULTIPLE,shanded,null);
    switch (s.handed)
    {
      case 0:cghanded.setSelectedIndex(0,true);break;
      case 1:cghanded.setSelectedIndex(1,true);break;
      case 2:cghanded.setSelectedIndex(0,true);cghanded.setSelectedIndex(1,true);break;
    }
    tfspeed = new TextField("Speed:",String.valueOf(s.speed),5,TextField.NUMERIC);
    tfload = new TextField("Load:",String.valueOf(s.load),5,TextField.NUMERIC);
  }

  void saveItems()
  {
    s.name=tfname.getString();
    s._class=tfclass.getString();
    s.race=tfrace.getString();
    s.alignment1=cgalignment1.getSelectedIndex();
    s.alignment2=cgalignment2.getSelectedIndex();
    s.deity=tfdeity.getString();
    s.size=cgsize.getSelectedIndex();
    s.age=Integer.valueOf(tfage.getString()).intValue();
    s.gender=cggender.getSelectedIndex()==0;
    s.height=Integer.valueOf(tfheight.getString()).intValue();
    s.weight=Integer.valueOf(tfweight.getString()).intValue();
    s.handed =((cghanded.isSelected(0) && cghanded.isSelected(1))?2:(cghanded.isSelected(0)?0:1));
    s.speed=Integer.valueOf(tfspeed.getString()).intValue();
    s.load=Integer.valueOf(tfload.getString()).intValue();
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
    {
      saveItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].setItems();
      ddpt.fsheets.set(ddpt.fsheets.getSelectedIndex(),s.name+" "+s.race+" "+s._class,null);
    }
    Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()]);
  }
}