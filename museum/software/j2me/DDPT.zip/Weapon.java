package DDPT;

import java.io.*;

  public class Weapon
  {
    String name;
    int attack_bonus;
    int damage_sides;
    int damage_amount;
    int damage_modifier;
    int crit_range;
    int crit_mult;
    int range;
    int weight;
    int type;
    int size;
    String special_properties;

    public Weapon()
    {
      name = new String();
      attack_bonus = 0;
      damage_sides = 0;
      damage_amount = 0;
      damage_modifier = 0;
      crit_range = 0;
      crit_mult = 0;
      range = 0;
      weight = 0;
      type = 0;
      size = 0;
      special_properties = new String();
    }

    public Weapon(DataInputStream dis) throws Exception
    {
      name = dis.readUTF();
      attack_bonus = dis.readInt();
      damage_sides = dis.readInt();
      damage_amount = dis.readInt();
      damage_modifier = dis.readInt();
      crit_range = dis.readInt();
      crit_mult = dis.readInt();
      range = dis.readInt();
      weight = dis.readInt();
      type = dis.readInt();
      size = dis.readInt();
      special_properties = dis.readUTF();
    }

    void write(DataOutputStream dos) throws Exception
    {
      dos.writeUTF(name);
      dos.writeInt(attack_bonus);
      dos.writeInt(damage_sides);
      dos.writeInt(damage_amount);
      dos.writeInt(damage_modifier);
      dos.writeInt(crit_range);
      dos.writeInt(crit_mult);
      dos.writeInt(range);
      dos.writeInt(weight);
      dos.writeInt(type);
      dos.writeInt(size);
      dos.writeUTF(special_properties);
    }

    public String toString()
    {
      String result = name+" ("+damage_amount+"d"+damage_sides;
      if (damage_modifier!=0)
        result+="+"+damage_modifier;
      result+=")";
      return result;
    }
  }
