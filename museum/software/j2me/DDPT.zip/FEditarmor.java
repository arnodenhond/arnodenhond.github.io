package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FEditarmor extends Form implements CommandListener
{

  DDPT ddpt;
  Armor a;

  TextField name = new TextField("Name:","",15,TextField.ANY);
  TextField armor_bonus = new TextField("Armor Bonus:","0",5,TextField.NUMERIC);
  TextField max_dex_bonus = new TextField("Max. Dex. Bonus:","0",5,TextField.NUMERIC);
  TextField check_penalty = new TextField("Check Penalty:","0",5,TextField.NUMERIC);
  TextField spell_failure = new TextField("Spell Failure:","0",5,TextField.NUMERIC);
  TextField speed = new TextField("Speed:","0",5,TextField.NUMERIC);
  TextField weight = new TextField("Weight:","0",5,TextField.NUMERIC);
  String[] stype = new String[] {"Piercing","Bludgeoning","Slashing"};
  ChoiceGroup type = new ChoiceGroup("Type:",ChoiceGroup.EXCLUSIVE,stype,null);
  TextField special_properties = new TextField("Special Properties:","",30,TextField.ANY);

  Command done = new Command("Done",Command.BACK,0);
  Command cancel = new Command("Cancel",Command.SCREEN,0);

  FEditarmor(DDPT ddpt, Armor a)
  {
    super("DDPT");
    this.ddpt = ddpt;
    this.a = a;

    append(name);
    append(armor_bonus);
    append(max_dex_bonus);
    append(check_penalty);
    append(spell_failure);
    append(speed);
    append(weight);
    append(type);
    append(special_properties);

    setItems();

    addCommand(done);
    addCommand(cancel);
    setCommandListener(this);
  }

  void setItems()
  {
    name.setString(a.name);
    armor_bonus.setString(String.valueOf(a.armor_bonus));
    max_dex_bonus.setString(String.valueOf(a.max_dex_bonus));
    check_penalty.setString(String.valueOf(a.check_penalty));
    spell_failure.setString(String.valueOf(a.spell_failure));
    speed.setString(String.valueOf(a.speed));
    weight.setString(String.valueOf(a.weight));
    type.setSelectedIndex(a.type,true);
    special_properties.setString(a.special_properties);
  }

  void saveItems()
  {
    a.name=name.getString();
    a.armor_bonus = Integer.valueOf(armor_bonus.getString()).intValue();
    a.max_dex_bonus = Integer.valueOf(max_dex_bonus.getString()).intValue();
    a.check_penalty = Integer.valueOf(check_penalty.getString()).intValue();
    a.spell_failure = Integer.valueOf(spell_failure.getString()).intValue();
    a.speed = Integer.valueOf(speed.getString()).intValue();
    a.weight = Integer.valueOf(weight.getString()).intValue();
    a.type = type.getSelectedIndex();
    a.special_properties = special_properties.getString();
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
    {
      saveItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
      ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.farmors.setItems();
    }
    else
      setItems();
    Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.farmors);
  }
}