package DDPT;

import javax.microedition.lcdui.*;

public class FCombat extends Form implements CommandListener, ItemStateListener
{

  DDPT ddpt;
  Sheet s;

  ChoiceGroup cgweapons = new ChoiceGroup("Weapons:",ChoiceGroup.EXCLUSIVE);
  ChoiceGroup cgarmors = new ChoiceGroup("Armor:",ChoiceGroup.MULTIPLE);
  String[] sacopts = new String[] {"flat-footed"};
  ChoiceGroup cgarmorclass = new ChoiceGroup("Armor Class:",ChoiceGroup.MULTIPLE,sacopts,null);

  StringItem st_fort = new StringItem(null,"Fortitude:");
  StringItem st_ref = new StringItem(null,"Reflex:");
  StringItem st_will = new StringItem(null,"Willpower:");
  StringItem mod_init = new StringItem(null,"Initiative:");
  StringItem mod_attack = new StringItem(null,"Attack Bonus:");
  StringItem mod_armor = new StringItem(null,"Armor Bonus:");
  StringItem mod_melee = new StringItem(null,"Melee:");
  StringItem mod_ranged = new StringItem(null,"Ranged:");

  Command stats = new Command("Stats",Command.BACK,0);
  Command savingthrows = new Command("Saving Throws",Command.SCREEN,0);
  Command weapons = new Command("Weapons",Command.SCREEN,0);
  Command armors = new Command("Armor",Command.SCREEN,0);
  Command hitpoints = new Command("Hitpoints",Command.SCREEN,0);
  Command modifiers = new Command("Modifiers",Command.SCREEN,0);
  Command rollinit = new Command("Roll Initiative",Command.SCREEN,0);
  Command rollattack = new Command("Roll Attack",Command.SCREEN,0);
  Command rolldamage = new Command("Roll Damage",Command.SCREEN,0);

  FWeapons fweapons;
  FArmors farmors;

  public FCombat(DDPT ddpt, Sheet s)
  {
    super("DDPT");
    this.ddpt = ddpt;
    this.s = s;

    append(cgweapons);
    append(cgarmors);
    append(cgarmorclass);

    append(new StringItem("Modifiers:",null));
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(mod_init);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(mod_attack);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(mod_armor);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(mod_melee);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(mod_ranged);

    append(new StringItem("Saving Throws:",null));
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(st_fort);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(st_ref);
    append(new ImageItem(null,null,ImageItem.LAYOUT_NEWLINE_AFTER,null));
    append(st_will);

    setItems();

    addCommand(stats);
    addCommand(savingthrows);
    addCommand(weapons);
    addCommand(armors);
    addCommand(hitpoints);
    addCommand(modifiers);
    addCommand(rollinit);
    addCommand(rollattack);
    addCommand(rolldamage);
    setCommandListener(this);
    setItemStateListener(this);
    
    farmors = new FArmors(ddpt,s);
    fweapons = new FWeapons(ddpt,s);
  }

  int modified(int score)
  {
    if (score%2==1)
      score--;
    return (score-10)/2;
  }

  int getAC()
  {
    int iac = 10 + s.armor;
    for (int i = 0; i < cgarmors.size(); i++)
      if (cgarmors.isSelected(i))
        iac+=s.armors[i].armor_bonus;
    if (!cgarmorclass.isSelected(0))
      iac+=modified(s.curdex);
    return iac;
  }

  void setItems()
  {
    int selweapon = cgweapons.getSelectedIndex();
    boolean[] selarmors = new boolean[cgarmors.size()];
    cgarmors.getSelectedFlags(selarmors);

    while (cgweapons.size()>0)
      cgweapons.delete(0);
    while (cgarmors.size()>0)
      cgarmors.delete(0);
    for (int i = 0; i < s.weapons.length; i++)
      cgweapons.append(s.weapons[i].toString(),null);
    for (int i = 0; i < s.armors.length; i++)
      cgarmors.append(s.armors[i].toString(),null);
    if ((selweapon<cgweapons.size())&(selweapon!=-1))
      cgweapons.setSelectedIndex(selweapon,true);
    for (int i = 0; (i < selarmors.length) & (i < cgarmors.size()); i++)
      cgarmors.setSelectedIndex(i,selarmors[i]);

    cgarmorclass.setLabel("Armor Class: "+getAC());

    mod_init.setText("Initiative: "+s.initiative);
    mod_attack.setText("Attack Bonus: "+s.attack);
    mod_armor.setText("Armor Bonus: "+s.armor);
    mod_melee.setText("Melee: "+s.melee);
    mod_ranged.setText("Ranged: "+s.ranged);

    st_fort.setText("Fortitude: "+s.curfortitude);
    if (s.curfortitude!=s.fortitude)
      st_fort.setText(st_fort.getText()+" ("+s.fortitude+")");

    st_ref.setText("Reflex: "+s.curreflex);
    if (s.curreflex!=s.reflex)
      st_ref.setText(st_ref.getText()+" ("+s.reflex+")");

    st_will.setText("Willpower: "+s.curwillpower);
    if (s.curwillpower!=s.willpower)
      st_will.setText(st_will.getText()+" ("+s.willpower+")");

  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==stats)
      Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()]);
    if (c==weapons)
      Display.getDisplay(ddpt).setCurrent(fweapons);
    if (c==armors)
      Display.getDisplay(ddpt).setCurrent(farmors);
  }

  public void itemStateChanged(Item item)
  {
    cgarmorclass.setLabel("Armor Class: "+getAC());
  }

}