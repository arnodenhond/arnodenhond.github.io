package DDPT;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;

public class FAbilities extends List implements CommandListener
{

  DDPT ddpt;
  Sheet s;
  FEditability[] feditability = new FEditability[6];
//  FRollAbility frollability;

  Command edit = new Command("Edit",Command.SCREEN,0);
  Command done = new Command("Done",Command.BACK,0);

  FAbilities(DDPT ddpt, Sheet s)
  {
    super("DDPT",List.IMPLICIT);
    this.ddpt = ddpt;
    this.s = s;
    append("Strength",null);
    append("Dexterity",null);
    append("Constitution",null);
    append("Intelligence",null);
    append("Wisdom",null);
    append("Charisma",null);
    addCommand(edit);
    addCommand(done);
    setCommandListener(this);

    for (int i = 0; i < 6; i++)
      feditability[i] = new FEditability(ddpt,s,i);
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
      Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()]);
    if (c==edit)
      Display.getDisplay(ddpt).setCurrent(feditability[getSelectedIndex()]);
//    if (c==SELECT_COMMAND)
//      Display.getDisplay(ddpt).setCurrent();
  }

}