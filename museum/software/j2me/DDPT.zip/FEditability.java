package DDPT;

import javax.microedition.lcdui.*;

public class FEditability extends Form implements CommandListener, ItemStateListener
{

  DDPT ddpt;
  Sheet s;
  TextField original = new TextField("original value:","0",5,TextField.NUMERIC);
  TextField current = new TextField("current value:","0",5,TextField.NUMERIC);
  StringItem orig_mod = new StringItem("modified:","0");
  StringItem cur_mod = new StringItem("modified:","0");
  int ia;

  Command cancel = new Command("Cancel",Command.SCREEN,0);
  Command done = new Command("Done",Command.BACK,0);

  FEditability(DDPT ddpt, Sheet s, int ia)
  {
    super("DDPT");
    this.ddpt = ddpt;
    this.s = s;
    this.ia = ia;
    setItems();
    append(original);
    append(current);
    append(orig_mod);
    append(cur_mod);
    addCommand(cancel);
    addCommand(done);
    setCommandListener(this);
    setItemStateListener(this);
  }

  void setItems()
  {
    int abil = 0;
    int tabil = 0;
    switch (ia)
    {
      case 0:abil = s.str;tabil = s.curstr;break;
      case 1:abil = s.dex;tabil = s.curdex;break;
      case 2:abil = s.con;tabil = s.curcon;break;
      case 3:abil = s._int;tabil = s.curint;break;
      case 4:abil = s.wis;tabil = s.curwis;break;
      case 5:abil = s.cha;tabil = s.curcha;break;
    }
    original.setString(String.valueOf(abil));
    current.setString(String.valueOf(tabil));
    orig_mod.setText(String.valueOf(modified(abil)));
    cur_mod.setText(String.valueOf(modified(tabil)));
  }

  int modified(int score)
  {
    if (score%2==1)
      score--;
    return (score-10)/2;
  }

  public void commandAction (Command c, Displayable d)
  {
    if (c==done)
      saveItems();
    else
      setItems();
    Display.getDisplay(ddpt).setCurrent(ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fabilities);
  }

  void saveItems()
  {
    String str = original.getString();
    if (str.equals(""))
      str="0";
    switch (ia)
    {
      case 0:s.str = Integer.valueOf(str).intValue();s.curstr = Integer.valueOf(str).intValue();break;
      case 1:s.dex = Integer.valueOf(str).intValue();s.curdex = Integer.valueOf(str).intValue();break;
      case 2:s.con = Integer.valueOf(str).intValue();s.curcon = Integer.valueOf(str).intValue();break;
      case 3:s._int= Integer.valueOf(str).intValue();s.curint= Integer.valueOf(str).intValue();break;
      case 4:s.wis = Integer.valueOf(str).intValue();s.curwis = Integer.valueOf(str).intValue();break;
      case 5:s.cha = Integer.valueOf(str).intValue();s.curcha = Integer.valueOf(str).intValue();break;
    }
    ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].setItems();
    ddpt.fsheets.fstats[ddpt.fsheets.getSelectedIndex()].fcombat.setItems();
  }

  public void itemStateChanged(Item item)
  {
    String s = original.getString();
    if (s.equals(""))
      s="0";
    orig_mod.setText(String.valueOf(modified(Integer.valueOf(s).intValue())));
    s = current.getString();
    if (s.equals(""))
      s="0";
    cur_mod.setText(String.valueOf(modified(Integer.valueOf(s).intValue())));
  }
}