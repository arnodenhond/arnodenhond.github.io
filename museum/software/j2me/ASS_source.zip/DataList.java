package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class DataList extends List implements CommandListener
{

  ASS ass;
  long[] dates = new long[0];
  int[] amounts = new int[0];
  boolean[] cashbanks = new boolean[0];
  boolean[] inouts = new boolean[0];
  String[] strings = new String[0];
  int[][] datas = new int[0][0];
  int[] indices = new int[0];
  int[] scores = new int[0];

  Mutation tbNewData = null;
  Form fDelData = null;
  Balance fBalance = null;
  View viewData = null;
  Transfer transfer = null;

  Command cBack = new Command("Cancel",Command.BACK,0);
  Command cKeyword = new Command("Keywords",Command.BACK,0);
  Command cBalance = new Command("Balance",Command.SCREEN,0);
  Command cAddData = new Command("Add Mutation",Command.SCREEN,1);
  Command cTransfer = new Command("Transfer",Command.SCREEN,2);
  Command cView = new Command("View Mutation",Command.SCREEN,3);
  Command cNext = new Command("Next Mutation",Command.SCREEN,0);
  Command cGetKeys = new Command("Selected Keywords",Command.SCREEN,1);
  Command cDelData = new Command("Del Mutation",Command.SCREEN,2);

  public DataList(ASS ass)
  {
    super("Mutations",List.IMPLICIT);
    this.ass = ass;

    addCommand(cKeyword);
    addCommand(cBalance);
    addCommand(cView);
    setCommandListener(this);

  }

  void addData(long date, int amount, boolean cashbank, boolean inout, String comment, int[] kSearch)
  {
//add comment
    String[] newStrings = new String[strings.length+1];
    System.arraycopy(strings,0,newStrings,0,strings.length);
    newStrings[strings.length] = comment;
    strings = newStrings;
//add date
    long[] newDates = new long[dates.length+1];
    System.arraycopy(dates,0,newDates,0,dates.length);
    newDates[dates.length] = date;
    dates = newDates;
//add amount
    int[] newAmounts = new int[amounts.length+1];
    System.arraycopy(amounts,0,newAmounts,0,amounts.length);
    newAmounts[amounts.length] = amount;
    amounts = newAmounts;
//add cashbank
    boolean[] newCashbanks = new boolean[cashbanks.length+1];
    System.arraycopy(cashbanks,0,newCashbanks,0,cashbanks.length);
    newCashbanks[cashbanks.length] = cashbank;
    cashbanks = newCashbanks;
//add inout
    boolean[] newInouts = new boolean[inouts.length+1];
    System.arraycopy(inouts,0,newInouts,0,inouts.length);
    newInouts[inouts.length] = inout;
    inouts = newInouts;
//add searchkeywords to datalist
    int[][] newDatas = new int[datas.length+1][];
    System.arraycopy(datas,0,newDatas,0,datas.length);
    newDatas[datas.length]=ass.keyList.getSelectedKeywords();
    datas = newDatas;
//add this data to searchkeywords's datalists
    for (int i = 0; i < kSearch.length; i++)
    {
      int[] kds = new int[ass.keyList.keywords[kSearch[i]].length+1];
      System.arraycopy(ass.keyList.keywords[kSearch[i]],0,kds,0,ass.keyList.keywords[kSearch[i]].length);
      kds[ass.keyList.keywords[kSearch[i]].length] = datas.length-1;
      ass.keyList.keywords[kSearch[i]] = kds;
    }
  }

  void delData(int data)
  {
//delete comment
        String[] newStrings = new String[strings.length-1];
        System.arraycopy(strings,0,newStrings,0,data);
        System.arraycopy(strings,data+1,newStrings,data,strings.length-(data+1));
        strings = newStrings;
//delete date
        long[] newDates = new long[dates.length-1];
        System.arraycopy(dates,0,newDates,0,data);
        System.arraycopy(dates,data+1,newDates,data,dates.length-(data+1));
        dates = newDates;
//delete amount
        int[] newAmounts = new int[amounts.length-1];
        System.arraycopy(amounts,0,newAmounts,0,data);
        System.arraycopy(amounts,data+1,newAmounts,data,amounts.length-(data+1));
        amounts = newAmounts;
//delete cashbank
        boolean[] newCashbanks = new boolean[cashbanks.length-1];
        System.arraycopy(cashbanks,0,newCashbanks,0,data);
        System.arraycopy(cashbanks,data+1,newCashbanks,data,cashbanks.length-(data+1));
        cashbanks = newCashbanks;
//delete inout
        boolean[] newInouts = new boolean[inouts.length-1];
        System.arraycopy(inouts,0,newInouts,0,data);
        System.arraycopy(inouts,data+1,newInouts,data,inouts.length-(data+1));
        inouts = newInouts;
//update datas in keywordlist
        for (int i = 0; i < ass.keyList.keywords.length; i++)
          for (int j = 0; j < ass.keyList.keywords[i].length; j++)
          {
            if (ass.keyList.keywords[i][j]==data)
            {
              int[] newdatas = new int[ass.keyList.keywords[i].length-1];
              System.arraycopy(ass.keyList.keywords[i],0,newdatas,0,j);
              System.arraycopy(ass.keyList.keywords[i],j+1,newdatas,j,ass.keyList.keywords[i].length-(j+1));
              ass.keyList.keywords[i] = newdatas;
              j--;
            }
            else
              if (ass.keyList.keywords[i][j]>data)
                ass.keyList.keywords[i][j]--;
          }
//delete from datalist
        int[][] newDatas = new int[datas.length-1][];
        System.arraycopy(datas,0,newDatas,0,data);
        System.arraycopy(datas,data+1,newDatas,data,datas.length-(data+1));
        datas = newDatas;
  }


  String getSelectedDataKeywordString()
  {
      String title = new String();
      for (int i = 0; i < datas[getSelectedData()].length; i++)
        title+=ass.keyList.strings[datas[getSelectedData()][i]]+" ";
      return title;
  }

  int getSelectedData()
  {
    if (getSelectedIndex()!=-1)
      return indices[getSelectedIndex()];
    else
      return -1;
  }

  String makeDateString(long date)
  {
    String result = new String();
    Calendar c = Calendar.getInstance();
    c.setTime(new Date(date));
    String s = String.valueOf(c.get(Calendar.DAY_OF_MONTH));
    if (s.length()<2)
      s="0"+s;
    result+=s;
    s = String.valueOf(c.get(Calendar.MONTH)+1);
    if (s.length()<2)
      s="0"+s;
    result+="/"+s;
    return result;
  }

  String makeLongDateString(long date)
  {
    String result = new String();
    Calendar c = Calendar.getInstance();
    c.setTime(new Date(date));
    String s = String.valueOf(c.get(Calendar.DAY_OF_MONTH));
    if (s.length()<2)
      s="0"+s;
    result+=s;
    s = String.valueOf(c.get(Calendar.MONTH)+1);
    if (s.length()<2)
      s="0"+s;
    result+="/"+s;
    s = String.valueOf(c.get(Calendar.YEAR));
    if (s.length()<2)
      s="0"+s;
    result+="/"+s;
    result+="-";
    s=String.valueOf(c.get(Calendar.HOUR_OF_DAY));
    if (s.length()<2)
      s="0"+s;
    result+=s;
    result+=":";
    s=String.valueOf(c.get(Calendar.MINUTE));
    if (s.length()<2)
      s="0"+s;
    result+=s;

    return result;
  }


  String makeAmountString(int amount)
  {
    String s = String.valueOf(amount);
    boolean negative = s.substring(0,1).equals("-");
    if (negative)
      s = s.substring(1,s.length());
    if (s.length()<3)
      if (s.length()<2)
        s="0.0"+s;
      else
        s="0."+s;
    else
      s=s.substring(0,s.length()-2)+"."+s.substring(s.length()-2,s.length());
    if (negative)
      s = "-"+s;
    return s;
  }

  void update()
  {
    scores = new int[datas.length];
    int[] selkeys = ass.keyList.getSelectedKeywords();
    for (int i = 0; i < selkeys.length; i++)
      for (int j = 0; j < ass.keyList.keywords[selkeys[i]].length; j++)
        scores[ass.keyList.keywords[selkeys[i]][j]]++;
    indices = ass.getTop(scores,15);

    while(size()>0)
      delete(size()-1);
    for (int i = 0; i < indices.length; i++)
    {
      String s = new String();
      if (inouts[indices[i]])
        s+="< ";
      else
        s+="> ";
      if (cashbanks[indices[i]])
        s+="$ ";
      else
        s+="# ";
      s+=makeDateString(dates[indices[i]])+" ";
      s+=makeAmountString(amounts[indices[i]])+" ";
      s+=strings[indices[i]];
      append(s,null);
    }
    removeCommand(cAddData);
    removeCommand(cTransfer);
    if (ass.keyList.getSelectedKeywords().length>0)
    {
      addCommand(cAddData);
      addCommand(cTransfer);
    }
  }

  public void commandAction(Command c, Displayable d)
  {
    if ((c==List.SELECT_COMMAND|c==cView) && getSelectedData()!=-1)
    {
      if (viewData == null)
      {
        viewData = new View(this);
        viewData.addCommand(cNext);
        viewData.addCommand(cGetKeys);
        viewData.addCommand(cDelData);
        viewData.addCommand(cBack);
        viewData.setCommandListener(this);
      }
      viewData.setData(getSelectedData());
      Display.getDisplay(ass).setCurrent(viewData);
    }
    if (c==cBack)
      Display.getDisplay(ass).setCurrent(this);
    if (c==cKeyword)
    {
      ass.keyList.update();
      Display.getDisplay(ass).setCurrent(ass.keyList);
    }
    if (c==cNext && getSelectedIndex()<(size()-1))
    {
      setSelectedIndex(getSelectedIndex()+1,true);
      viewData.setData(getSelectedData());
    }
    if (c==cGetKeys)
    {
      ass.keyList.setSelectedKeywords(datas[getSelectedData()]);
      update();
      ass.keyList.update();
      Display.getDisplay(ass).setCurrent(ass.keyList);
    }
    if (c==cBalance)
    {
      if (fBalance==null)
      {
        fBalance = new Balance(this);
        fBalance.addCommand(cBack);
        fBalance.setCommandListener(this);
      }
      fBalance.setBalance();
      Display.getDisplay(ass).setCurrent(fBalance);
    }

    if (c==cAddData)
      if (d==tbNewData)
      {
        boolean[] ba = new boolean[2];
        tbNewData.cashout.getSelectedFlags(ba);
        long date = tbNewData.date.getDate().getTime();
        int amount = Integer.valueOf(tbNewData.amount.getString()).intValue();
        addData(date,amount,ba[0],ba[1],tbNewData.comment.getString(),ass.keyList.getSelectedKeywords());
        update();
        ass.save();
        Display.getDisplay(ass).setCurrent(this);
      }
      else
      {
        if (tbNewData == null)
        {
          tbNewData = new Mutation();
          tbNewData.addCommand(cAddData);
          tbNewData.addCommand(cBack);
          tbNewData.setCommandListener(this);
        }
        tbNewData.setString(ass.keyList.getSelectedString());
        Display.getDisplay(ass).setCurrent(tbNewData);
      }

    if (c==cTransfer)
      if (d==transfer)
      {
        boolean withdraw = (transfer.withdraw.getSelectedIndex()==0);
        long date = transfer.date.getDate().getTime();
        int amount = Integer.valueOf(transfer.amount.getString()).intValue();
        addData(date,amount,!withdraw,true,transfer.comment.getString(),ass.keyList.getSelectedKeywords());
        addData(date,amount,withdraw,false,transfer.comment.getString(),ass.keyList.getSelectedKeywords());
        update();
        ass.save();
        Display.getDisplay(ass).setCurrent(this);
      }
      else
      {
        if (transfer == null)
        {
          transfer = new Transfer();
          transfer.addCommand(cTransfer);
          transfer.addCommand(cBack);
          transfer.setCommandListener(this);
        }
        transfer.setString(ass.keyList.getSelectedString());
        Display.getDisplay(ass).setCurrent(transfer);
      }

    if (c==cDelData && getSelectedData()!=-1)
    {
      if (d==fDelData)
      {
        delData(getSelectedData());
        update();
        ass.save();
        Display.getDisplay(ass).setCurrent(this);
      }
      else
      {
        if (fDelData == null)
        {
          fDelData = new Form("Delete Mutation");
          fDelData.addCommand(cDelData);
          fDelData.addCommand(cBack);
          fDelData.setCommandListener(this);
        }
        while (fDelData.size()>0)
          fDelData.delete(0);
        fDelData.append(new StringItem("Keywords",getSelectedDataKeywordString()));
        fDelData.append(new StringItem("Comment",strings[getSelectedData()]));
        Display.getDisplay(ass).setCurrent(fDelData);
      }
    }//cDelData

  }


}