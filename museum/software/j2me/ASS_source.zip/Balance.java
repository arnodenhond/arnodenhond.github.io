package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class Balance extends Form
{

  StringItem cashbal = new StringItem("Cash balance","");
  StringItem bankbal = new StringItem("Bank balance","");
  StringItem totalbal = new StringItem("Total balance","");
  StringItem totalin = new StringItem("Total incoming","");
  StringItem totalout = new StringItem("Total outgoing","");
  DataList dataList;

  Balance(DataList dataList)
  {
    super("Balance");
    this.dataList = dataList;
    append(cashbal);
    append(bankbal);
    append(totalbal);
    append(totalin);
    append(totalout);
  }

  void setBalance()
  {
    int CashOut=0;
    int CashIn=0;
    int BankOut=0;
    int BankIn=0;
    for (int i = 0; i < dataList.amounts.length; i++)
      if (dataList.scores[i]>0)
      {
        if (!dataList.cashbanks[i] && dataList.inouts[i])
          BankOut+=dataList.amounts[i];
        if (!dataList.cashbanks[i] && !dataList.inouts[i])
          BankIn+=dataList.amounts[i];
        if (dataList.cashbanks[i] && dataList.inouts[i])
          CashOut+=dataList.amounts[i];
        if (dataList.cashbanks[i] && !dataList.inouts[i])
          CashIn+=dataList.amounts[i];
      }

    cashbal.setText(dataList.makeAmountString(CashIn-CashOut));
    bankbal.setText(dataList.makeAmountString(BankIn-BankOut));
    totalbal.setText(dataList.makeAmountString( (CashIn-CashOut) + (BankIn-BankOut) ));
    totalin.setText(dataList.makeAmountString(CashIn+BankIn));
    totalout.setText(dataList.makeAmountString(CashOut+BankOut));
  }

}
