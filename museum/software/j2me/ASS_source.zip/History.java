package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class History extends Canvas
{

  DataList dataList;
  int[] stats = new int[0];

  History(DataList dataList)
  {
    this.dataList = dataList;
  }

  void set(int[] stats)
  {
    this.stats = stats;
  }

  protected void paint(Graphics g)
  {
    if (stats.length==0)
      return;
    int highest = stats[0];
    for (int i = 0; i < stats.length; i++)
      if (highest<stats[i])
        highest = stats[i];
    int lowest = stats[0];
    for (int i = 0; i < stats.length; i++)
      if (lowest>stats[i])
        lowest = stats[i];
    int space = getWidth() / (stats.length-1);
    g.setStrokeStyle(g.SOLID);
    g.setColor(255, 255, 255);
    g.fillRect(0, 0, getWidth(), getHeight());
    int[] newstats=calcstats(stats);
    int last = newstats[0];
    g.setColor(0, 0, 0);
    for (int i = 1; i < newstats.length; i++)
    {
      g.drawLine(space*(i-1),last,space*i,newstats[i]);
      last=newstats[i];
    }
    g.drawString(dataList.makeAmountString(lowest),getWidth(),0,g.TOP|g.RIGHT);
    g.drawString(dataList.makeAmountString(highest),getWidth(),getHeight(),g.BOTTOM|g.RIGHT);
    int hh = (int) getHeight() / 2;
    g.setStrokeStyle(g.DOTTED);
    g.drawLine(0,hh,getWidth(),hh);
  }

  int[] calcstats(int[] stats)
  {
    int[] result = new int[stats.length];
    int highest = stats[0];
    for (int i = 0; i < stats.length; i++)
      if (highest<stats[i])
        highest = stats[i];
    int lowest = stats[0];
    for (int i = 0; i < stats.length; i++)
      if (lowest>stats[i])
        lowest = stats[i];
    int diff = highest-lowest;
    if (diff==0)
      diff=1;
    long f = ((getHeight()*1000000)/diff);
    for (int i = 0; i < stats.length; i++)
    {
      result[i] = (int) ((stats[i]-lowest)*f)/1000000;
    }
    return result;
  }

  int[] getAmountsByDate(long period, int repeats)
  {
    int[] result = new int[repeats];
    for (int i = 0; i < result.length; i++)
      result[i]=0;
    for (int i = 0; i < dataList.datas.length; i++)
      if (dataList.scores[i]>0)
        for (long j = 0; j < repeats; j++)
        {
          long begin = System.currentTimeMillis() - (j*period);
          long end = begin - period;
          if (dataList.dates[i]<begin && dataList.dates[i]>end)
          {
            if (dataList.inouts[i])
              result[(int)j]-=dataList.amounts[i];
            else
              result[(int)j]+=dataList.amounts[i];
            break;
          }
        }
    return result;
  }

}
