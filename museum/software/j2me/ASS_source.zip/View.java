package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class View extends Form
{

  StringItem keywords = new StringItem("keywords","");
  StringItem amount = new StringItem("amount","0.00");
  StringItem cashbank = new StringItem("account","");
  StringItem inout = new StringItem("direction","");
  StringItem date = new StringItem("date","");
  StringItem comment = new StringItem("comment","");
  DataList dataList;

  View(DataList dataList)
  {
    super("View Mutation");
    this.dataList = dataList;
    append(keywords);
    append(amount);
    append(cashbank);
    append(inout);
    append(date);
    append(comment);
  }

  void setData(int data)
  {
    keywords.setText(dataList.getSelectedDataKeywordString());
    amount.setText(dataList.makeAmountString(dataList.amounts[dataList.getSelectedData()]));
    if (dataList.cashbanks[dataList.getSelectedData()])
      cashbank.setText("cash");
    else
      cashbank.setText("bank");
    if (dataList.inouts[dataList.getSelectedData()])
      inout.setText("outgoing");
    else
      inout.setText("incoming");
    date.setText(dataList.makeLongDateString(dataList.dates[dataList.getSelectedData()]));
    comment.setText(dataList.strings[dataList.getSelectedData()]);
  }

}
