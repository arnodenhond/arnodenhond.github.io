package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class Mutation extends Form
{

  DateField date = new DateField("",DateField.DATE_TIME);
  TextField amount = new TextField("Amount","0",10,TextField.NUMERIC);
  ChoiceGroup cashout = new ChoiceGroup("",Choice.MULTIPLE);
  TextField comment = new TextField("Comment","",100,TextField.ANY);
  StringItem keywords = new StringItem("Keywords"," ");

  Mutation()
  {
    super("New Mutation");
    cashout.append("cash",null);
    cashout.append("outgoing",null);
    setString("");
    append(keywords);
    append(amount);
    append(cashout);
    append(date);
    append(comment);
  }

  void setString(String s)
  {
    date.setDate(new Date(System.currentTimeMillis()));
    amount.setString("0");
    comment.setString("");
    cashout.setSelectedIndex(0,true);
    cashout.setSelectedIndex(1,true);
    keywords.setText(s);
  }

}

