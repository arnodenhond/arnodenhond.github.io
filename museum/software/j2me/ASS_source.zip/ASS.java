package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class ASS extends MIDlet
{

  KeyList keyList;
  DataList dataList;

  public ASS()
  {
    keyList = new KeyList(this);
    dataList = new DataList(this);

    load();

    dataList.update();
    keyList.update();
  }

  public void startApp()
  {
    Display.getDisplay(this).setCurrent(keyList);
  }

  public void pauseApp()
  {
  }

  public void destroyApp(boolean b)
  {
  }

  int[] getTop(int[] data,int length)
  {
    if (length>data.length)
      length=data.length;
    int[] result = new int[length];
    for (int i = 0; i < result.length; i++)
      result[i]=Integer.MAX_VALUE;

    for (int i = 0; i < data.length; i++)
      for (int j = 0; j < result.length; j++)
        if (result[j] == Integer.MAX_VALUE)
        {
          result[j] = i;
          break;
        }
        else
          if (data[result[j]] <= data[i])
          {
            for (int k = length-1; k > j; k--)
              result[k] = result[k-1];
            result[j] = i;
            break;
          }
    return result;
  }//getTop

  void read(byte[] data) throws Exception
  {
        ByteArrayInputStream bais = new ByteArrayInputStream(data);
        DataInputStream dis = new DataInputStream(bais);
//read dStrings
        dataList.strings = new String[dis.readInt()];
        for (int i = 0; i < dataList.strings.length; i++)
          dataList.strings[i] = dis.readUTF();
//read dates
        dataList.dates = new long[dis.readInt()];
        for (int i = 0; i < dataList.dates.length; i++)
          dataList.dates[i] = dis.readLong();
//read amounts
        dataList.amounts = new int[dis.readInt()];
        for (int i = 0; i < dataList.amounts.length; i++)
          dataList.amounts[i] = dis.readInt();
//read cashbanks
        dataList.cashbanks = new boolean[dis.readInt()];
        for (int i = 0; i < dataList.cashbanks.length; i++)
          dataList.cashbanks[i] = dis.readBoolean();
//read inouts
        dataList.inouts = new boolean[dis.readInt()];
        for (int i = 0; i < dataList.inouts.length; i++)
          dataList.inouts[i] = dis.readBoolean();
//read kStrings
        keyList.strings = new String[dis.readInt()];
        for (int i = 0; i < keyList.strings.length; i++)
          keyList.strings[i] = dis.readUTF();
//read keywords
        keyList.keywords = new int[dis.readInt()][];
        for (int i = 0; i < keyList.keywords.length; i++)
        {
          keyList.keywords[i] = new int[dis.readInt()];
          for (int j = 0; j < keyList.keywords[i].length; j++)
            keyList.keywords[i][j] = dis.readInt();
        }
//read datas
        dataList.datas = new int[dis.readInt()][];
        for (int i = 0; i < dataList.datas.length; i++)
        {
          dataList.datas[i] = new int[dis.readInt()];
          for (int j = 0; j < dataList.datas[i].length; j++)
            dataList.datas[i][j] = dis.readInt();
        }
  }
  byte[] write() throws Exception
  {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      DataOutputStream dos = new DataOutputStream(baos);
//write dStrings
      dos.writeInt(dataList.strings.length);
      for (int i = 0; i < dataList.strings.length; i++)
        dos.writeUTF(dataList.strings[i]);
//write dates
      dos.writeInt(dataList.dates.length);
      for (int i = 0; i < dataList.dates.length; i++)
        dos.writeLong(dataList.dates[i]);
//write amounts
      dos.writeInt(dataList.amounts.length);
      for (int i = 0; i < dataList.amounts.length; i++)
        dos.writeInt(dataList.amounts[i]);
//write cashbanks
      dos.writeInt(dataList.cashbanks.length);
      for (int i = 0; i < dataList.cashbanks.length; i++)
        dos.writeBoolean(dataList.cashbanks[i]);
//write inouts
      dos.writeInt(dataList.inouts.length);
      for (int i = 0; i < dataList.inouts.length; i++)
        dos.writeBoolean(dataList.inouts[i]);

//write kStrings
      dos.writeInt(keyList.strings.length);
      for (int i = 0; i < keyList.strings.length; i++)
        dos.writeUTF(keyList.strings[i]);
//write keywords
      dos.writeInt(keyList.keywords.length);
      for (int i = 0; i < keyList.keywords.length; i++)
      {
        dos.writeInt(keyList.keywords[i].length);
        for (int j = 0; j < keyList.keywords[i].length; j++)
          dos.writeInt(keyList.keywords[i][j]);
      }
//write datas
      dos.writeInt(dataList.datas.length);
      for (int i = 0; i < dataList.datas.length; i++)
      {
        dos.writeInt(dataList.datas[i].length);
        for (int j = 0; j < dataList.datas[i].length; j++)
          dos.writeInt(dataList.datas[i][j]);
      }
    return baos.toByteArray();
  }

  void load()
  {
      try
      {
//      RecordStore.deleteRecordStore("ASS");
        RecordStore rs = RecordStore.openRecordStore("ASS",true);
        if (rs.getNumRecords()==0)
          save();
        byte[] data = rs.getRecord(1);
        rs.closeRecordStore();
        read(data);
      }
      catch (Exception e)
      {
      }
  }

  void save()
  {
    try
    {
      RecordStore rs = RecordStore.openRecordStore("ASS",true);
    	byte[] data = write();
      if (rs.getNumRecords()==0)
        rs.addRecord(data,0,data.length);
      else
        rs.setRecord(1,data,0,data.length);
      rs.closeRecordStore();
    }
    catch (Exception e)
    {
    }
  }

}//ASS

