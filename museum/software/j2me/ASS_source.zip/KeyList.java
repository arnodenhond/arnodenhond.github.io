package ASS;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

public class KeyList extends List implements CommandListener
{

  ASS ass;
  String[] strings = new String[0];
  int[][] keywords = new int[0][0];
  int[] indices = new int[0];
  int[] scores = new int[0];

  TextBox tbNewKeyword = null;
  Form fDelKeyword = null;
  History history = null;

  Command cBack = new Command("Cancel",Command.BACK,0);
  Command cData = new Command("Mutations",Command.BACK,0);
  Command cHistory = new Command("History",Command.SCREEN,0);
  Command cSelectAll = new Command("Select All Keywords",Command.SCREEN,1);
  Command cSelectNone = new Command("DE-Select All Keywords",Command.SCREEN,1);
  Command cAddKeyword = new Command("Add Keyword",Command.SCREEN,2);
  Command cDelKeyword = new Command("Del Keyword",Command.SCREEN,3);
  Command cWeek = new Command("Week",Command.SCREEN,0);
  Command cMonth = new Command("Month",Command.SCREEN,1);
  Command cYear = new Command("Year",Command.SCREEN,2);

  public KeyList(ASS ass)
  {
    super("Keywords",List.MULTIPLE);
    this.ass = ass;

    addCommand(cSelectAll);
    addCommand(cHistory);
    addCommand(cAddKeyword);
    addCommand(cData);
    setCommandListener(this);

  }

  void addKeyword(String s)
  {
//add string
    String[] newStrings = new String[strings.length+1];
    System.arraycopy(strings,0,newStrings,0,strings.length);
    newStrings[strings.length] = s;
    strings = newStrings;
//add empty datalist to keywordlist
    int[][] newKeywords = new int[keywords.length+1][];
    System.arraycopy(keywords,0,newKeywords,0,keywords.length);
    newKeywords[keywords.length]=new int[0];
    keywords = newKeywords;
//add new keyword to searchkeywords
    append(strings[strings.length-1],null);
    setSelectedIndex(size()-1,true);
    int[] newIndices = new int[indices.length+1];
    System.arraycopy(indices,0,newIndices,0,indices.length);
    newIndices[size()-1]=keywords.length-1;
    indices = newIndices;
  }

  void delKeyword(int keyword)
  {
//delete string
        String[] newStrings = new String[strings.length-1];
        System.arraycopy(strings,0,newStrings,0,keyword);
        System.arraycopy(strings,keyword+1,newStrings,keyword,strings.length-(keyword+1));
        strings = newStrings;
//update keywords in datalist
        for (int i = 0; i < ass.dataList.datas.length; i++)
        {
          for (int j = 0; j < ass.dataList.datas[i].length; j++)
            if (ass.dataList.datas[i][j]==keyword)
            {
              int[] newkeywords = new int[ass.dataList.datas[i].length-1];
              System.arraycopy(ass.dataList.datas[i],0,newkeywords,0,j);
              System.arraycopy(ass.dataList.datas[i],j+1,newkeywords,j,ass.dataList.datas[i].length-(j+1));
              ass.dataList.datas[i] = newkeywords;
              j--;
            }
            else
              if (ass.dataList.datas[i][j]>keyword)
                ass.dataList.datas[i][j]--;
          if (ass.dataList.datas[i].length==0)
          {
            ass.dataList.delData(i);
            i--;
          }
        }
//delete from keywordlist
        int[][] newKeywords = new int[keywords.length-1][];
        System.arraycopy(keywords,0,newKeywords,0,keyword);
        System.arraycopy(keywords,keyword+1,newKeywords,keyword,keywords.length-(keyword+1));
        keywords = newKeywords;
//delete keyword from searchkeywords
        delete(0);
        int[] newIndices = new int[indices.length-1];
        System.arraycopy(indices,1,newIndices,0,indices.length-1);
        indices = newIndices;
  }

  void selectAll()
  {
    while(size()>0)
      delete(size()-1);
    indices = new int[keywords.length];
    boolean[] ba = new boolean[keywords.length];
    for (int i = 0; i < keywords.length; i++)
    {
      append(strings[i],null);
      ba[i] = true;
      indices[i]=i;
    }
    setSelectedFlags(ba);
  }

  void selectNone()
  {
    boolean[] ba = new boolean[size()];
    for (int i = 0; i < ba.length; i++)
      ba[i]=false;
    setSelectedFlags(ba);
  }

  void setSelectedKeywords(int[] keys)
  {
    while (size()>0)
      delete(size()-1);
    int[] newIndices = new int[keys.length];
    for (int i = 0; i < keys.length; i++)
    {
      append(strings[keys[i]],null);
      setSelectedIndex(size()-1,true);
      newIndices[i]=keys[i];
    }
    indices = newIndices;
  }

  String getSelectedString()
  {
      String result = new String();
      int[] sk = getSelectedKeywords();
      for (int i = 0; i < sk.length; i++)
        result+=strings[sk[i]]+" ";
      return result;
  }

  int[] getSelectedKeywords() //unoptimized!
  {
    int selkeys = 0;
    for (int i = 0; i < size(); i++)
      if (isSelected(i))
        selkeys++;
    int[] result = new int[selkeys];
    int j = 0;
    for (int i = 0; i < size(); i++)
      if (isSelected(i))
      {
        result[j]=indices[i];
        j++;
      }
    return result;
  }

  void update()
  {
    int[] selected = getSelectedKeywords();

    int[] scores = new int[keywords.length];
    if (selected.length==0)
      for (int i = 0; i < keywords.length; i++)
        scores[i]=keywords[i].length;
    else
      for (int i = 0; i < ass.dataList.datas.length; i++)
        for (int j = 0; j < ass.dataList.datas[i].length; j++)
          scores[ass.dataList.datas[i][j]]+=ass.dataList.scores[i];
    for (int i = 0; i < selected.length; i++)
      scores[selected[i]] = 1000000+keywords[selected[i]].length;
    indices = ass.getTop(scores,selected.length+15);

    while(size()>0)
      delete(size()-1);
    for (int i = 0; i < indices.length; i++)
    {
      append(strings[indices[i]],null);
      for (int j = 0; j < selected.length; j++)
        if (selected[j]==indices[i])
        {
          setSelectedIndex(size()-1,true);
          break;
        }
    }
    removeCommand(cDelKeyword);
    if (getSelectedKeywords().length==1 && getSelectedKeywords()[0]==indices[0])
      addCommand(cDelKeyword);

  }

  public void commandAction(Command c, Displayable d)
  {
    if (c==cBack)
      Display.getDisplay(ass).setCurrent(this);
    if (c==cData)
    {
      ass.dataList.update();
      Display.getDisplay(ass).setCurrent(ass.dataList);
    }

    if (c==cHistory)
    {
      if (history ==null)
      {
        history = new History(ass.dataList);
        history.addCommand(cWeek);
        history.addCommand(cMonth);
        history.addCommand(cYear);
        history.addCommand(cBack);
        history.setCommandListener(this);
      }
      ass.dataList.update();
      long l = 86400 * 1000;
      history.set(history.getAmountsByDate(l,7));
      Display.getDisplay(ass).setCurrent(history);
      history.repaint();
    }
    if (c==cWeek)
    {
      long l = 86400 * 1000;
      history.set(history.getAmountsByDate(l,7));
      history.repaint();
    }
    if (c==cMonth)
    {
      long l = 60480 * 10000;
      history.set(history.getAmountsByDate(l,5));
      history.repaint();
    }
    if (c==cYear)
    {
      long l = 2592 * 1000 ;
      history.set(history.getAmountsByDate(l* 1000,12));
      history.repaint();
    }

    if (c==cSelectAll)
    {
      selectAll();
      removeCommand(cSelectAll);
      addCommand(cSelectNone);
    }
    if (c==cSelectNone)
    {
      selectNone();
      removeCommand(cSelectNone);
      addCommand(cSelectAll);
    }

    if (c==cAddKeyword)
      if (d==tbNewKeyword && !tbNewKeyword.getString().trim().equals(""))
      {
        addKeyword(tbNewKeyword.getString());
        ass.dataList.update();
        update();
        ass.save();
        Display.getDisplay(ass).setCurrent(this);
        tbNewKeyword.setString("");
      }
      else
      {
        if (tbNewKeyword == null)
        {
          tbNewKeyword = new TextBox("New Keyword","",15,TextField.ANY);
          tbNewKeyword.addCommand(cAddKeyword);
          tbNewKeyword.addCommand(cBack);
          tbNewKeyword.setCommandListener(this);
        }
        Display.getDisplay(ass).setCurrent(tbNewKeyword);
      }

    if (c==cDelKeyword && (getSelectedKeywords().length==1 && getSelectedKeywords()[0]==indices[0]))
    {
      if (d==fDelKeyword)
      {
        delKeyword(getSelectedKeywords()[0]);
        ass.dataList.update();
        update();
        ass.save();
        Display.getDisplay(ass).setCurrent(this);
      }
      else
      {
        if (fDelKeyword == null)
        {
          fDelKeyword = new Form("Delete Keyword");
          fDelKeyword.addCommand(cDelKeyword);
          fDelKeyword.addCommand(cBack);
          fDelKeyword.setCommandListener(this);
        }
        while (fDelKeyword.size()>0)
          fDelKeyword.delete(0);
        fDelKeyword.append(new StringItem("Delete this keyword?",strings[getSelectedKeywords()[0]]));
        Display.getDisplay(ass).setCurrent(fDelKeyword);
      }
    }//cDelKeyword

  }

}