package KnikkerSpel;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class KnikkerSpel extends MIDlet {
    
    public void startApp() {
        Display display = Display.getDisplay(this);
        display.setCurrent(new KnikkerCanvas(this));
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
}
