package KnikkerSpel;

import javax.microedition.lcdui.*;

public class KnikkerCanvas extends Canvas implements CommandListener {
    
    KnikkerBord bord;
    int size;
    private int selectedMovable;
    private boolean[] ablemoves;
    private int selx;
    private int sely;
    private int movables;
    private int selectedDirection;
    private boolean moveMode;
    private KnikkerSpel ks;
    
    public KnikkerCanvas(KnikkerSpel ks) {
        this.ks = ks;
        selx=-1;
        sely=-1;
        selectedMovable=0;
        movables=0;
        selectedDirection=-1;
        moveMode=true;
        size=(int)Math.min(getWidth(),getHeight())/22;
        bord = new KnikkerBord(size);
        try {
            // Set up this canvas to listen to command events
            setCommandListener(this);
            // Add the Exit command
            addCommand(new Command("Exit", Command.EXIT, 1));
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public void paint(Graphics g) {
        int curMovable=0;
        g.setColor(255,255,255);
        g.fillRect(0,0, getWidth(), getHeight());
        for (int x = 0; x < bord.getWidth(); x++) {
            for (int y = 0; y < bord.getHeight(); y++) {
                if (bord.inBord(x,y)) {
                    if (bord.getKnikker(x,y)!=null) {
                        g.drawImage(bord.getKnikker(x,y), (size*3)+(x*(size*3)), (size*3)+(y*(size*3)), Graphics.VCENTER|Graphics.HCENTER);
                        if (bord.hasAnyMove(bord.getMoves(x,y))) {
                            g.setColor(0);
                            if (curMovable==selectedMovable) {
                                g.setStrokeStyle(Graphics.SOLID);
                                ablemoves = bord.getMoves(x,y);
                                selx=x;
                                sely=y;
                            } else
                                g.setStrokeStyle(Graphics.DOTTED);
                            g.drawRect((size*2)+(x*(size*3)), (size*2)+(y*(size*3)),(size*2), (size*2) );
                            boolean[] moves = bord.getMoves(x,y);
                            g.setColor(255,0,0);
                            
                            setStyle(g,curMovable,bord.DOWN);
                            if (moves[bord.DOWN])
                                g.drawLine((size*2)+(x*(size*3)), (size*2)+(y*(size*3))+(size*2)+1, (size*2)+(x*(size*3))+(size*2), (size*2)+(y*(size*3))+(size*2)+1);
                            setStyle(g,curMovable,bord.LEFT);
                            if (moves[bord.LEFT])
                                g.drawLine((size*2)+(x*(size*3))-1, (size*2)+(y*(size*3)), (size*2)+(x*(size*3))-1, (size*2)+(y*(size*3))+(size*2));
                            setStyle(g,curMovable,bord.RIGHT);
                            if (moves[bord.RIGHT])
                                g.drawLine((size*2)+(x*(size*3))+(size*2)+1, (size*2)+(y*(size*3)), (size*2)+(x*(size*3))+(size*2)+1, (size*2)+(y*(size*3))+(size*2));
                            setStyle(g,curMovable,bord.UP);
                            if (moves[bord.UP])
                                g.drawLine((size*2)+(x*(size*3)), (size*2)+(y*(size*3))-1, (size*2)+(x*(size*3))+(size*2), (size*2)+(y*(size*3))-1);
                            curMovable++;
                        }
                    } else {
                        g.setStrokeStyle(Graphics.SOLID);
                        g.drawImage(bord.maakBakje(),(size*3)+(x*(size*3)), (size*3)+(y*(size*3)), Graphics.VCENTER|Graphics.HCENTER);
                    }
                }
            }
        }
        movables = curMovable;
    }
    
    private void setStyle(Graphics g,int curMovable, int curDirection) {
        if (curMovable==selectedMovable && curDirection==selectedDirection)
            g.setStrokeStyle(Graphics.SOLID);
        else
            g.setStrokeStyle(Graphics.DOTTED);
    }
    
    
    private int firstDirection(boolean[] moves) {
        for (int i = 0; i < moves.length; i++)
            if (moves[i])
                return i;
        return -1;
    }
    
    /**
     * Called when a key is pressed.
     */
    protected  void keyPressed(int keyCode) {
        int gameAction = getGameAction(keyCode);
        if (moveMode) {
            switch (gameAction) {
                case DOWN:
                case RIGHT:
                    if (selectedMovable<movables-1)
                        selectedMovable++;
                    break;
                case UP:
                case LEFT:
                    if (selectedMovable>0)
                        selectedMovable--;
                    break;
                case FIRE:
                    moveMode=false;
                    selectedDirection=firstDirection(ablemoves);
                    break;
            }
        } else {
            switch (gameAction) {
                case DOWN:
                    if (ablemoves[bord.DOWN])
                        selectedDirection=bord.DOWN;
                    break;
                case UP:
                    if (ablemoves[bord.UP])
                        selectedDirection=bord.UP;
                    break;
                case LEFT:
                    if (ablemoves[bord.LEFT])
                        selectedDirection=bord.LEFT;
                    break;
                case RIGHT:
                    if (ablemoves[bord.RIGHT])
                        selectedDirection=bord.RIGHT;
                    break;
                case FIRE:
                    switch (selectedDirection) {
                        case 0: bord.hit(selx,sely,bord.UP); break;
                        case 1: bord.hit(selx,sely,bord.DOWN); break;
                        case 2: bord.hit(selx,sely,bord.LEFT); break;
                        case 3: bord.hit(selx,sely,bord.RIGHT); break;
                    }
                    moveMode=true;
                    selectedMovable=0;
                    selectedDirection=-1;
                    selx=-1;
                    sely=-1;
                    break;
            }
        }
        repaint();
    }
    
    /**
     * Called when a key is released.
     */
    protected  void keyReleased(int keyCode) {
    }
    
    /**
     * Called when a key is repeated (held down).
     */
    protected  void keyRepeated(int keyCode) {
    }
    
    /**
     * Called when the pointer is dragged.
     */
    protected  void pointerDragged(int x, int y) {
    }
    
    /**
     * Called when the pointer is pressed.
     */
    protected  void pointerPressed(int x, int y) {
    }
    
    /**
     * Called when the pointer is released.
     */
    protected  void pointerReleased(int x, int y) {
    }
    
    /**
     * Called when action should be handled
     */
    public void commandAction(Command command, Displayable displayable) {
        if (command.getCommandType()==Command.EXIT) {
            javax.microedition.lcdui.Display.getDisplay(ks).setCurrent(null);
            ks.destroyApp(true);
            ks.notifyDestroyed();
        }
    }
    
}
