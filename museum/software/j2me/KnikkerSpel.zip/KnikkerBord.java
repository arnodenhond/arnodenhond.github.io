package KnikkerSpel;

import java.util.Random;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

public class KnikkerBord {
    
    public int UP = 0;
    public int DOWN = 1;
    public int LEFT = 2;
    public int RIGHT = 3;
    
    private Image[][] bord;
    private boolean[][] tempbord;
    private int size;
    
    public boolean inBord(int px,int py) {
        if (tempbord==null) {
            tempbord = new boolean[7][];
            for (int i = 0; i < 7; i++) {
                tempbord[i] = new boolean[7];
            }
            
            for (int x = 2; x < 5; x++) {
                for (int y = 0; y < 7; y++) {
                    tempbord[x][y]=true;
                }
            }
            
            for (int y = 2; y < 5; y++) {
                for (int x = 0; x < 7; x++) {
                    tempbord[x][y]=true;
                }
            }
        }
        return tempbord[px][py];
    }
    
    public KnikkerBord(int size) {
        this.size = size;
        Random random = new Random();
        
        bord = new Image[7][];
        for (int i = 0; i < 7; i++) {
            bord[i] = new Image[7];
        }
        
        for (int x = 2; x < 5; x++) {
            for (int y = 0; y < 7; y++) {
                bord[x][y]=maakKnikker(random);
            }
        }
        
        for (int y = 2; y < 5; y++) {
            for (int x = 0; x < 7; x++) {
                bord[x][y]=maakKnikker(random);
            }
        }
        
        bord[3][3]=null;
    }
    
    void hit(int x, int y, int direction) {
        switch (direction) {
            case 0: bord[x][y-2]=bord[x][y]; bord[x][y-1]=null; bord[x][y]=null; break;
            case 1: bord[x][y+2]=bord[x][y]; bord[x][y+1]=null; bord[x][y]=null; break;
            case 2: bord[x-2][y]=bord[x][y]; bord[x-1][y]=null; bord[x][y]=null; break;
            case 3: bord[x+2][y]=bord[x][y]; bord[x+1][y]=null; bord[x][y]=null; break;
        }
    }
    
    Image getKnikker(int x, int y) {
        if (bord[x][y]!=null)
            if (bord[x][y]==null)
                return maakBakje();
            else
                return bord[x][y];
        return null;
    }
    
    boolean hasAnyMove(boolean[] moves) {
        if (moves==null)
            return false;
        for (int i = 0; i < 4; i++)
            if (moves[i])
                return true;
        return false;
    }
    
    //returns a array of booleans showing which directions the knikker at param x,y can move to.
    //returns null if there is no knikker at param x,y
    boolean[] getMoves(int x, int y) {
        boolean[] result = new boolean[4];
        if (bord[x][y]==null && inBord(x,y))
            return null;
        if (x>1)
            if (inBord(x-2,y))
                if (bord[x-1][y]!=null&&bord[x-2][y]==null)
                    result[LEFT]=true;
        if (x<5)
            if (inBord(x+2,y))
                if (bord[x+1][y]!=null && bord[x+2][y]==null)
                    result[RIGHT]=true;
        if (y>1)
            if (inBord(x,y-2))
                if (bord[x][y-1]!=null && bord[x][y-2]==null)
                    result[UP]=true;
        if (y<5)
            if (inBord(x,y+2))
                if (bord[x][y+1]!=null && bord[x][y+2]==null)
                    result[DOWN]=true;
        return result;
    }
    
    public int getHeight() {
        if (bord[0]!=null)
            return bord[0].length;
        else
            return 0;
    }
    
    public int getWidth() {
        if (bord!=null)
            return bord.length;
        else
            return 0;
    }
    
    public Image maakKnikker(Random random) {
        Image image = Image.createImage(size*2,size*2);
        Graphics graphics = image.getGraphics();
        graphics.setColor(random.nextInt());
        graphics.fillArc(0,0,size*2,size*2,0,360);
        return image;
    }
    
    public Image maakBakje() {
        Image image = Image.createImage(size*2,size*2);
        Graphics graphics = image.getGraphics();
        graphics.setColor(0,0,0);
        graphics.setStrokeStyle(Graphics.SOLID);
        graphics.drawArc(0,0,(size*2)-1,(size*2)-1,0,360);
        return image;
    }
}
