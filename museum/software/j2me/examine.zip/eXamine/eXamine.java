    /* v_type
     * 0 = textfield
     * 1 = multiple     X
     * 2 = exclusive
     * 3 = getal        X
     * 4 = datum        X
     * 5 = email
     * 6 = gauge        X           (min=default max=length)
     *                  X = min/max
     */

package eXamine;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.*;
import java.io.*;

/** eXamine client
 * ToDo: download vragenlijst, upload antwoorden -- initialize() eruit
 * @author Arno den Hond
 * @version 0.9
 */
public class eXamine extends MIDlet implements CommandListener {
    
    Command c_volgende;
    Command c_vorige;
    Command c_upload;
    
    int current;
    
    String[] s_id;
    String[] s_titel;
    String[] s_text;
    
    String[][] v_id;
    String[][] v_titel;
    byte[][]   v_type;
    long[][]   v_min;
    long[][]   v_max;
    String[][] v_antwoord;
    
    String[][][] a_id;
    String[][][] a_titel;
    
    
    public eXamine() {
        current=0;
        c_volgende = new Command("Verder",Command.BACK,0);
        c_vorige = new Command("Terug",Command.SCREEN,0);
        c_upload = new Command("Upload",Command.BACK,0);
    }
    
    
    public void startApp() {
        initialize();
        Display.getDisplay(this).setCurrent(makeForm());
    }
    
    /** make new form
     * @return new form
     */
    Form makeForm() {
        Form result = new Form(s_titel[current]);
        result.append(s_text[current]);
        result.append(new Gauge("voortgang",false,s_id.length,current+1));
        for (int i = 0; i < v_id[current].length; i++) {
            switch (v_type[current][i]) {
                case 0: {
                    TextField tf = new TextField(v_titel[current][i],"",100,TextField.ANY);
                    if (v_antwoord[current][i]!=null)
                        tf.setString(v_antwoord[current][i]);
                    result.append(tf);
                }
                break;
                case 1: {
                    ChoiceGroup cg = new ChoiceGroup(v_titel[current][i],Choice.MULTIPLE);
                    for (int j = 0; j < a_id[current][i].length; j++)
                        cg.append(a_titel[current][i][j],null);
                    if (v_antwoord[current][i]!=null) {
                        // COMMA-SEPERATED STRING --> VLAGGETJES ZETTEN!!
                        int index = 0;
                        while (v_antwoord[current][i].indexOf(",",index)!=-1) {
                            String flag = v_antwoord[current][i].substring(index,v_antwoord[current][i].indexOf(",",index+1));
                            //eindigt altijd op , (tenzij leeg) dus geen probleem
                            for (int j = 0; j < a_id[current][i].length; j++) {
                                if (flag.equals(a_id[current][i][j])) {
                                    cg.setSelectedIndex(j,true);
                                    break;
                                }
                            }
                            index=v_antwoord[current][i].indexOf(",",index)+1;
                        }
                    }
                    result.append(cg);
                }
                break;
                case 2: {
                    ChoiceGroup cg = new ChoiceGroup(v_titel[current][i],Choice.EXCLUSIVE);
                    for (int j = 0; j < a_id[current][i].length; j++) {
                        cg.append(a_titel[current][i][j],null);
                    }
                    if (v_antwoord[current][i]!=null) {
                        for (int j = 0; j < a_id[current][i].length; j++)
                            if (v_antwoord[current][i].equals(a_id[current][i][j])) {
                                cg.setSelectedIndex(j,true);
                                break;
                            }
                    }
                    result.append(cg);
                }
                break;
                case 3: {
                    TextField tf = new TextField(v_titel[current][i],"0",100,TextField.NUMERIC);
                    if (v_antwoord[current][i]!=null)
                        tf.setString(v_antwoord[current][i]);
                    result.append(tf);
                }
                break;
                case 4: {
                    DateField df = new DateField(v_titel[current][i],DateField.DATE);
                    df.setDate(new Date());
                    if (v_antwoord[current][i]!=null)
                        df.setDate(new Date(Long.parseLong(v_antwoord[current][i])));
                    result.append(df);
                }
                break;
                case 5: {
                    TextField tf = new TextField(v_titel[current][i],"",100,TextField.EMAILADDR);
                    if (v_antwoord[current][i]!=null)
                        tf.setString(v_antwoord[current][i]);
                    result.append(tf);
                }
                break;
                case 6: {
                    Gauge g = new Gauge(v_titel[current][i],true,(int)v_max[current][i],(int) v_min[current][i]);
                    if (v_antwoord[current][i]!=null)
                        g.setValue(Integer.parseInt(v_antwoord[current][i]));
                    result.append(g);
                }
                break;
            }
        }
        if (current>0)
            result.addCommand(c_vorige);
        if (current<(s_id.length-1))
            result.addCommand(c_volgende);
        else
            result.addCommand(c_upload);
        result.setCommandListener(this);
        return result;
    }
    
    
    /** update v_antwoord
     * @return lijst van ongeldige antwoorden en omschrijvingen
     */
    String saveForm() {
        String result=new String();
        Form f = (Form) Display.getDisplay(this).getCurrent();
        for (int i =0; i < v_id[current].length; i++) {
            switch (v_type[current][i]) {
                case 0: {
                    TextField tf = (TextField) f.get(i+2);
                    v_antwoord[current][i] = tf.getString();
                }
                break;
                case 1: {
                    ChoiceGroup cg = (ChoiceGroup) f.get(i+2);
                    boolean[] b = new boolean[cg.size()];
                    int flags = cg.getSelectedFlags(b);
                    if (flags>=v_min[current][i] && flags<=v_max[current][i]) {
                        v_antwoord[current][i] = "";
                        for (int j = 0; j < b.length; j++)
                            if (b[j])
                                v_antwoord[current][i]+=a_id[current][i][j]+",";
                    }
                    else
                        result += "vraag "+(i+1)+": kies "+v_min[current][i]+" t/m "+v_max[current][i]+" checkboxen\n";
                }
                break;
                case 2: {
                    ChoiceGroup cg = (ChoiceGroup) f.get(i+2);
                    v_antwoord[current][i]=a_id[current][i][cg.getSelectedIndex()];
                }
                break;
                case 3: {
                    TextField tf = (TextField) f.get(i+2);
                    if (tf.getString().equals(""))
                        tf.setString("0");
                    int j = Integer.parseInt(tf.getString());
                    if (j>=v_min[current][i] && j<=v_max[current][i])
                        v_antwoord[current][i] = tf.getString();
                    else
                        result += "vraag "+(i+1)+": kies een getal van "+v_min[current][i]+" t/m "+v_max[current][i]+"\n";
                }
                break;
                case 4: {
                    DateField df = (DateField) f.get(i+2);
                    long value = df.getDate().getTime();
                    if (value>=v_min[current][i] && value<=v_max[current][i]) {
                        Calendar cur = Calendar.getInstance();
                        cur.setTime(df.getDate());
                        cur.set(Calendar.HOUR_OF_DAY,0);
                        cur.set(Calendar.MINUTE,0);
                        cur.set(Calendar.SECOND,0);
                        v_antwoord[current][i] = String.valueOf(cur.getTime().getTime());
                    }
                    else {
                        Calendar cmin = Calendar.getInstance();
                        Calendar cmax = Calendar.getInstance();
                        cmin.setTime(new Date(v_min[current][i]));
                        cmin.setTime(new Date(v_max[current][i]));
                        result += "vraag "+(i+1)+": kies een datum van "+cmin.toString().substring(0,cmin.toString().length()-12)+" t/m "+cmax.toString().substring(0,cmax.toString().length()-12)+"\n";
                    }
                }
                break;
                case 5: {
                    TextField tf = (TextField) f.get(i+2);
                    v_antwoord[current][i] = tf.getString();
                }
                break;
                case 6: {
                    Gauge g = (Gauge) f.get(i+2);
                    v_antwoord[current][i] = String.valueOf(g.getValue());
                }
                break;
            }
        }
        return result;
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
    
    public void commandAction(Command c, Displayable s) {
        String result = saveForm();
        if (c==c_upload) {
            Form f = new Form("uploading");
            String postdata = new String();
            for (int si = 0; si < v_id.length; si++) {
                for (int qi = 0; qi < v_id[si].length; qi++) {
                    postdata+=v_id[si][qi]+"="+v_antwoord[si][qi]+"&";
                }
            }
            f.append(postdata);
            Display.getDisplay(this).setCurrent(f);
        }
        else
            if (result.equals("")) {
                if (c == c_volgende) {
                    current++;
                }
                else
                    current--;
                Display.getDisplay(this).setCurrent(makeForm());
            }
            else
                Display.getDisplay(this).setCurrent(new Alert("ongeldig antwoord",result,null,null));
    }
    
    /** temporary method to fill database
     */
    void initialize() {
        Form form = new Form("eXamine");
        form.append("downloading");
        Display.getDisplay(this).setCurrent(form);
        try {
            HttpConnection conn = (HttpConnection) Connector.open("http://www.xs4all.nl/~nobsoft/examine.dat");
            DataInputStream dis = conn.openDataInputStream();
            int screens=dis.readInt();
            s_id = new String[screens];
            s_titel = new String[screens];
            s_text = new String[screens];
            v_id = new String[screens][];
            v_titel = new String[screens][];
            v_type = new byte[screens][];
            v_min = new long[screens][];
            v_max = new long[screens][];
            v_antwoord = new String[screens][];
            a_id = new String[screens][][];
            a_titel = new String[screens][][];
            for (int si = 0; si < screens; si++) {
                s_id[si] = dis.readUTF();
                s_titel[si] = dis.readUTF();
                s_text[si] = dis.readUTF();
                int questions = dis.readInt();
                v_id[si] = new String[questions];
                v_titel[si] = new String[questions];
                v_type[si] = new byte[questions];
                v_min[si] = new long[questions];
                v_max[si] = new long[questions];
                v_antwoord[si] = new String[questions];
                a_id[si] = new String[questions][];
                a_titel[si] = new String[questions][];
                for (int qi = 0; qi < questions; qi++) {
                    v_id[si][qi] = dis.readUTF();
                    v_titel[si][qi] = dis.readUTF();
                    v_type[si][qi] = dis.readByte();
                    v_min[si][qi] = dis.readLong();
                    v_max[si][qi] = dis.readLong();
                    int answers = dis.readInt();
                    a_id[si][qi] = new String[answers];
                    a_titel[si][qi] = new String[answers];
                    for (int ai = 0; ai < answers; ai++) {
                        a_id[si][qi][ai] = dis.readUTF();
                        a_titel[si][qi][ai] = dis.readUTF();
                    }
                }
            }
        }
        catch (Exception e) {
            form.append("error");
        }
        /*
         
        s_id=new String[3];
        s_id[0]="wlcm";
        s_id[1]="mid";
        s_id[2]="bye";
        s_titel=new String[3];
        s_titel[0]="het eerste scherm";
        s_titel[1]="dit is de tweede";
        s_titel[2]="scherm drie";
        s_text=new String[3];
        s_text[0]="hallo en welkom bij de test tester";
        s_text[1]="ok, en hoe denk je hierover..?";
        s_text[2]="nog even dit invullen dan klaar";
        v_id = new String[3][];//3 schermen
        v_id[0] = new String[3];//3 vragen in 1e scherm
        v_id[0][0]="name";
        v_id[0][1]="flags";
        v_id[0][2]="email";
        v_id[1] = new String[2];//3 vragen in 2e scherm
        v_id[1][0]="gender";
        v_id[1][1]="qty";
//        v_id[1][2
        v_id[2] = new String[3];//3 vragen in 3e scherm
        v_id[2][0]="dob";
        v_id[2][1]="pct";
        v_id[2][2]="true";
        v_titel = new String[3][];
        v_titel[0] = new String[3];
        v_titel[0][0]="lijf spreuk";
        v_titel[0][1]="hoe verplaats je je";
        v_titel[0][2]="wat is je email adres";
        v_titel[1] = new String[2];
        v_titel[1][0]="wat is je geslacht";
        v_titel[1][1]="wat is je geluks getal";
        v_titel[2] = new String[3];
        v_titel[2][0]="wat is je geboorte datum";
        v_titel[2][1]="wat vind je er van";
        v_titel[2][2]="naar waarheid ingevuld";
        v_type = new byte[3][];
        v_type[0] = new byte[3];
        v_type[0][0]=0;
        v_type[0][1]=1;
        v_type[0][2]=5;
        v_type[1] = new byte[2];
        v_type[1][0]=2;
        v_type[1][1]=3;
        v_type[2] = new byte[3];
        v_type[2][0]=4;
        v_type[2][1]=6;
        v_type[2][2]=1;
        v_min = new long[3][];
        v_min[0] = new long[3];
        //        v_min[0][0] = ...
        v_min[0][1]=1;
        // m_min[0][2]=
        v_min[1] = new long[2];
        //        v_min[1][0]=...
        v_min[1][1]=0;
        v_min[2] = new long[3];
        v_min[2][0]=0;
        v_min[2][1]=5;
        v_min[2][2]=1;
        v_max = new long[3][];
        v_max[0] = new long[2];
        //        v_max[0][0] = ...
        v_max[0][1]=2;
        // m_max[0][2]=
        v_max[1] = new long[2];
        //        v_max[1][0]=...
        v_max[1][1]=9;
        v_max[2] = new long[3];
        v_max[2][0]=System.currentTimeMillis();
        v_max[2][1]=10;
        v_max[2][2]=1;
        a_id          = new String[3][][];  //3 schermen
        a_id[0]       = new String[3][];    //  2 vragen
        a_id[0][0]    = new String[0];      //      0 antwoord
        a_id[0][1]    = new String[3];      //      3 antwoord
        a_id[0][1][0] = "ov";
        a_id[0][1][1] = "auto";
        a_id[0][1][2] = "benen";
        a_id[0][2]    = new String[0];      //      0 antwoord
        a_id[1]       = new String[2][];    //  2 vragen
        a_id[1][0]    = new String[2];      //      2 antwoord
        a_id[1][0][0] = "m";
        a_id[1][0][1] = "v";
        a_id[1][1]    = new String[0];      //      0 antwoord
        a_id[2]       = new String[3][];    //  3 vragen
        a_id[2][0]    = new String[0];      //      0 antwoord
        a_id[2][1]    = new String[0];      //      0 antwoord
        a_id[2][2]    = new String[1];      //      1 antwoord
        a_id[2][2][0] = "true";
        a_titel          = new String[3][][];//3 schermen
        a_titel[0]       = new String[3][]; //2 vragen in 1e scherm
        a_titel[0][0]    = new String[0];   //0 antwoord voor 1e vraan in 1e scherm
        a_titel[0][1]    = new String[3];   //3 antwoord voor 2e vraag in 1e scherm
        a_titel[0][1][0] = "bus/trein";
        a_titel[0][1][1] = "auto/motor";
        a_titel[0][1][2] = "lopen/fietsen";
        a_titel[0][2]    = new String[0];
        a_titel[1]       = new String[2][];//2 vragen in 2e scherm
        a_titel[1][0]    = new String[2];//2 antwoord voor 1e vraag in 2e scherm
        a_titel[1][0][0] = "man";
        a_titel[1][0][1] = "vrouw";
        a_titel[1][1]    = new String[0];//0 antwoord voor 2e vraag in 2e scherm
        a_titel[2]       = new String[3][];//2 vragen in 3e scherm
        a_titel[2][0]    = new String[0];
        a_titel[2][1]    = new String[0];
        a_titel[2][2]    = new String[1];
        a_titel[2][2][0] = "ja, echt waar";
        v_antwoord    = new String[3][];
        v_antwoord[0] = new String[3];
        v_antwoord[1] = new String[2];
        v_antwoord[2] = new String[3];
         */
    }
    
}
