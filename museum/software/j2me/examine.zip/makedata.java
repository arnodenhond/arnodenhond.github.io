import java.io.*;
import java.lang.*;
import java.util.*;

class makedata {
    
    public static void main(String[] args) throws Exception {
        args = new String[1];
        args[0]="E:/NOBSOFT/EXAMINE/knobbel.xml";
        
        String data = new String();
        FileInputStream fos = new FileInputStream(args[0]);
        while (fos.available()>0)
            data+=(char) fos.read();
        ArrayList screens = new ArrayList();
        int sindex = 0;
        while (data.indexOf("<Screen",sindex)!=-1) {
            sindex = data.indexOf("<Screen",sindex)+1;
            String ssid = data.substring( data.indexOf("ID=",sindex)+4 , data.indexOf("\"",data.indexOf("ID=",sindex)+5) );
            String sstitel = data.substring( data.indexOf("Title=",sindex)+7, data.indexOf("\"",data.indexOf("Title=",sindex)+8) );
            String sstext = data.substring( data.indexOf("<![CDATA[",sindex)+9 , data.indexOf("]]",sindex) );
            System.out.println("scherm id:"+ssid);
            System.out.println("scherm titel:"+sstitel);
            System.out.println("scherm text:"+sstext);
            screen s = new screen(sstitel, sstext, ssid);
            screens.add(s);
            String screen = data.substring(sindex,data.indexOf("</Screen>",sindex));
            int qindex = 0;
            while (screen.indexOf("<Question",qindex)!=-1) {
                qindex = screen.indexOf("<Question",qindex)+1;
                String svid = screen.substring( screen.indexOf("ID=",qindex)+4,screen.indexOf("\"",screen.indexOf("ID=",qindex)+5) );
                String svtitel = screen.substring( screen.indexOf("<![CDATA[",qindex)+9,screen.indexOf("]]",qindex) );
                Byte bvtype = new Byte( screen.substring( screen.indexOf("Type=",qindex)+6,screen.indexOf("\"",screen.indexOf("Type=",qindex)+7) ));
                System.out.println("vraag id:"+svid);
                System.out.println("vraag titel:"+svtitel);
                System.out.println("vraag type:"+bvtype.toString());
                question q = new question(svtitel,svid,bvtype);
                s.questions.add(q);
                String question = screen.substring(qindex,screen.indexOf("</Question>",qindex));
                int aindex = 0;
                while (question.indexOf("<Answer",aindex)!=-1) {
                    aindex = question.indexOf("<Answer",aindex)+1;
                    String said = question.substring( question.indexOf("ID=",aindex)+4,question.indexOf("\"",question.indexOf("ID=",aindex)+5) );
                    String satitel = question.substring( question.indexOf("<![CDATA[",aindex)+9,question.indexOf("]]",aindex) );
                    System.out.println("antwoord id:"+said);
                    System.out.println("antwoord titel:"+satitel);
                    answer a = new answer(satitel,said);
                    q.answers.add(a);
                    
                }
            }
        }
        String[] s_id;
        String[] s_titel;
        String[] s_text;
        
        String[][] v_id;
        String[][] v_titel;
        byte[][]   v_type;
        long[][]   v_min;
        long[][]   v_max;
        
        String[][][] a_id;
        String[][][] a_titel;
        
        s_id = new String[screens.size()];
        s_titel = new String[screens.size()];
        s_text = new String[screens.size()];
        
        v_id = new String[screens.size()][];
        v_titel = new String[screens.size()][];
        v_type = new byte[screens.size()][];
        v_min = new long[screens.size()][];
        v_max = new long[screens.size()][];
        
        a_id = new String[screens.size()][][];
        a_titel = new String[screens.size()][][];
        
        for (int si = 0; si < screens.size(); si++) {
            screen s = (screen) screens.get(si);
            s_id[si] = s.id;
            s_titel[si] = s.titel;
            s_text[si] = s.text;
            
            v_id[si] = new String[s.questions.size()];
            v_titel[si] = new String[s.questions.size()];
            v_type[si] = new byte[s.questions.size()];
            v_min[si] = new long[s.questions.size()];
            v_max[si] = new long[s.questions.size()];
            
            a_id[si] = new String[s.questions.size()][];
            a_titel[si] = new String[s.questions.size()][];
            for (int qi = 0; qi < s.questions.size(); qi++) {
                question q = (question) s.questions.get(qi);
                v_id[si][qi] = q.id;
                v_titel[si][qi] = q.titel;
                switch (q.type.byteValue())
                {
                    case 1:v_type[si][qi]=0;break;//textveld
                    case 2:v_type[si][qi]=0;break;//textblok
                    case 3:v_type[si][qi]=2;break;//dropdown
                    case 4:v_type[si][qi]=2;break;//radiolist
                    case 5:v_type[si][qi]=1;break;//checklist
                    case 6:v_type[si][qi]=3;break;//getal
                    case 7:v_type[si][qi]=4;break;//datum
                    case 8:v_type[si][qi]=5;break;//email
                    case 9:v_type[si][qi]=6;break;//schaal
                }
                //v_type[si][qi] = q.type.byteValue();
                v_min[si][qi] = Long.MIN_VALUE;
                v_max[si][qi] = Long.MAX_VALUE;
                
                a_id[si][qi] = new String[q.answers.size()];
                a_titel[si][qi] = new String[q.answers.size()];
                
                for (int ai = 0; ai < q.answers.size(); ai++) {
                    answer a = (answer) q.answers.get(ai);
                    a_id[si][qi][ai] = a.id;
                    a_titel[si][qi][ai] = a.titel;
                }
            }
            
        }
/*        s_id=new String[3];
        s_id[0]="wlcm";
        s_id[1]="mid";
        s_id[2]="bye";
        s_titel=new String[3];
        s_titel[0]="het eerste scherm";
        s_titel[1]="dit is de tweede";
        s_titel[2]="scherm drie";
        s_text=new String[3];
        s_text[0]="hallo en welkom bij de test tester";
        s_text[1]="ok, en hoe denk je hierover..?";
        s_text[2]="nog even dit invullen dan klaar";
        v_id = new String[3][];//3 schermen
        v_id[0] = new String[3];//3 vragen in 1e scherm
        v_id[0][0]="name";
        v_id[0][1]="flags";
        v_id[0][2]="email";
        v_id[1] = new String[2];//2 vragen in 2e scherm
        v_id[1][0]="gender";
        v_id[1][1]="qty";
        v_id[2] = new String[3];//3 vragen in 3e scherm
        v_id[2][0]="dob";
        v_id[2][1]="pct";
        v_id[2][2]="true";
        v_titel = new String[3][];
        v_titel[0] = new String[3];
        v_titel[0][0]="lijf spreuk";
        v_titel[0][1]="hoe verplaats je je";
        v_titel[0][2]="wat is je email adres";
        v_titel[1] = new String[2];
        v_titel[1][0]="wat is je geslacht";
        v_titel[1][1]="wat is je geluks getal";
        v_titel[2] = new String[3];
        v_titel[2][0]="wat is je geboorte datum";
        v_titel[2][1]="wat vind je er van";
        v_titel[2][2]="naar waarheid ingevuld";
        v_type = new byte[3][];
        v_type[0] = new byte[3];
        v_type[0][0]=0;
        v_type[0][1]=1;
        v_type[0][2]=5;
        v_type[1] = new byte[2];
        v_type[1][0]=2;
        v_type[1][1]=3;
        v_type[2] = new byte[3];
        v_type[2][0]=4;
        v_type[2][1]=6;
        v_type[2][2]=1;
        v_min = new long[3][];
        v_min[0] = new long[3];
        v_min[0][0]=0;
        v_min[0][1]=1;
        v_min[0][2]=0;
        v_min[1] = new long[2];
        v_min[1][0]=0;
        v_min[1][1]=0;
        v_min[2] = new long[3];
        v_min[2][0]=0;
        v_min[2][1]=5;
        v_min[2][2]=1;
        v_max = new long[3][];
        v_max[0] = new long[3];
        v_max[0][0] = 0;
        v_max[0][1]=2;
        v_max[0][2]=0;
        v_max[1] = new long[2];
        v_max[1][0]=0;
        v_max[1][1]=9;
        v_max[2] = new long[3];
        v_max[2][0]=System.currentTimeMillis();
        v_max[2][1]=10;
        v_max[2][2]=1;
        a_id          = new String[3][][];  //3 schermen
        a_id[0]       = new String[3][];    //  2 vragen
        a_id[0][0]    = new String[0];      //      0 antwoord
        a_id[0][1]    = new String[3];      //      3 antwoord
        a_id[0][1][0] = "ov";
        a_id[0][1][1] = "auto";
        a_id[0][1][2] = "benen";
        a_id[0][2]    = new String[0];      //      0 antwoord
        a_id[1]       = new String[2][];    //  2 vragen
        a_id[1][0]    = new String[2];      //      2 antwoord
        a_id[1][0][0] = "m";
        a_id[1][0][1] = "v";
        a_id[1][1]    = new String[0];      //      0 antwoord
        a_id[2]       = new String[3][];    //  3 vragen
        a_id[2][0]    = new String[0];      //      0 antwoord
        a_id[2][1]    = new String[0];      //      0 antwoord
        a_id[2][2]    = new String[1];      //      1 antwoord
        a_id[2][2][0] = "true";
        a_titel          = new String[3][][];//3 schermen
        a_titel[0]       = new String[3][]; //3 vragen in 1e scherm
        a_titel[0][0]    = new String[0];
        a_titel[0][1]    = new String[3];
        a_titel[0][1][0] = "bus/trein";
        a_titel[0][1][1] = "auto/motor";
        a_titel[0][1][2] = "lopen/fietsen";
        a_titel[0][2]    = new String[0];
        a_titel[1]       = new String[2][];//2 vragen in 2e scherm
        a_titel[1][0]    = new String[2];
        a_titel[1][0][0] = "man";
        a_titel[1][0][1] = "vrouw";
        a_titel[1][1]    = new String[0];
        a_titel[2]       = new String[3][];//2 vragen in 3e scherm
        a_titel[2][0]    = new String[0];
        a_titel[2][1]    = new String[0];
        a_titel[2][2]    = new String[1];
        a_titel[2][2][0] = "ja, echt waar";
 */
        DataOutputStream dos = new DataOutputStream(new FileOutputStream("E:/NOBSOFT/EXAMINE/examine.dat"));
        dos.writeInt(s_id.length);//aantal schermen
        for (int i = 0; i < s_id.length; i++) {
            dos.writeUTF(s_id[i]);
            dos.writeUTF(s_titel[i]);
            dos.writeUTF(s_text[i]);
            dos.writeInt(v_id[i].length);//aantal vragen
            for (int j = 0; j < v_id[i].length; j++) {
                dos.writeUTF(v_id[i][j]);
                dos.writeUTF(v_titel[i][j]);
                dos.writeByte(v_type[i][j]);
                dos.writeLong(v_min[i][j]);
                dos.writeLong(v_max[i][j]);
                dos.writeInt(a_id[i][j].length);//aantal antwoorden
                for (int k = 0; k < a_id[i][j].length; k++) {
                    dos.writeUTF(a_id[i][j][k]);
                    dos.writeUTF(a_titel[i][j][k]);
                }
            }
        }
        dos.flush();
        dos.close();
    }
}

class screen {
    screen(String titel, String text, String id) {
        this.titel = titel;
        this.text = text;
        this.id = id;
        questions = new ArrayList();
    }
    String titel;
    String text;
    String id;
    ArrayList questions;
}

class question {
    question(String titel, String id, Byte type) {
        this.titel=titel;
        this.id = id;
        this.type = type;
        answers = new ArrayList();
    }
    String titel;
    String id;
    Byte type;
    ArrayList answers;
}

class answer {
    answer(String titel, String id) {
        this.titel = titel;
        this.id = id;
    }
    String titel;
    String id;
}