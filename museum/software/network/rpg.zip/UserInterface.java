
import java.net.*;
import java.util.*;
import java.io.*;

class UserInterface extends Thread {
    
    static String getRequesthdr(BufferedReader in) throws Exception {
        String templine = " ";
        String requesthdr = "";
        while (!templine.equals("")) {
            templine = in.readLine();
            requesthdr += templine+"|";
        }
        requesthdr = new URLDecoder().decode(requesthdr);
        return requesthdr;
    }
    
    static String getPostdata(String requesthdr, BufferedReader in) throws Exception {
        String postdata = new String();
        int clstart=requesthdr.toUpperCase().indexOf("CONTENT-LENGTH:");
        if (clstart!=-1) {
            int length=new Integer(requesthdr.substring(clstart+16,requesthdr.indexOf("|",clstart))).intValue();
            char[] pdchars = new char[length];
            int rl=0;
            while (rl<length)
                rl+=in.read(pdchars,rl,length-rl);
            postdata=new String(pdchars);
            postdata = new URLDecoder().decode(postdata);
        }
        return postdata;
    }
    
    Socket s;
    ArrayList routers;
    
    public UserInterface(Socket s, ArrayList routers) {
        this.s = s;
        this.routers = routers;
    }
    
    public void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String requesthdr = getRequesthdr(in);
            
            StringTokenizer st = new StringTokenizer(requesthdr," ");
            boolean POST = st.nextToken().toUpperCase().equals("POST");
            String URL = st.nextToken();
            
            String postdata=new String();
            if (POST)
                postdata = getPostdata(requesthdr, in);
            else
                if (URL.indexOf("?")!=-1)
                    postdata = URL.substring(URL.indexOf("?")+1,URL.length());
            PostData pd = new PostData(postdata);
            for (int i = 0; i < pd.elements.size(); i++) {
                String elem = (String) pd.elements.get(i);
                String val = (String) pd.values.get(i);
                //                System.out.println("elem: "+elem+" - val: "+val);
            }
            PrintWriter pw = new PrintWriter(s.getOutputStream(),true);
            pw.println("HTTP/1.0 200 OK");
		pw.println("content-type=text/html\r\n");
            
            //            pw.println("Router Playing Game v0.1 -- noBSoft <hr>");
            
            
            if (URL.equals("/")) {
                pw.println("<title>Router Playing Game</title>");
                pw.println("<frameset cols=25%,50%,25%>");
                pw.println("<frame src=/leftindex>");
                pw.println("<frame name=routerframe>");
                pw.println("<frame src=/listrouters>");
                pw.println("</frameset>");
            }
            if (URL.equals("/leftindex")) {
                pw.println("<frameset rows=25%,25%,25%,25%>");
                pw.println("<frame src=/routers>");
                pw.println("<frame src=/connections>");
                pw.println("<frame src=/msggen>");
                pw.println("<frame src=/forwarding>");
                pw.println("</frameset>");
            }
            
            if (URL.equals("/listrouters")) {
                pw.println("<meta http-equiv=REFRESH content=5>");
                
                pw.println("<table>");
                pw.println("<tr><td>name</td><td>in</td><td>out</td><td>wait</td><td>conn</td><td>dest</td></tr>");
                for (int i = 0; i < routers.size(); i++) {
                    Router r = (Router) routers.get(i);
                    pw.println("<tr><td>");
                    pw.println("<a href=\"/login/stats/"+r.name+"\" target=routerframe>"+r.name+"</a> <br>");
                    pw.println("</td><td>");
                    pw.println(r.totalin);
                    pw.println("</td><td>");
                    pw.println(r.totalout);
                    pw.println("</td><td>");
                    pw.println(r.inbox.size());
                    pw.println("</td><td>");
                    pw.println(r.connections.size());
                    pw.println("</td><td>");
                    float fd = (float) r.destinations.size();
                    float fs = (float) routers.size()-1;
                    float f = (fd/fs);
                    pw.println((f*100)+"%");
                    pw.println("</td></tr>");
                }
                pw.println("</table>");
                pw.println("<hr><center><a href=/listrouters><b>refresh</b></a></center>");
            }
            
            if (URL.equals("/createrouter")) {
                String name = pd.getValue("name");
                routers.add(new Router(name));
                pw.println("<b> router "+name+" created </b> <hr>");
                URL = "/routers";
            }
            if (URL.equals("/deleterouter")) {
                Router r = (Router) routers.get(new Integer(pd.getValue("rid")).intValue());
                pw.println("<b> router "+r.name+" deleted </b> <hr>");
                routers.remove(r);
                for (int i = 0; i < r.connections.size(); i++) {
                    Connection c = (Connection) r.connections.get(i);
                    disconnect(r,c.router);
                    i--;
                }
                for (int i = 0; i < routers.size(); i++) {
                    Router r2 = (Router) routers.get(i);
                    r2.delDestination(r);
                    for (int j = 0; j < r2.inbox.size(); j++) {
                        Message m = (Message) r2.inbox.get(j);
                        if (m.sender==r) {
                            r2.inbox.remove(m);
                            j--;
                        }
                    }
                }
                URL = "/routers";
            }
            
            if (URL.equals("/routers")) {
                pw.println("<b><center>create/delete a router</center></b><hr>");
                pw.println("<form action=/createrouter method=post>");
                pw.println("<input type=text name=name>");
                pw.println("<input type=submit value=create>");
                pw.println("</form>");
                pw.println("<form action=/deleterouter method=post>");
                pw.println(makeRouterSelect(null,"rid"));
                pw.println("<input type=submit value=delete>");
                pw.println("</form>");
                pw.println("<hr><center><a href=/routers><b>refresh</b></a></center>");
            }
            
            if (URL.equals("/createconnection")) {
                Router r1 = (Router) routers.get(new Integer(pd.getValue("rid1")).intValue());
                Router r2 = (Router) routers.get(new Integer(pd.getValue("rid2")).intValue());
                if (connect(r1,r2))
                    pw.println("<b>connection created from "+r1.name+" to "+r2.name+"</b><hr>");
                else
                    pw.println("<b>unable to create connection from "+r1.name+" to "+r2.name+"</b><hr>");
                URL="/connections";
            }
            if (URL.equals("/deleteconnection")) {
                Router r1 = (Router) routers.get(new Integer(pd.getValue("rid1")).intValue());
                Router r2 = (Router) routers.get(new Integer(pd.getValue("rid2")).intValue());
                if (disconnect(r1,r2))
                    pw.println("<b>connection removed from "+r1.name+" to "+r2.name+"</b><hr>");
                else
                    pw.println("<b>unable to remove connection from "+r1.name+" to "+r2.name+"</b><hr>");
                URL="/connections";
            }
            
            if (URL.equals("/connections")) {
                pw.println("<center><b>connect/disconnect routers</b></center><hr>");
                pw.println("<form action=/createconnection method=post>");
                pw.println(makeRouterSelect(null,"rid1"));
                pw.println(makeRouterSelect(null,"rid2"));
                pw.println("<input type=submit value=connect>");
                pw.println("</form>");
                pw.println("<form action=/deleteconnection method=post>");
                pw.println(makeRouterSelect(null,"rid1"));
                pw.println(makeRouterSelect(null,"rid2"));
                pw.println("<input type=submit value=disconnect>");
                pw.println("</form>");
                pw.println("<hr><center><a href=/connections><b>refresh</b></a></center>");
            }
            
            if (URL.equals("/autogen")) {
                pw.println("<meta http-equiv=REFRESH content=5>");
                pw.println("<center><a href=/msggen><b>stop auto generate</b></a></center><hr>");
                if (routers.size()>0) {
                    Random rnd = new Random(System.currentTimeMillis());
                    Router r1 = (Router) routers.get(rnd.nextInt(routers.size()));
                    Router r2 = (Router) routers.get(rnd.nextInt(routers.size()));
                    if (r1!=r2) {
                        r1.totalgen++;
                        Message m = new Message(r1,r2);
                        r1.inbox.add(m);
                        r1.history.add(0,m);
                        r1.log.add("message generated to "+ r2.name);
                        pw.println("<b>message generated from "+r1.name+" to "+ r2.name+"</b><hr>");
                    }
                    else
                        pw.println("<b>cannot generate message to self</b><hr>");
                }
                else
                    pw.println("<b>none to generate</b>");
            }
            if (URL.equals("/createmessage")) {
                Router r1 = (Router) routers.get(new Integer(pd.getValue("from")).intValue());
                Router r2 = (Router) routers.get(new Integer(pd.getValue("to")).intValue());
                if (r1!=r2) {
                    r1.totalgen++;
                    Message m = new Message(r1,r2);
                    r1.inbox.add(m);
                    r1.history.add(0,m);
                    pw.println("<b>message generated from "+r1.name+" to "+ r2.name+"</b><hr>");
                }
                else
                    pw.println("<b>cannot generate message to self</b><hr>");
                
                URL="/msggen";
            }
            
            if (URL.equals("/msggen")) {
                pw.println("<b><center>generate message</center></b><hr>");
                pw.println("<a href=/autogen>auto generator</a><br>");
                pw.println("<form action=/createmessage method=post>");
                pw.println("from :"+makeRouterSelect(null,"from"));
                pw.println("to:"+makeRouterSelect(null,"to"));
                pw.println("<input type=submit value=generate>");
                pw.println("</form>");
                pw.println("<hr><center><a href=/msggen><b>refresh</b></a></center>");
            }
            
            if (URL.equals("/autoforward")) {
                pw.println("<meta http-equiv=REFRESH content=5>");
                pw.println("<center><a href=/forwarding><b>stop auto forward</b></a></center><hr>");
                if (routers.size()>0) {
                    Random rnd = new Random(System.currentTimeMillis());
                    Router r = (Router) routers.get(rnd.nextInt(routers.size()));
                    r.forward();
                    pw.println("<b>"+r.name+" in: "+r.lastin()+" out: "+r.lastout()+"</b><hr>");
                }
                else
                    pw.println("<b>none to forward</b>");
            }
            
            if (URL.equals("/doforward")) {
                Router r = (Router) routers.get(new Integer(pd.getValue("rid")).intValue());
                r.forward();
                pw.println("<b>"+r.name+" in: "+r.lastin()+" out: "+r.lastout()+"</b><hr>");
                URL="/forwarding";
            }
            
            if (URL.equals("/forwarding")) {
                pw.println("<b><center>forward messages</center></b><hr>");
                pw.println("<a href=/autoforward>auto forward</a><br>");
                pw.println("<form action=/doforward method=post>");
                pw.println(makeRouterSelect(null,"rid"));
                pw.println("<input type=submit value=forward>");
                pw.println("</form>");
                pw.println("<hr><center><a href=/forwarding><b>refresh</b></a></center>");
            }
            
            if (URL.startsWith("/login/dest")) {
                String name = URL.substring(URL.lastIndexOf('/')+1,URL.length());
                Router r = (Router) findRouter(name);
                pw.println("<h2><center>"+r.name+"</h2><br>");
                pw.println("<a href=/login/stats/"+name+">stats</a> - <b>destinations</b> - <a href=/login/log/"+name+">log</a></center><hr>");
                for (int i = 0; i < r.connections.size(); i++) {
                    Connection c = (Connection) r.connections.get(i);
                    pw.println("<table><tr><td>"+c.router.name+"</td></tr>");
                    for (int j = 0; j < r.destinations.size(); j++) {
                        Destination d = (Destination) r.destinations.get(j);
                        if (d.connection==c)
                            pw.println("<tr><td></td><td>"+d.destination.name+"</td><td>from: "+d.from+"</td><td>to: "+d.to+"</td></tr>");
                    }
                    pw.println("</table>");
                }
            }
            if (URL.startsWith("/login/log")) {
                String name = URL.substring(URL.lastIndexOf('/')+1,URL.length());
                Router r = (Router) findRouter(name);
                pw.println("<h2><center>"+r.name+"</h2><br>");
                pw.println("<a href=/login/stats/"+name+">stats</a> - <a href=/login/dest/"+name+">destinations</a> - <b>log</b></center><hr>");
                for (int i = 0; i < r.log.size(); i++) {
                    String s = (String) r.log.get(i);
                    pw.println(s+"<br>");
                }
            }
            if (URL.startsWith("/login/stats")) {
                String name = URL.substring(URL.lastIndexOf('/')+1,URL.length());
                Router r = (Router) findRouter(name);
                pw.println("<h2><center>"+r.name+"</h2><br>");
                pw.println("<b>stats</b> - <a href=/login/dest/"+name+">destinations</a> - <a href=/login/log/"+name+">log</a></center><hr>");
                pw.println("<table><tr><td></td><td>total</td><td>last</td></tr>");
                pw.println("<tr><td>incoming</td><td>"+r.totalin+"</td><td>"+r.lastin()+"</td></tr>");
                pw.println("<tr><td>outgoing</td><td>"+r.totalout+"</td><td>"+r.lastout()+"</td></tr>");
                pw.println("<tr><td>delivered</td><td>"+r.totaldel+"</td><td></td></tr>");
                pw.println("<tr><td>generated</td><td>"+r.totalgen+"</td><td></td></tr>");
                pw.println("</table>");
                pw.println("<hr> connections <br>");
                pw.println("<table>");
                pw.println("<tr><td>name</td><td>total in</td><td>total out</td><td>destinations</td><td>last in</td><td>last out</td></tr>");
                for (int i = 0; i < r.connections.size(); i++) {
                    Connection c = (Connection) r.connections.get(i);
                    pw.println("<tr><td>"+c.router.name);
                    pw.println("</td><td>"+c.totalin);
                    pw.println("</td><td>"+c.totalout);
                    float fd = (float) r.numberDestinations(c);
                    float fs = (float) routers.size()-1;
                    float f = (fd/fs);
                    pw.println("</td><td>"+(f*100)+"% <br>");
                    pw.println("</td><td>"+c.lastin);
                    pw.println("</td><td>"+c.lastout+"</td></tr>");
                }
                pw.println("</table>");
            }
            s.close();
        }
        catch (Exception e) {
            System.out.println("error occurred while handling connection!");
            System.out.println(e.toString());
            e.printStackTrace(System.out);
        }
    }
    
    Router findRouter(String name) {
        for (int i = 0; i < routers.size(); i++) {
            Router r = (Router) routers.get(i);
            if (r.name.equals(name))
                return r;
        }
        return null;
    }
    
    String makeRouterSelect(Router rthis, String tagname) {
        String result = "<select name="+tagname+">";
        for (int i = 0; i < routers.size(); i++) {
            Router r = (Router) routers.get(i);
            if ((r==rthis) | (connected(r,rthis)))
                continue;
            result+="<option value="+i+">"+r.name+"</option>";
        }
        result+="</select>";
        return result;
    }
    
    boolean connected(Router r1, Router r2) {
        for (int i = 0; i < r1.connections.size(); i++) {
            Connection c = (Connection) r1.connections.get(i);
            if (c.router==r2)
                return true;
        }
        return false;
    }
    
    boolean connect(Router r1, Router r2) {
        if (!connected(r1,r2) & (r1!=r2) ) {
            r1.connections.add(new Connection(r2));
            r2.connections.add(new Connection(r1));
            return true;
        }
        return false;
    }
    
    boolean disconnect(Router r1, Router r2) {
        if (connected(r1,r2)) {
            r1.delConnection(r2);
            r2.delConnection(r1);
            return true;
        }
        return false;
    }
    
}
