
import java.util.*;

class PostData
{
  ArrayList elements;
  ArrayList values;

  PostData(String s)
  {
    elements = new ArrayList();
    values = new ArrayList();
    StringTokenizer st = new StringTokenizer(s,"&");
    while (st.hasMoreTokens())
    {
      String pdp=st.nextToken();
      String element=pdp.substring(0,pdp.indexOf("="));
      String value=pdp.substring(pdp.indexOf("=")+1,pdp.length());
      elements.add(element);
      values.add(value);
    }
  }

  String getValue(String element)
  {
    for (int i = 0; i < elements.size(); i++)
    {
      String s = (String) elements.get(i);
      if (s.equalsIgnoreCase(element))
      {
        String result = (String) values.get(i);
        return result;
      }
    }
    return new String();
  }

}

