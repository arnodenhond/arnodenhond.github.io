
import java.net.*;
import java.util.*;

class RPG {
    
    
    public RPG() {
    }
    
    public static void main(String[] args) throws Exception {
        ArrayList routers = new ArrayList();
        //new Processor(routers).start();
        ServerSocket ss = new ServerSocket(80);
        ss.setSoTimeout(1000);
        while (true) {
            try {
                Socket s = ss.accept();
                new UserInterface(s,routers).start();
            }
            catch (Exception e) {
            }
        }
    }
    
}
