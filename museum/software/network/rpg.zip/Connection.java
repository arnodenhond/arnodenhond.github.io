
class Connection {
    
    Router router;
    int totalin;
    int totalout;
    int lastin;
    int lastout;
    int curin;
    int curout;
    
    public Connection(Router router) {
        this.router = router;
    }

    
}
