
import java.util.*;

class Router {
    
    String name;
    ArrayList connections;
    ArrayList destinations;
    ArrayList history;
    ArrayList inbox;
    ArrayList log;
    int totalin;
    int totalout;
    int totalgen;
    int totaldel;

    public Router(String name) {
        this.name=name;
        connections = new ArrayList();
        destinations = new ArrayList();
        history = new ArrayList();
        inbox = new ArrayList();
        log = new ArrayList();
    }
    
    void forward() {
        log = new ArrayList();
        for (int i = 0; i < connections.size(); i++) {
            Connection c = (Connection) connections.get(i);
            c.lastout=c.curout;
            c.curout=0;
            c.lastin=c.curin;
            c.curin=0;
        }
        for (int i = 0; i < inbox.size(); i++) {
            Message m = (Message) inbox.get(i);
            log.add("processing message from "+m.sender.name+" to "+m.receiver.name);
            if (m.receiver == this) {
                totaldel++;
                log.add("message delivered");
                continue;
            }
            Connection c = findDestination(m.receiver);
            if (c==null) {
                log.add("unknown destination, forwarding");
                for (int j = 0; j < connections.size(); j++) {
                    c = (Connection) connections.get(j);
                    send(m,c);
                }
            }
            else
                send(m,c);
        }
        inbox = new ArrayList();
    }
    
    boolean send(Message m, Connection c) {
        if (!connections.contains(c)) {
            System.out.println("ERROR , unable to send");
            return false;
        }
        boolean ok = c.router.receive(m, this);
        if (ok) {
            c.totalout++;
            totalout++;
            c.curout++;
            for (int i = 0; i < destinations.size(); i++) {
                Destination d = (Destination) destinations.get(i);
                if (d.destination==m.receiver) {
                    d.to++;
                    break;
                }
            }
            log.add("forwarded to "+c.router.name);
        }
        else
            log.add(c.router.name+" did not accept");
        return ok; //whether or not the connection acutally accepted the offered message
    }
    
    boolean receive(Message m, Router r) {
        if (!history.contains(m)) {
            log.add("message from "+m.sender.name+" to "+m.receiver.name+" received from "+r.name);
            history.add(0, m);
            Connection c = findConnection(r);
            c.totalin++;
            totalin++;
            c.curin++;
            updateDestination(m.sender,c);
            for (int i = 0; i < destinations.size(); i++) {
                Destination d = (Destination) destinations.get(i);
                if (d.destination==m.sender) {
                    d.from++;
                    break;
                }
            }
            inbox.add(m);
            return true;
        }
        return false;
    }
    
    void clearDestination(Connection c) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.connection==c) {
                destinations.remove(d);
                i--;
            }
        }
    }
    
    void delConnection(Router r) {
        for (int i = 0; i < connections.size(); i++) {
            Connection c = (Connection) connections.get(i);
            if (c.router==r) {
                clearDestination(c);
                connections.remove(c);
                return;
            }
        }
    }
    
    void delDestination(Router r) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==r) {
                destinations.remove(d);
                return;
            }
        }
    }
    
    void updateDestination(Router destination, Connection connection) {
        if (!connections.contains(connection)) {
            System.out.println("ERROR, unable to update destination");
            return;
        }
        boolean found=false;
        for (int i = 0; i< destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==destination) {
                if (d.connection != connection) {
                    d.connection = connection;
                    log.add("destination updated");
                }
                else
                    log.add("destination not updated");
                found=true;
                break;
            }
        }
        if (!found) {
            destinations.add(new Destination(destination,connection));
            log.add("destination added");
        }
    }
    
    Connection findDestination(Router r) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==r)
                return d.connection;
        }
        return null;
    }
    
    Connection findConnection(Router r) {
        for (int i = 0; i < connections.size(); i++) {
            Connection c = (Connection) connections.get(i);
            if (c.router == r)
                return c;
        }
        System.out.println("ERROR, unable to find connection");
        return null;
    }
    
    int numberDestinations(Connection c) {
        int result = 0;
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.connection==c)
                result++;
        }
        return result;
    }


    int lastin() {
        int result=0;
        for (int i = 0; i < connections.size(); i++) {
            Connection c = (Connection) connections.get(i);
            result+=c.lastin;
        }
        return result;
    }

    int lastout() {
        int result=0;
        for (int i = 0; i < connections.size(); i++) {
            Connection c = (Connection) connections.get(i);
            result+=c.lastout;
        }
        return result;
    }
    
}
