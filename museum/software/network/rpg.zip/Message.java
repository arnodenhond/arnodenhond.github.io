
class Message {
    
    Router sender;
    
    Router receiver;
    
    public Message(Router sender, Router receiver) {
        this.sender = sender;
        this.receiver = receiver;
    }
    
}
