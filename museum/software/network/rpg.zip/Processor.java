
import java.util.*;

class Processor extends Thread {
    
    ArrayList routers;
    
    public Processor(ArrayList routers) {
        this.routers = routers;
    }
    
    public void run() {
        Random rnd = new Random(System.currentTimeMillis());
        while (true) {
            try {
                sleep(1);
            } catch (Exception e)
            {}
            if (routers.size()==0)
                continue;
            Router r = (Router) routers.get(rnd.nextInt(routers.size()));
            System.out.println("processing "+r.name);
            Router r2 = (Router) routers.get(rnd.nextInt(routers.size()));
            if (r!=r2) {
                //r.totalsent++;
                Message m = new Message(r,r2);
                r.inbox.add(m);
                r.history.add(0,m);
            }
            r.forward();
        }
    }
    
}
