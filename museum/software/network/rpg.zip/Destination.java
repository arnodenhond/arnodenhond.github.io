
class Destination {
    
    Router destination;
    Connection connection;
    int from;
    int to;
    
    public Destination(Router destination, Connection connection) {
        this.destination = destination;
        this.connection = connection;
    }
    
}
