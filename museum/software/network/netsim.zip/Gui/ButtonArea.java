package Gui;

import Network.Node;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

public class ButtonArea extends JPanel implements ActionListener {
    
    DrawArea drawArea;
    JToggleButton startstop;
    boolean running;
    
    public ButtonArea(DrawArea drawArea,NodePanel np) {
        this.drawArea = drawArea;
        running = false;
        GridBagLayout gbl = new GridBagLayout();
        startstop = new JToggleButton("start",false);
        startstop.addActionListener(this);
        this.add(startstop);
        this.add(np);
        this.setLayout(gbl);
    }
    
    public Dimension getPreferredSize() {
        return new Dimension(200, 600);
    }

    public void actionPerformed(ActionEvent e) {
        running=!running;
        if (running)
            startstop.setText("stop");
        else
            startstop.setText("start");
            
    }
    
}
