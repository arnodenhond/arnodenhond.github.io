package Gui;

import Network.Connection;
import Network.Message;
import Network.Node;
import Network.Network;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;
import java.util.Random;
import javax.swing.JPanel;

class DrawArea extends JPanel implements MouseListener {
    
    Node[] nodes;
    
    Connection[] connections;
    
    Message message;
    Node node1;
    Node node2;
    Network network;
    NodePanel np;
    
    DrawArea(Network network,NodePanel np) {
        this.addMouseListener(this);
        this.nodes = network.nodes;
        //node1=network.nodes[500];
        this.connections = network.connections;
        message=null;
        this.network = network;
        this.np=np;
    }
    
    public void setMessage(Message message) {
        this.message = message;
    }
    
    public void paint(Graphics g) {
        g.setColor(new Color(0));
        g.fillRect(0, 0, 600, 600);
        Color blue =new Color(32452);
        Color white = new Color(Integer.MAX_VALUE);
        Color black = Color.PINK;
        
        for (int i = 0; i < nodes.length; i++) {
            g.setColor(blue);
            Iterator connections = nodes[i].connections.values().iterator();
            while (connections.hasNext()) {
                Connection connection = (Connection) connections.next();
                Iterator queue = connection.queue.iterator();
                while (queue.hasNext()) {
                    Message m = (Message) queue.next();
                    if (m.isFrom(node1)) {
                        g.setColor(Color.RED);
                        g.drawString(m.getHops()+"",nodes[i].x,nodes[i].y);
                        break;
                    }
                }
                /*
                if (connection.queue.contains(message)) {
                    Message m = (Message) connection.queue.get(connection.queue.indexOf(message));
                    g.setColor(new Color(Integer.MAX_VALUE));
                    g.drawString(m.getHops()+"",nodes[i].x,nodes[i].y);
                    break;
                }
                 */
            }
            if (nodes[i]==node1)
                g.setColor(Color.MAGENTA);
            g.fillOval(nodes[i].x, nodes[i].y, 8, 8);
            g.setColor(black);
            //g.drawString(nodes[i].getMaxHops()+"",nodes[i].x,nodes[i].y);
        }
        
        
        for (int i = 0; i < connections.length; i++) {
            g.setColor(new Color(32452));
            int x1 = connections[i].from.x + 4;
            int y1 = connections[i].from.y + 4;
            int x2 = connections[i].to.x + 4;
            int y2 = connections[i].to.y + 4;
            
            g.drawLine(x1, y1,x2, y2);
            g.setColor(new Color(Integer.MAX_VALUE));
            if (connections[i].from.destinations.get(node1)==connections[i].to)
                g.drawLine(x1,y1,x2+((x1-x2)/2),y2+((y1-y2)/2) );
            if (connections[i].to.destinations.get(node1)==connections[i].from)
                g.drawLine(x1+((x2-x1)/2),y1+((y2-y1)/2),x2,y2);
        }
        
        g.setColor(new Color(Integer.MAX_VALUE));
        g.drawString(new String(""+network.tick),10,10);
        
    }
    
    public Dimension getPreferredSize() {
        return new Dimension(600, 600);
    }
    
    public void mouseClicked(MouseEvent e) {
        Node node = network.findClosest(new Node(e.getX(),e.getY(),new Random()));
        if (e.getButton()==MouseEvent.BUTTON1)
            node1 = node;
        else
            node2 = node;
        np.setNode(node);
    }
    
    public void mouseEntered(MouseEvent e) {
    }
    
    public void mouseExited(MouseEvent e) {
    }
    
    public void mousePressed(MouseEvent e) {
    }
    
    public void mouseReleased(MouseEvent e) {
    }
    
}

