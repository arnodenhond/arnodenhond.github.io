package Gui;

import Network.Network;
import Network.Node;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JSplitPane;

public class ViSim {
    
    ViSim(DrawArea drawArea,ButtonArea buttonArea) {
        JFrame frame = new JFrame("ViSim");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,drawArea,buttonArea);
        frame.getContentPane().add(splitPane);
        frame.setState(JFrame.MAXIMIZED_BOTH);
        frame.pack();
        frame.setVisible(true);
    }
    
    public static void main(String[] args) throws Exception{
        Random r = new Random();
        Network network = new Network(r);
        NodePanel np = new NodePanel(new Node(new Integer(0)));
        DrawArea drawArea = new DrawArea(network,np);
        ButtonArea buttonArea = new ButtonArea(drawArea,np);
        new ViSim(drawArea,buttonArea);
        for (int i = 0; i < 20000; i++) {
            while (!buttonArea.running)
                Thread.sleep(100);
            network.tick();
            //drawArea.repaint();
            drawArea.paintImmediately(0,0,drawArea.getSize().width,drawArea.getSize().height);
           /* if (r.nextInt(50)==1) {
                Node from = null;
                from = network.nodes[r.nextInt(network.nodes.length)];
                int j = r.nextInt(from.connections.values().size());
                Iterator connections = from.connections.values().iterator();
                for (int k = 0; k < j; k++)
                    connections.next();
                Connection connection = (Connection) connections.next();
                if (connection.queue.size()==0)
                    continue;
                Message message = (Message) connection.queue.get(r.nextInt(connection.queue.size()));
                //Message message = new Message(from,network.nodes[r.nextInt(network.nodes.length)],r);
                //from.receive(message,from);
                drawArea.setMessage(message);
            }*/
        }
        
    }
}


/*
        class Router {
                int x;
 
                int y;
 
                Router[] connections;
 
                Router() {
                        connections = new Router[0];
                }
 
                boolean isConnected(Router r) {
                        for (int i = 0; i < connections.length; i++)
                                if (connections[i] == r)
                                        return true;
                        return false;
                }
 
                void addConnection(Router r) {
                        Router[] newconnections = new Router[connections.length+1];
                        System.arraycopy(connections, 0, newconnections, 0,
                                        connections.length);
                        newconnections[connections.length] = r;
                        connections = newconnections;
                }
        }
 */
