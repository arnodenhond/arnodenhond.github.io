
package Gui;

import Network.Node;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.util.Iterator;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListModel;
import javax.swing.event.ListDataListener;

public class NodePanel extends JPanel {
    
    public NodePanel(Node node) {
        setNode(node);
    }
    public void setNode(final Node node) {
        LayoutManager lm = new LayoutManager() {
            public void addLayoutComponent(String name, Component comp) {
            }
            
            public void removeLayoutComponent(Component comp) {
            }
            
            public Dimension preferredLayoutSize(Container parent) {
                return new Dimension(0,0);
            }
            
            public Dimension minimumLayoutSize(Container parent) {
                return new Dimension(0,0);
            }
            
            public void layoutContainer(Container parent) {
            }};
            setLayout(lm);
            add(new JLabel(node.toString()));
            JList connections = new JList(new ListModel(){
                public int getSize() {
                    return node.connections.keySet().size();
                }
                
                public Object getElementAt(int index) {
                    Iterator iter = node.connections.keySet().iterator();
                    for (int i = 0 ; i < index; i++)
                        iter.next();
                    return iter.next();
                }
                
                public void addListDataListener(ListDataListener l) {
                }
                
                public void removeListDataListener(ListDataListener l) {
                }}
            );
            add(connections);
            
            JList generators = new JList(new ListModel(){
                public int getSize() {
                    return node.generators.size();
                }
                
                public Object getElementAt(int index) {
                    Iterator iter = node.generators.iterator();
                    for (int i = 0 ; i < index; i++)
                        iter.next();
                    return iter.next();
                }
                
                public void addListDataListener(ListDataListener l) {
                }
                
                public void removeListDataListener(ListDataListener l) {
                }}
            );
            add(generators);
            
            JList destinations = new JList(new ListModel(){
                public int getSize() {
                    return node.destinations.keySet().size();
                }
                
                public Object getElementAt(int index) {
                    Iterator iter = node.destinations.keySet().iterator();
                    for (int i = 0 ; i < index; i++)
                        iter.next();
                    return iter.next();
                }
                
                public void addListDataListener(ListDataListener l) {
                }
                
                public void removeListDataListener(ListDataListener l) {
                }}
            );
            add(destinations);
    }
    
}
