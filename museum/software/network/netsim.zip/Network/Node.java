package Network;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

public class Node {
    
    public Integer id;
    
    public int x;
    public int y;
    
    public LinkedList history = new LinkedList();
    public HashSet generators = new HashSet();
    public HashMap destinations = new HashMap();//key=final destination, value=connected node
//TODO: destination & history timeouts
    public HashMap connections = new HashMap();//key=connected node, value = connection
    public LinkedList inBufferMsg = new LinkedList();//TODO: converge buffers
    public LinkedList inBufferNode = new LinkedList();
    
    public Node(int x, int y, Random r) {
        this.x = x;
        this.y = y;
        id = new Integer(r.nextInt());//just hope its unique
    }
    
    public Node(Integer id) {
        this.id = id;
    }
    
    public void send() {
        //System.out.println("--Sending "+toString());
        Iterator i = generators.iterator();
        while (i.hasNext()) {
            Generator generator = (Generator) i.next();
            generator.tick();
        }
        i = connections.values().iterator();
        while (i.hasNext()) {
            Connection connection = (Connection) i.next();
            connection.tick();//tick calls receive on the connected node to pass the message
        }
    }
    
    public void receive(Message message, Node node) {
        //System.out.println(toString()+" RECEIVED "+message.toString()+" from "+node.toString());
        inBufferMsg.offer(message);
        inBufferNode.offer(node);
    }
    
    public void process() {
        Iterator msgIter = inBufferMsg.iterator();
        Iterator nodeIter = inBufferNode.iterator();
        while (msgIter.hasNext()) {
            Message message = (Message) msgIter.next();
            Node node = (Node) nodeIter.next();

            if (history.contains(message.id)) //dont process the same message twice
                continue;//DUPLICATE DROPPED
            history.offer(message.id);//store message id
            
            if (node!=this && node!=null)//store origin
                destinations.put(message.from,node);//Destination stored
            //TODO: destination time out
            
            if (equals(message.to)) {//delivered
                message.delivered();
                continue;//message arrived at destination
            }
            
            message.hiphop();//increase hopcount
            
            //have we ever seen a message from this message.to? which connection did it come from?
            Node to = (Node) destinations.get(message.to);
            
            if (to!=null && to.equals(node)) {//dont send it back
                destinations.remove(message.to);//BACKLOOP FIXED
                to = null;//continue
            }
            
            if (to==null) {//spam
                Iterator i = connections.values().iterator();
                while (i.hasNext()) {
                    Connection connection = (Connection) i.next();
                    if (connection.to!=node)//dont spam back to sender
                        connection.addToQueue(message.clone());
                }
            }//TODO: multicast
            else {//forward
                Connection connection = (Connection) connections.get(to);
                connection.addToQueue(message.clone());//clone is not mandatory here
            }
        }
        inBufferMsg = new LinkedList();
        inBufferNode = new LinkedList();
        while (history.size()>250)
            history.remove();//TODO: history time out
    }
    
    public void connect(Node to,int speed, int buffer, Random r) {
        //System.out.println("CONNECTING from "+toString()+ " to "+ to.toString());
        Connection connection = new Connection(this,to,speed,buffer,r);
        connections.put(to,connection);
    }
    
    public boolean isConnected(Node node) {
        return connections.containsKey(node);
    }
    
    public int getMaxHops() {
        int result = 0;
        Iterator i = connections.values().iterator();
        while (i.hasNext()) {
            Connection connection = (Connection) i.next();
            if (connection.getMaxHops()>result)
                result = connection.getMaxHops();
        }
        return result;
    }
    
    public boolean equals(Object o) {
        if (o==null)
            return false;
        if (!(o instanceof Node)) {
            System.out.println("oops! this shouldnt happen");
        }
        Node n = (Node) o;
        return id.equals(n.id);
    }
    
    public String toString() {
        return "node " + Integer.toHexString(id.intValue());
    }
    
}
