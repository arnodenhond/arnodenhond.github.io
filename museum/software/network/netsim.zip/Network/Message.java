package Network;

import java.util.Random;

public class Message {
    
    Integer hops;
    Integer id;
    Node from;
    Node to;
    Random r;
    //String data;
    
    public Message(Node from, Node to, Random r) {
        this.from = from;
        this.to = to;
        id = new Integer(r.nextInt());
        hops = new Integer(0);
        this.r = r;
    }
    
    public void hiphop() {
        hops = new Integer(hops.intValue()+1);
        //System.out.println((r.nextBoolean()?"hip":"hop"));
    }
    
    public String toString() {
        return "message id " + Integer.toHexString(id.intValue()) + " from " + from.toString() + " to " + to.toString() + " hops " + hops.toString();
    }
    
    public boolean isFrom(Node from) {
        return this.from.equals(from);
    }
    
    public Message clone() {
        Message result = new Message(from,to,r);
        result.hops = new Integer(hops.intValue());//create separate hopcounters when spamming
        result.id = id;
        return result;
    }
    
    
    public boolean equals(Object o) {
        Message m = (Message) o;
        return m.id.intValue()==id.intValue();
    }

    public void delivered() {}//call listener?
    
    public int getHops() {
        return hops.intValue();
    }
    
}


