package Network;

import java.util.Random;

public class Network {
    
    public Node[] nodes;
    public Connection[] connections;
    public int tick;
    
    public Node findClosest(Node node) {
        Node result = null;
        double length = Integer.MAX_VALUE;
        for (int i = 0; i < nodes.length; i++) {
            if ((nodes[i] != node) && (!nodes[i].isConnected(node))) {
                int xd = Math.abs(node.x - nodes[i].x);
                int yd = Math.abs(node.y - nodes[i].y);
                //pythagoras
                double tl = Math.sqrt((xd * xd) + (yd * yd));
                if (tl < length) {
                    result = nodes[i];
                    length = tl;
                }
            }
        }
        return result;
    }
    
    public Network(Random r) {
        tick=0;
        connections = new Connection[0];
        int numpoints = 900;
        nodes = new Node[numpoints];
        for (int i = 0; i < 30; i++)
            for (int j = 0; j < 30; j++) {
            int x = (i*20)+r.nextInt(15);
            int y = (j*20)+r.nextInt(15);
            nodes[(i*30)+j] = new Node(x,y,r);
            
            nodes[(i*30)+j].generators.add(new Generator(nodes[(i*30)+j],Generator.SPAM,1000,r));
            nodes[(i*30)+j].generators.add(new Generator(nodes[(i*30)+j],Generator.DIRECT,50,r));
            
            }
        //nodes[500].generators.add(new Generator(nodes[500],Generator.SPAM,100,r));
        for (int j = 0; j < 5; j++)
            for (int i = 0; i < nodes.length; i++) {
            Node closest = findClosest(nodes[i]);
            
            nodes[i].connect(closest,10,10,r);//send 1 message (both ways) every 1st ticks 
            closest.connect(nodes[i],10,10,r);//store a buffer of 2nd messages
            
            Connection[] newconnections = new Connection[connections.length+1];
            System.arraycopy(connections, 0, newconnections, 0, connections.length);
            newconnections[connections.length] = new Connection(nodes[i], closest,10,10,r);
            connections = newconnections;
            }
    }
    
    public static void main(String[] args) {
    }
    
    public void tick() {
        //System.out.println("-------------------------a. SENDING TICK "+tick);
        for (int j = 0; j < nodes.length; j++)
            nodes[j].send();//and receive
        //System.out.println("-------------------------b. PROCESSING TICK "+tick);
        for (int j = 0; j < nodes.length; j++)
            nodes[j].process();//add new messages to each connections queue
        tick++;
    }
    
}
