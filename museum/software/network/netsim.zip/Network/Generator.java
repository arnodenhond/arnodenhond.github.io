package Network;

import java.util.Iterator;
import java.util.Random;

public class Generator {
    
    Node node; //the node on which this generator inserts its messages
    boolean spam; //or send the message to a node in the destinations list
    Random r;
    int speed;
    static boolean SPAM=true;
    static boolean DIRECT=false;
    int tick;
    
    public Generator(Node node, boolean spam, int speed, Random r) {
        this.node = node;
        this.spam = spam;
        this.speed = speed;
        this.r = r;
        tick=r.nextInt(speed);
    }
    
    public void tick() {
        if (tick<speed) {
            tick++;
            return;
        }
        tick=0;
        //System.out.println("TICK "+toString());
        Message message;
        if (spam==DIRECT) {
            if (node.destinations.size()==0) {
                //System.out.println(toString()+" could not generate a message");
                return;
            }
            int i = r.nextInt(node.destinations.keySet().size());
            Node to = null;
            Iterator iter = node.destinations.keySet().iterator();
            for (int j = 0; j < i; j++)
                iter.next();
            to = (Node) iter.next();
            message = new Message(node,to,r);
        } else {
            message = new Message(node,null,r);
        }
        node.receive(message,node);
    }
    
    public String toString() {
        return "generator on " + node.toString() + (spam?" sending spamming":" sending directed");
    }
    
}
