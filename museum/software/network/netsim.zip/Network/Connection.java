package Network;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

public class Connection {
    
    public Node from;
    public Node to;
    public LinkedList queue = new LinkedList();
    int speed;
    int tick;
    int buffer;
    
    public Connection(Node from, Node to, int speed,int buffer, Random r) {
        this.from = from;
        this.to = to;
        this.speed = speed;
        this.buffer=buffer;
        tick=r.nextInt(speed);
    }
    
    
    public int getMaxHops() {
        return getHighest().hops;
    }
    
    private Message getHighest() {
            Message highest = new Message(null,null, new Random());//dummy message with hopcount=0
            Iterator i = queue.iterator();
            while (i.hasNext()) {
                Message m = (Message) i.next();
                if (m.hops.intValue()>highest.hops.intValue())
                    highest = m;
            }
            return highest;
    }
    
    public void addToQueue(Message message) {
        if (queue.size()>buffer) {//remove the message with the highest hopcount
            Message highest = getHighest();
            if (highest.hops.intValue()>message.hops.intValue()) {
                //System.out.println(toString() + " REMOVED "+highest.toString()+" ADDED "+message.toString());
                queue.remove(highest);
                queue.offer(message);
            } 
            //else System.out.println(toString() +"HOPCOUNT TOO HIGH " + message.toString());
        } else { //buffer was not full!
            //System.out.println(toString()+ " ADDED " + message.toString());
            queue.offer(message);
        }
    }
    
    public void tick() {
        if (tick<speed) {
            tick++;
            return;
        }
        tick=0;

        //System.out.println("TICK "+toString());
        Message message = (Message) queue.poll();
        if (message==null)
            return;
        //System.out.println("connection to "+to.id.toString()+" sending "+message.toString());
        to.receive(message,from);
    }
    
    public String toString() {
        return "connection from " + Integer.toHexString(from.id.intValue()) + " to " + Integer.toHexString(to.id.intValue());
    }
    
}


