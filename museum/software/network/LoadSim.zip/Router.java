import java.util.*;

public class Router {
    
    ArrayList connections;
    DestList destinations;
    History history;
    
    Timer connectionTimer;
    int totalreceived;
    int desttimeout;//how long to remember a destination
    
    public Router() {
        desttimeout=100*1000;//1000sec~15min
        connections = new ArrayList();
        destinations = new DestList(desttimeout);
        history = new History(600000);//10 minutes
        connectionTimer = new Timer();
        totalreceived=0;
        //        System.out.println("router created");
    }
    
    public void addConnection(Router router,int speed, int buffer) {
        Connection connection = new Connection(router,this,buffer);
        connectionTimer.scheduleAtFixedRate(connection,new Random().nextInt(speed),speed);
        connections.add(connection);
        //        System.out.println("router connected");
    }
    
    private Connection findConnection(Router router) { //used icw thisrouter to know who sent a msg
        for (int i = 0; i < connections.size(); i++) {
            Connection connection = (Connection) connections.get(i);
            if (connection.router == router)
                return connection;
        }
        return null;
    }
    
    public void process(Message message, Router sender) {
        //        System.out.println("processing message");
        if (message==null) {
            System.out.println("***NULL MESSAGE!***");
            System.out.println("***NULL MESSAGE!***");
            System.exit(0);
        }
        
        if (history.containsMessage(message)) {//rule 2
            //reset the timertask to delete this message from history
            //            System.out.println("duplicate message received, ignoring");
            return;
        }
        history.addMessage(message);//rule 2
        if (message.from!=this)
            destinations.addDestination(message.from, findConnection(sender));
        if (message.to==this) {
            totalreceived++;
            //            System.out.println("message delivered");
            return;
        }
        Destination d = destinations.findDestination(message.to);
        if ((d!=null) && (d.destConnection==findConnection(sender))) { //rule 4
            destinations.delDestination(d);
            System.out.println("backloop detected!");
            d=null;
        }
        Message newMessage = new Message(message.id,message.from,message.to,message.hops+1);
        if (d!=null) { //rule 3
            //System.out.println("destination known");
            //System.out.println("known - highest hopcount "+d.destConnection.buffer.getHighest());
            d.destConnection.buffer.addMessage(newMessage);//rule 6
        }
        else {
            //System.out.println("spamming to all");
            for (int i = 0; i < connections.size(); i++) { //rule 1 and !3
                Connection connection = (Connection) connections.get(i);
                if (connection!=findConnection(sender)) {//dont send it back
                    connection.buffer.addMessage(newMessage);//rule 6
                    //  System.out.println("spam - highest hopcount "+connection.buffer.getHighest());
                }
            }
        }
    }
}
