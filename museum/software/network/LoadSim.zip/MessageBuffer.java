import java.util.*;

public class MessageBuffer extends ArrayList {
    
    int maxsize;
    boolean busy;
    
    public MessageBuffer(int maxsize) {
        this.maxsize = maxsize;
        busy=false;
    }
    
    synchronized int getHighest() {
/*        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;*/
        int result = 0;
        //System.out.print("bufhops: ");
        for (int i = 0; i < size(); i++) {
            Message message = (Message) get(i);
            //System.out.print(message.hops+" ");
            if (message.hops>result)
                result = message.hops;
        }
        //System.out.println("");
        /*busy=false;
        notifyAll();*/
        return result;
    }
    
    synchronized Message getMessage() {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        
        if (size()>0) {
            Message message = (Message) get(0);
            remove(0);
            busy=false;
            notifyAll();
            return message;
        }
        else {
            busy=false;
            notifyAll();
            return null;
        }
    }
    
    synchronized void addMessage(Message message) {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        if (size()>maxsize) {
            Message highest = (Message) get(0);
            //            System.out.print("BUFHOPS: "+highest.hops+" ");
            for (int i = 1; i < size(); i++) {
                Message current = (Message) get(i);
                //System.out.print(current.hops+" ");
                if (current.hops>highest.hops)
                    highest=current;
            }
            //          System.out.println("highest: "+highest.hops);
            remove(highest);
        }
        add(message);
        busy=false;
        notifyAll();
    }
    
}
