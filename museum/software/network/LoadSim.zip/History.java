import java.util.*;

public class History extends ArrayList {
    
    Timer removeTimer;
    boolean busy;
    
    public History(int time) {
        //removeTimer = new Timer();
    }
    
    synchronized public void addMessage(Message message) {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        //crate timertask to remove it
        //add timertask to removeTimer
        add(message);
        if (size()>1000)
            remove(0);
        busy=false;
        notifyAll();
    }
    
    synchronized public boolean containsMessage(Message message) {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        
        for (int i = 0; i < size(); i++) {
            Message m = (Message) get(i);
            if ((m.id == message.id) && (m.to == message.to)) {
                //reset timertask for this message
                busy=false;
                notifyAll();
                return true;
            }
        }
        busy=false;
        notifyAll();
        return false;
    }
}
