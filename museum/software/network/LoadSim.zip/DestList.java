import java.util.*;

public class DestList extends ArrayList {
    
    int desttimeout;
    boolean busy;
    Timer destinationTimer;
    
    public DestList(int desttimeout) {
        busy=false;
        this.desttimeout=desttimeout;
        destinationTimer = new Timer();
    }
    
    synchronized Destination findDestination(Router destRouter) {//used when deciding where to send 2
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        for (int i = 0; i < size(); i++) {
            Destination d = (Destination) get(i);
            if (d.destRouter==destRouter) {
                busy=false;
                notifyAll();
                return d;
            }
        }
        busy=false;
        notifyAll();
        return null;
    }
    
    synchronized Destination getDestination(int d) {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        Destination result = (Destination) get(d);
        busy=false;
        notifyAll();
        return result;
    }
    
    synchronized void delDestination(Destination d) {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        d.cancel();//make it stop
        remove(d);//delete it
        busy=false;
        notifyAll();
        
    }
    
    synchronized int destSize() {
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        int result=size();
        busy=false;
        notifyAll();
        return result;
    }
    
    synchronized void addDestination(Router destRouter, Connection destConnection) {//store it 4 da future
        while (busy)
            try {
                wait();
            } catch (InterruptedException e) { }
        busy=true;
        for (int i = 0; i < size(); i++) {
            Destination d = (Destination) get(i);
            if (d.destRouter==destRouter) {
                if (d.lastmessage!=0) { // never change permanent routes
                    d.destConnection = destConnection;
                    //update timer thing
                    d.cancel();
                    remove(d);
                    Destination dnew = new Destination(d.destRouter,d.destConnection, this);
                    add(dnew);
                    destinationTimer.schedule(dnew, desttimeout);//1000sec
                    //                    System.out.println("destination updated");
                }
                busy=false;
                notifyAll();
                return;
            }
        }
        Destination d = new Destination(destRouter, destConnection,this);
        add(d);
        destinationTimer.schedule(d, desttimeout);//1000sec
        //        System.out.println("destination added - new size:"+destinations.size());
        busy=false;
        notifyAll();
    }
    
}
