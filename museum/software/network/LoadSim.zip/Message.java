
public class Message {

    int id;
    
    Router from;
    
    Router to;
    
    int hops;
    
    //boolean outofrange;

    public Message() {
    }
    
    public Message(int id, Router from, Router to, int hops) {
        this.id = id;
        this.from=from;
        this.to=to;
        this.hops=hops;
    }
    
}
