//todo: timers for history items autodestruct
//todo: make parameter in router constructor for destination timeout (router.desttimeout)
//todo: generate triangular (hexagonal) continuous grid just for fun

import java.util.*;
import java.lang.*;
import java.io.*;

public class LoadSim {
    
    public LoadSim() {

//createNetwork(numberOfNodes,numberOfConnections,speedPerConnection,bufferSize);
//numberofnodes^2 for gridshaped network
//numberofconnections unused for gridshaped network (only for random network)
//speedperconnection*2 for total bandwidth
//buffersize * speed * hops = minimal safe destination timeout (router.desttimeout)
//example: 10,2,1000,10 = 100 nodes, 1 msg/sec each connection (2/sec total), buffersize 10

        System.out.println("creating network");
        routers = createNetwork(10,2,1000,10);//400=2.5/sec 

//startGenerator(millisBetweenDirectedMessages,millisBetweenReversePing);
//directedmessage = message to somebody in senders destination list
//reverseping = message to nonexistant recepiant
//example: 10,1000 in case of 100 nodes = 1 directed_msg/sec each node, 0,001 reverseping_msg/sec each node

        System.out.println("starting generator");
        generator = startGenerator(10,100);

	//some testing results:
        //10,2,1000,10 -- 999999,100 ==> H4/5 D50 
        //10,2,1000,10 -- 10,100 ==> H3 D25
        //10,2,1000,10 -- 999999,50 --> H3/4 D30
    }
    
    static ArrayList routers;
    static Timer generator;
    
    public static void main(String[] args) throws Exception {
        LoadSim sim = new LoadSim();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String in = new String();
        while (!in.equalsIgnoreCase("QUIT")) {
            in = br.readLine();
        }
        generator.cancel();
        int totalhops = 0;
        int totalconnections=0;
        for (int i = 0; i < routers.size(); i++) {
            Router r = (Router) routers.get(i);
            for (int j = 0; j < r.connections.size(); j++) {
                Connection c = (Connection) r.connections.get(j);
                if (c.buffer.size()<c.buffer.maxsize)
                    continue;
                totalhops+=c.buffer.getHighest();
                totalconnections++;
            }
        }
        try {
            System.out.println("bufs:"+totalconnections+" - avg:"+(totalhops/totalconnections));
        } catch (Exception e) {System.out.println("bufs:0 - avg: 0 cons");}
        System.exit(0);
    }
    
    private ArrayList createNetwork(int routers, int connections, int speed, int buffer) {
        ArrayList result = new ArrayList();
        /*ring shaped network
        for (int i = 0; i < routers; i++)
            result.add(new Router());
        for (int i = 0; i < result.size()-1; i++) {//connect each to the next
            Router r1 = (Router) result.get(i);
            Router r2 = (Router) result.get(i+1);
            r1.addConnection(r2,speed,buffer);
            r2.addConnection(r1,speed,buffer);
        }
        Router r1 = (Router) result.get(0);//connect first and last
        Router r2 = (Router) result.get(result.size()-1);
        r1.addConnection(r2,speed,buffer);
        r2.addConnection(r1,speed,buffer);
         */
        //---------
        Router[][] grid = new Router[routers][routers];
        for (int x = 0; x < routers; x++)
            for (int y = 0; y < routers; y++) {
                grid[x][y]=new Router();
                result.add(grid[x][y]);
            }
        for (int x = 0; x < routers; x++)
            for (int y = 0; y < routers; y++) {//continuous square grid
                //System.out.println(x+","+y+" <--> "+((x+1)<routers?x+1:0)+","+y);
                grid[x][y].addConnection(grid[((x+1)<routers?x+1:0)][y],speed,buffer);
                grid[((x+1)<routers?x+1:0)][y].addConnection(grid[x][y],speed,buffer);
                //System.out.println(x+","+y+" <--> "+x+","+((y+1)<routers?y+1:0));
                grid[x][y].addConnection(grid[x][((y+1)<routers?y+1:0)],speed,buffer);
                grid[x][((y+1)<routers?y+1:0)].addConnection(grid[x][y],speed,buffer);
//connect diagonally aswell:
//System.out.println(x+","+y+" <--> "+((x+1)<routers?x+1:0)+","+((y+1)<routers?y+1:0));
//grid[x][y].addConnection(grid[((x+1)<routers?x+1:0)][((y+1)<routers?y+1:0)],speed,buffer);
//grid[((x+1)<routers?x+1:0)][((y+1)<routers?y+1:0)].addConnection(grid[x][y]),speed,buffer);
//System.out.println(x+","+((y+1)<routers?y+1:0)+" <--> "+((x+1)<routers?x+1:0)+","+y);
//grid[x][((y+1)<routers?y+1:0)].addConnection(grid[((x+1)<routers?x+1:0)][y],speed,buffer);
//grid[((x+1)<routers?x+1:0)][y].addConnection(grid[x][((y+1)<routers?y+1:0)],speed,buffer);
            }

        /*random network -- 2 completely seperate networks is possible!
        Random r = new Random();
        for (int i = 0; i < routers; i++)
            result.add(new Router());
        for (int i = 0; i < result.size(); i++)
            for (int j = 0; j < connections; j++) {
                int k = 0;
                do {
                    k = r.nextInt(result.size());
                } while (k!=i);//dont connect to itself
                Router r1 = (Router) result.get(i);
                Router r2 = (Router) result.get(k);
                r1.addConnection(r2,speed,buffer);
                r2.addConnection(r1,speed,buffer);
            }*/
        return result;
    }
    
    Timer startGenerator(int destspeed, int oorspeed) {
        Timer messageGenerator = new Timer();
        messageGenerator.scheduleAtFixedRate(new TimerTask() {
            Random r = new Random();
            public void run() {
                Message message = new Message();
                Router from = (Router) routers.get(r.nextInt(routers.size()));
                message.from = from;
                if (from.destinations.destSize()==0)
                    return;//nobody to send to
                message.id = r.nextInt();
                Destination destination = from.destinations.getDestination(r.nextInt(from.destinations.destSize()));
                message.to = destination.destRouter;
                message.hops=0;
                //System.out.println("known destination message generated");
                from.process(message,from);
                //System.gc();
            }
        }, destspeed, destspeed);
        
        messageGenerator.scheduleAtFixedRate(new TimerTask() {
            Random r = new Random();
            public void run() {
                Message message = new Message();
                message.id = r.nextInt();
                Router from = (Router) routers.get(r.nextInt(routers.size()));
                message.from = from;
                message.to = null;//or null
                message.hops=0;
                //System.out.println("out of range message generated");
                from.process(message,from);
                //System.gc();
            }
        }, oorspeed, oorspeed);
        return messageGenerator;
    }
    
}
