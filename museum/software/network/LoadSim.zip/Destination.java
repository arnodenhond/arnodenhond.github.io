import java.util.*;

public class Destination extends TimerTask {
    
    Router destRouter;
    Connection destConnection;
    long lastmessage;
    DestList list;

    public Destination(Router destRouter, Connection destConnection, DestList list) {
        this.destRouter = destRouter;
        this.destConnection = destConnection;
        lastmessage = System.currentTimeMillis();
        this.list = list;
    }
    
    public void run() {
        list.delDestination(this);
    }

}
