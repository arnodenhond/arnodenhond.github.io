import java.util.*;

public class Connection extends TimerTask {
    
    Router router;
    Router thisrouter;
    MessageBuffer buffer;
    
    public Connection(Router router, Router thisrouter, int maxbuffer) {
        this.router = router;
        this.thisrouter = thisrouter;
        buffer = new MessageBuffer(maxbuffer);
    }
    
    public void run() {
        /*Random r = new Random();
        int yields = r.nextInt(10);
        try {
            for (int i = 0; i < yields; i++)
                if (r.nextBoolean())
                    Thread.yield();
                else
                    Thread.sleep(r.nextInt(10));
        }catch (Exception e) {}*/
        Message message;
        do {
            message = buffer.getMessage();
            if (message==null)
                break;
        } while (router.history.containsMessage(message));
        if (message!=null) {
            router.process(message,thisrouter);
            System.out.println("B"+buffer.size()+" H"+buffer.getHighest()+" D"+thisrouter.destinations.destSize());
        }
        System.gc();
    }
    
}
