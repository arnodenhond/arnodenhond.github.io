interface Connection {
    
    Message getMessage();
    
    void putMessage(Message m);
    
    boolean hasMessage();
    
    boolean isAlive();
    
    String getConnectionName();
    
}
