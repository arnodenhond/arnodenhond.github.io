class Destination {
    
    long destination;
    Connection connection;
    long lastmessage;
    
    public Destination() {
    }
    
}
