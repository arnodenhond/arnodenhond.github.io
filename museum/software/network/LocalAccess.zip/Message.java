public class Message {
    
    long id;
    
    long[] to;
    
    long from;
    
    String content;
    
    public Message() {
    }
    
}
