import java.lang.*;
import java.util.*;

class Router extends Thread {
    
    ArrayList connections;
    ArrayList history;
    ArrayList destinations;
    ArrayList clients;
    
    public Router() {
        connections = new ArrayList();
        history = new ArrayList();
        destinations = new ArrayList();
        clients = new ArrayList();
    }
    
    boolean findid(long id) {
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.get(i);
            if (h.id==id)
                return true;
        }
        return false;
    }
    
    boolean findidto(long id,long to) {
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.get(i);
            if (h.id==id)
                for (int j = 0; j < h.to.length; j++)
                    if (h.to[j]==to)
                        return true;
        }
        return false;
    }
    
    void addid(long id) {
        History h = new History();
        h.id=id;
        h.to = new long[0];
        history.add(h);
        if (history.size()>1000) //don't let it grow too large
            history.remove(0);
    }
    
    void addidto(long id, long to) {
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.get(i);
            if (h.id==id) {
                long[] newto = new long[h.to.length+1];
                System.arraycopy(h.to, 0, newto, 0, h.to.length);
                newto[newto.length-1]=to;
                h.to=newto;
                return;
            }
        }
    }
    
    void addupdatedestination(long from, Connection c) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==from) {
                d.connection = c;
                d.lastmessage=System.currentTimeMillis();
                return;
            }
        }
        Destination d = new Destination();
        d.destination=from;
        d.connection=c;
        d.lastmessage=System.currentTimeMillis();
        destinations.add(d);
    }
    
    void delDestination(long destination) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==destination) {
                destinations.remove(i);
                return;
            }
        }
    }
    
    void delDestination(Connection c) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.connection==c) {
                destinations.remove(d);
                i--;
            }
        }
    }
    
    
    Connection findDestination(long destination) {
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.get(i);
            if (d.destination==destination)
                return d.connection;
        }
        return null;
    }
    
    long[] addto(long[] to,long newto) {
        long[] result = new long[to.length+1];
        System.arraycopy(to, 0, result, 0, to.length);
        result[result.length-1] = newto;
        return result;
    }
    
    void deliver(Message m)  {
        System.out.println("message delivered");
        System.out.println("id: "+m.id);
        //        System.out.println("to: "+localaddress);
        System.out.println("from: "+m.from);
        System.out.println("content: "+m.content);
    }
    
    public void run() {
        System.out.println("router running");
        try{
            while (true) {
                //check for outdated destinations
                for (int i = 0; i < destinations.size(); i++) {
                    Destination d = (Destination) destinations.get(i);
                    if (d.lastmessage<System.currentTimeMillis()-600000) { //del dest after 10 min
                        destinations.remove(d);
                        i--;
                    }
                }
                
                sleep(100);
                //check if all clients/servers are still alive
                for (int i =0; i < clients.size(); i++) {
                    Client c = (Client) clients.get(i);
                    if (!c.isAlive()) {
                        clients.remove(c);
                        System.out.println(c.getConnectionName()+" removed ");
                        i--;
                    }
                }
                for (int i = 0; i < connections.size(); i++) {
                    Connection c = (Connection) connections.get(i);
                    if (!c.isAlive()) {
                        connections.remove(c);
                        delDestination(c);
                        System.out.println(c.getConnectionName()+" removed");
                        i--;
                    }
                }
                
                //get messages from clients
                for (int i = 0; i < clients.size(); i++) {
                    Client c = (Client) clients.get(i);
                    if (c.hasMessage()) {
                        Message m = c.getMessage();
                        Random r = new Random();
                        do {
                            m.id = r.nextLong();
                        } while (findid(m.id));
                        System.out.println("client "+c.getConnectionName()+" has sent message "+m.id);
                        send(m);
                    }
                }
                for (int i = 0; i < connections.size(); i++) {
                    //wait(100);
                    Connection c = (Connection) connections.get(i);
                    if (c.hasMessage()) {
                        Message m = c.getMessage();
                        System.out.println("server "+c.getConnectionName()+" has sent message "+m.id);
                        //check history for id = if not found: add it & add/update "from" in destinations
                        if (!findid(m.id)) {
                            System.out.println("never seen this message before");
                            addid(m.id);
                            addupdatedestination(m.from, c);
                        }
                        else
                            System.out.println("message id known, checking receipiants");
                        //split message into all "to"'s and "connection"'s
                        Message[] mout = new Message[connections.size()];
                        for (int j = 0; j < mout.length; j++) {
                            mout[j] = new Message();
                            mout[j].from=m.from;
                            mout[j].id=m.id;
                            mout[j].to=new long[0];
                            mout[j].content=m.content;
                        }
                        for (int j = 0; j < m.to.length; j++) {
                            //check history for id and to - if not found: add it
                            if (!findidto(m.id,m.to[j])) {
                                System.out.println("message has not yet been sent to "+m.to[j]);
                                addidto(m.id,m.to[j]);
                                //check to==localaddress
                                //--------------------------------
                                boolean local=false;
                                for (int k = 0; k < clients.size(); k++) {
                                    Client client = (Client) clients.get(k);
                                    if (client.address==m.to[j]) {
                                        client.putMessage(m);
                                        System.out.println("delivered to "+client.getConnectionName());
                                        local=true;
                                        break;
                                    }
                                }
                                if (local)
                                    continue;
/*now supports multiple clients if (m.to[j]==localaddress) {
                                    deliver(m);
                                    continue;
                                }*/
                                //check destinations - if not found: forward to all (except sender)
                                Connection c2 = findDestination(m.to[j]);
                                if (c2==null) {
                                    System.out.println("unknown destination forwarding to all");
                                    for (int k = 0; k < mout.length; k++) {
                                        if (k != i)//don't send it back to the sender
                                            mout[k].to=addto(mout[k].to,m.to[j]);
                                    }
                                }
                                else {
                                    System.out.print("destination known ");
                                    //else make sure not forwarding back to sender - ifso delete destination & forward to all
                                    if (c2==c) {
                                        System.out.println("backloop detected, forwarding to all");
                                        delDestination(m.to[j]);
                                        for (int k = 0; k < mout.length; k++) {
                                            if (k != i)//don't send it back to the sender
                                                mout[k].to=addto(mout[k].to,m.to[j]);
                                        }
                                    }
                                    else {
                                        System.out.println("forwarding to "+c2.getConnectionName());
                                        //add current "to" to message for proper connection
                                        mout[connections.indexOf(c2)].to=addto(mout[connections.indexOf(c2)].to,m.to[j]);
                                    }
                                }
                            }
                        }
                        //send message to connection where to>0
                        for (int j = 0; j < mout.length; j++)
                            if (mout[j].to.length>0) {
                                Connection cout = (Connection) connections.get(j);
                                cout.putMessage(mout[j]);
                            }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("router:"+e.toString());
            e.printStackTrace();
        }
    }
    
    //used for sending locally generated messages
    public void send(Message m) {
        System.out.println("sending "+m.id);
        addid(m.id);
        Message[] mout = new Message[connections.size()];
        for (int j = 0; j < mout.length; j++) {
            mout[j] = new Message();
            mout[j].from=m.from;
            mout[j].id=m.id;
            mout[j].to=new long[0];
            mout[j].content=m.content;
        }
        for (int i = 0; i < m.to.length; i++) {
            addidto(m.id, m.to[i]);
            boolean local=false;
            for (int k = 0; k < clients.size(); k++) {
                Client client = (Client) clients.get(k);
                if (client.address==m.to[i]) {
                    client.putMessage(m);
                    System.out.println("delivered to "+client.getConnectionName());
                    local=true;
                    break;
                }
            }
            if (local)
                continue;
            Connection c2 = findDestination(m.to[i]);
            if (c2==null) {
                System.out.println("unknown destination forwarding to all");
                for (int k = 0; k < mout.length; k++)
                    mout[k].to=addto(mout[k].to,m.to[i]);
            }
            else {
                mout[connections.indexOf(c2)].to=addto(mout[connections.indexOf(c2)].to,m.to[i]);
                System.out.println("destination known forwarding to "+c2.getConnectionName());
            }
        }
        for (int j = 0; j < mout.length; j++)
            if (mout[j].to.length>0) {
                Connection cout = (Connection) connections.get(j);
                cout.putMessage(mout[j]);
            }
    }
    
    public void addConnection(Connection c) {
        connections.add(c);
        System.out.println("router: new server added");
    }
    
    public void addClient(Client c) {
        clients.add(c);
        System.out.println("router: new client added");
    }
}

//check history for id = if not found: add it & add/update "from" in destinations
//split message into all "to"'s and "connection"'s
//check history for id and to - if not found: add it
//check to==localaddress
//check destinations - if not found: forward to all (except sender)
//else make sure not forwarding back to sender - ifso delete destination & forward to all
//add current "to" to message for proper connection
//send message to connection where to>0
