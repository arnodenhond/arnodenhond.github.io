import java.net.*;
import java.io.*;

public class SocketConnection extends Thread implements Connection {
    
    Socket socket;
    Message message;
    DataOutputStream dos;
    DataInputStream dis;
    boolean handshake;
    
    public SocketConnection(Socket s) throws Exception {
        socket = s;
        message = null;
        handshake=false;
        dos = new DataOutputStream(s.getOutputStream());
        dis = new DataInputStream(s.getInputStream());
        dos.writeUTF("LocalAccess v1.0 server");
        String str = dis.readUTF();
        if (str.equalsIgnoreCase("LocalAccess v1.0 server")) {
            System.out.println("SocketConnection connected");
            handshake=true;
        }
    }
    
    public void run() {
        try {
            if (handshake)
                while (true) {
                    while (message!=null) sleep(100);
                    Message m = new Message();
                    m.id=dis.readLong();
                    m.to = new long[dis.readInt()];
                    for (int i = 0; i < m.to.length; i++)
                        m.to[i]=dis.readLong();
                    m.from=dis.readLong();
                    m.content=dis.readUTF();
                    message=m;
                }
        } catch (Exception e) {
            System.out.println("socketconnection.run:"+e.toString());
        }
    }
    
    public Message getMessage() {
        Message m = message;
        message=null;
        return m;
    }
    
    public void putMessage(Message m) {
        try {
            dos.writeLong(m.id);
            dos.writeInt(m.to.length);
            for (int i = 0; i < m.to.length; i++)
                dos.writeLong(m.to[i]);
            dos.writeLong(m.from);
            dos.writeUTF(m.content);
        } catch (Exception e) {
            System.out.println("putmessage:"+e.toString());
        }
    }
    
    public boolean hasMessage() {
        return (message!=null);
    }
    
    public String getConnectionName() {
        return socket.getInetAddress().toString()+" server";
    }
    
}
