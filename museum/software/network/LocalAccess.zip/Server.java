import java.net.*;

class Server extends Thread {
    
    ServerSocket ss;
    Router router;
    
    public Server(int port, Router router) throws Exception {
        ss = new ServerSocket(port);
        this.router = router;
        System.out.println("waiting for servers on port "+port);
    }
    
    public void run() {
        try {
            while (true) {
                Socket s = ss.accept();
                SocketConnection sc = new SocketConnection(s);
                System.out.println("new server connected from"+sc.getConnectionName());
                sc.start();
                router.addConnection(sc);
            }
        } catch (Exception e) {
            System.out.println("server:"+e.toString());
        }
    }
    
}
