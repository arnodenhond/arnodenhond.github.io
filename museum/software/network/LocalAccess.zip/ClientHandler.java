import java.net.*;

public class ClientHandler extends Thread {

    ServerSocket ss;
    Router router;
    
    public ClientHandler(int port, Router router) throws Exception {
        ss = new ServerSocket(port);
        this.router = router;        
        System.out.println("waiting for clients on port "+port);
    }

    public void run() {
        try {
            while (true) {
                Socket s = ss.accept();
                Client client = new Client(s);
                System.out.println("new client connected from "+client.getConnectionName());
                client.start();
                router.addClient(client);
            }
        } catch (Exception e) {
            System.out.println("client:"+e.toString());
        }
    }
}
