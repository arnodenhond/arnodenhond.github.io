import java.net.*;
import java.io.*;

public class Client extends Thread {
    
    Socket socket;
    Message message;
    DataOutputStream dos;
    DataInputStream dis;
    long address;
    boolean handshake;
    
    public Client(Socket s) throws Exception {
        socket = s;
        message = null;
        handshake=false;
        dos = new DataOutputStream(s.getOutputStream());
        dis = new DataInputStream(s.getInputStream());
        dos.writeUTF("LocalAccess v1.0 client");
        String str = dis.readUTF();
        address=dis.readLong();
        if (str.equalsIgnoreCase("LocalAccess v1.0 client")) {
            System.out.println("Client "+ address +" connected");
            handshake=true;
        }
    }
    
    public void run() {
        try {
            if (handshake)
                while (true) {
                    sleep(100);
                    while (message!=null) ;
                    Message m = new Message();
//auto generate     m.id=dis.readLong();
                    m.to = new long[dis.readInt()];
                    for (int i = 0; i < m.to.length; i++)
                        m.to[i]=dis.readLong();
                    m.from=address;
                    m.content=dis.readUTF();
                    message=m;
                }
        } catch (Exception e) {
            System.out.println("socketconnection.run:"+e.toString());
        }
    }
    
    public Message getMessage() {
        Message m = message;
        message=null;
        return m;
    }
    
    public void putMessage(Message m) {
        try {
            dos.writeLong(m.id);
            //            dos.writeInt(m.to.length);
            //            for (int i = 0; i < m.to.length; i++)
            //                dos.writeLong(m.to[i]);
            dos.writeLong(m.from);
            dos.writeUTF(m.content);
        } catch (Exception e) {
            System.out.println("putmessage:"+e.toString());
        }
    }
    
    public boolean hasMessage() {
        return (message!=null);
    }
    
    public String getConnectionName() {
        return socket.getInetAddress().toString()+" client";
    }
    
}