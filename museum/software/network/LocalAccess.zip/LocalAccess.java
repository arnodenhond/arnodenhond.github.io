/*todo:
 *ignore messages from where from==to
 *after receiving mesage header check if its not in history, then transfer message content
 *allow static destinations which dont expire
 *make buffers for incoming/outgoing messages (a router for each incoming connection?)
 */

import java.io.*;
import java.net.*;
import java.util.*;

class LocalAccess {
    
    public static void main(String[] args) throws Exception {
        if (args.length<2) {
            System.out.println("usage: parameters <server port number> <client�port number>");
            System.out.println("example: LocalAccess 88 36");
            System.exit(0);
        }
        Router router = new Router();
        router.start();
        Server server = new Server(Integer.parseInt(args[0]),router);
        server.start();
        ClientHandler clients = new ClientHandler(Integer.parseInt(args[1]),router);
        clients.start();
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String in = new String();
        while (!in.equalsIgnoreCase("QUIT")) {
            in = br.readLine();
            try {
                if (in.startsWith("?")) {
                    System.out.println("--commands and usage");
                    System.out.println("OPEN <hostname> <portnumber>");
                    System.out.println("SEND <id> <from> <to> (or to,to,to) <message_content>");
                    System.out.println("DEST <connection_number> <to/from>");
                    System.out.println("INFO");
                }
                if (in.startsWith("open")) { // format: HOSTNAME PORT
                    StringTokenizer st = new StringTokenizer(in," ");
                    st.nextToken();
                    SocketConnection sc = new SocketConnection(new Socket(st.nextToken(),Integer.parseInt(st.nextToken())));
                    sc.start();
                    router.addConnection(sc);
                }
                if (in.startsWith("send")) { //format: ID FROM TO(,TO,TO) MESSAGE_CONTENT
                    StringTokenizer st = new StringTokenizer(in," ");
                    st.nextToken();
                    Message m = new Message();
                    m.id = Long.parseLong(st.nextToken());
                    m.from = Long.parseLong(st.nextToken());
                    StringTokenizer st2 = new StringTokenizer(st.nextToken(),",");
                    m.to = new long[st2.countTokens()];
                    for (int i= 0; i < m.to.length; i++)
                        m.to[i]=Long.parseLong(st2.nextToken());
                    m.content=st.nextToken();
                    router.send(m);
                }
                if (in.startsWith("dest")) { // format: CONNECTION TO
                    StringTokenizer st = new StringTokenizer(in," ");
                    st.nextToken();
                    Connection c = (Connection) router.connections.get(Integer.parseInt(st.nextToken()));
                    router.addupdatedestination(Long.parseLong(st.nextToken()),c);
                }
                if (in.startsWith("info")) {
                    System.out.println("--connections");
                    for (int i = 0; i < router.connections.size(); i++) {
                        Connection c = (Connection) router.connections.get(i);
                        System.out.println(i+" : "+c.getConnectionName());
                    }
                    System.out.println("--destinations");
                    for (int i = 0; i < router.destinations.size(); i++) {
                        Destination d = (Destination) router.destinations.get(i);
                        System.out.println(d.destination+"\t"+d.connection.getConnectionName()+" ("+router.connections.indexOf(d.connection)+")");
                    }
                }
            } catch (Exception e) {
                System.out.println(e.toString());
            }
        }
    }
    
}
