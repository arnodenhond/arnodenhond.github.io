import java.io.*;
import java.util.*;
import java.net.*;
import java.lang.*;

public class LAClient {
    
    
    public static void main(String[] args) throws Exception{
        if (args.length<3) {
            System.out.println("parameters: <your id> <server hostname> <server portnumber>");
        }
        int address = Integer.parseInt(args[0]);
        Socket socket = new Socket(args[1],Integer.parseInt(args[2]));
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("LocalAccess v1.0 client");
        String string = dis.readUTF();
        if (string.equalsIgnoreCase("LocalAccess v1.0 client"))
            System.out.println("CONNECTED");
        dos.writeLong(address);
        LAClientThread thread = new LAClientThread(dis);
        thread.start();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
           String in = br.readLine();
           StringTokenizer st = new StringTokenizer(in," ");
//           dos.writeLong(Long.parseLong(st.nextToken()));
           StringTokenizer st2 = new StringTokenizer(st.nextToken(),",");
           dos.writeInt(st2.countTokens());
           while (st2.hasMoreTokens())
            dos.writeLong(Long.parseLong(st2.nextToken()));
           dos.writeUTF(st.nextToken());
        }
    }
    
}
