class History {

    long id;
    long[] to;
    
    public History() {
    }
    
}
