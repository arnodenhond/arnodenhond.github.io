import java.io.*;

public class LAClientThread extends Thread {
    
    DataInputStream dis;
    
    public LAClientThread(DataInputStream dis) {
        this.dis=dis;
    }
    
    public void run() {
        try {
        while (true) {
            sleep(100);
            long id = dis.readLong();
            long from = dis.readLong();
            String content = dis.readUTF();
            System.out.println("#"+id+" from:"+from+" : "+content);
        }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
