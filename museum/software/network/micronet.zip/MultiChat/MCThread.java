
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.*;
import java.io.*;

public class MCThread  extends Thread {
    
    DataInputStream dis;
    List list;
    Vector inHistory;
    boolean stop;
    Vector buddies;
    Vector allBuddies;
    
    
    public MCThread(DataInputStream dis,List list, Vector inHistory) {
        this.dis=dis;
        this.list=list;
        this.inHistory = inHistory;
        buddies = new Vector();
        allBuddies = new Vector();
        stop=false;
    }

    String getBuddyName(long buddy) {
        for (int i = 0; i < allBuddies.size(); i++) {
            Buddy b = (Buddy) allBuddies.elementAt(i);
            if (b.id==buddy) 
                return b.name;
        }
        return Long.toString(buddy);
    }    
    
    public void run() {
        try {
            while (!stop) {
                long from = dis.readLong();
                String content = dis.readUTF();
                inHistory.addElement(new InMessage(from,content));
                while (inHistory.size()>250)
                    inHistory.removeElementAt(0);
                boolean inbuddies = false;
                for (int i = 0; i < buddies.size(); i++) {
                    Buddy b = (Buddy) buddies.elementAt(i);
                    if (b.id==from) {
                        inbuddies=true;
                        break;
                    }
                }
                if ((buddies.size()==0)|(inbuddies))
                    if (list!=null)
                        if (buddies.size()==1)
                            list.insert(0,"-> "+content,null);
                        else
                            list.insert(0,"-> "+getBuddyName(from)+": "+content,null);
            }
        } catch (Exception e) {
            inHistory.insertElementAt(e.toString(),0);
        }
    }
}
