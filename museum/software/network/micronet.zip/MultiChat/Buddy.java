import javax.microedition.midlet.*;

public class Buddy {

    long id;
    long lastmessage;
    String name;
    String statusmsg;
    
    public Buddy(long id, String name) {
        this.id=id;
        lastmessage=System.currentTimeMillis();
        this.name=name;
        statusmsg="new buddy";
    }
}
