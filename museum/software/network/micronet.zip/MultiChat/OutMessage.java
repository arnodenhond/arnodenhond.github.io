import javax.microedition.midlet.*;


public class OutMessage {

    //long id
    //boolean[] confirmed
    long time;
    long[] to;
    String content;
    
    public OutMessage(long[] to, String content) {
        this.to=to;
        this.content=content;
        time = System.currentTimeMillis();
    }
    
}
