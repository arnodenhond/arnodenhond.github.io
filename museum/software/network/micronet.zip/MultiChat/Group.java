import javax.microedition.midlet.*;
import java.util.*;

public class Group {

    Vector buddies;
    String name;
    long lastmessage;
    
    public  Group(String name) {
        buddies = new Vector();
        this.name=name;
        lastmessage = System.currentTimeMillis();
    }
}
