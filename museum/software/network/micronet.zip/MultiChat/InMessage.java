import javax.microedition.midlet.*;


public class InMessage {
    
    //long chatid
    //boolean[] confirmed
    long time;
    long from;
    String content;
    
    public InMessage(long from, String content) {
        this.from=from;
        this.content=content;
        time=System.currentTimeMillis();
    }
    
}
