//todo: update last message times
//todo: select_command to view entire message then reply
//todo: settings - status message
//todo: auto ping buddies who are inactive
//todo: store buddies and groups in rms
//todo: edit group members (& edit buddy?)

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.*;

public class MultiChat extends MIDlet implements CommandListener {
    
    private Command exitCommand; // The exit command
    private Display display;    // The display for this MIDlet
    
    //private String statusmsg;
    //private int refreshrate;
    private DataOutputStream dos;
    private DataInputStream dis;
    Vector inHistory;
    Vector outHistory;
    MCThread reader;
    Vector buddies;
    Vector groups;
    
    public MultiChat() {
        buddies = new Vector();
        groups = new Vector();
        inHistory = new Vector();//load from RMS
        outHistory = new Vector();
        display = Display.getDisplay(this);
        exitCommand = new Command("Exit", Command.SCREEN, 2);
    }
    
    public void startApp() {
        Form f = new Form("MultiChat");
        final TextField stf = new TextField("Server Address","145.53.64.97",15,TextField.ANY);
        final TextField ctf = new TextField("Your Address","0",36,TextField.NUMERIC);
        final Gauge progress = new Gauge("",false,Gauge.INDEFINITE,Gauge.CONTINUOUS_IDLE);
        final StringItem errors = new StringItem("","");
        f.append(stf);
        f.append(ctf);
        f.append(progress);
        f.append(errors);
        f.append("welcome..");
        f.addCommand(new Command("Connect",Command.OK,0));
        f.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable d) {
                Thread connector = new Thread() {
                    public void run() {
                        try{
                            progress.setValue(Gauge.CONTINUOUS_RUNNING);
                            progress.setLabel("Connecting..");
                            StreamConnection sc = (StreamConnection) Connector.open("socket://"+stf.getString()+":4663");
                            dos = sc.openDataOutputStream();
                            dis = sc.openDataInputStream();
                            dos.writeUTF("LocalAccess v1.0 client");
                            String string = dis.readUTF();
                            dos.writeLong(Long.parseLong(ctf.getString()));
                            if (!string.equals("LocalAccess v1.0 client"))
                                throw new Exception("handshake failed");
                            reader = new MCThread(dis,null,inHistory);
                            reader.start();
                            inHistory.addElement(new InMessage(0,"CONNECTED"));
                            reader.list=mainList();
                            reader.allBuddies = buddies;
                            display.setCurrent(reader.list);
                        } catch (Exception e) {
                            progress.setValue(Gauge.CONTINUOUS_IDLE);
                            errors.setLabel("error");
                            errors.setText(e.toString());
                        }
                    }
                };
                connector.start();
            }
        });
        display.setCurrent(f);
    }
    
    private List mainList() {
        List result = new List("MultiChat - Main",List.IMPLICIT);
        Vector history = makeHistory();
        for (int i =history.size()-1; i >=0; i--)
            result.append((String) history.elementAt(i),null);
        final Command buddiesC = new Command("Buddies",Command.SCREEN,0);
        final Command groupsC = new Command("Groups", Command.SCREEN,0);
        //reply
        final Command settingsC = new Command("Settings", Command.SCREEN,0);
        result.addCommand(buddiesC);
        result.addCommand(groupsC);
        result.addCommand(settingsC);
        result.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                if (c==buddiesC) {
                    display.setCurrent(buddyList());
                    reader.list = null;
                }
                if (c==groupsC) {
                    display.setCurrent(groupList());
                    reader.list = null;
                }
                //list.selectcommand=view message->reply
            }
        });
        return result;
    }
    
    private String makeDate(long lastmessage) {
        String date = new String();
        if (lastmessage!=0) {
            long diff = System.currentTimeMillis()-lastmessage;
            long rem = diff % 60000;
            date = (diff/60000)+"m"+(rem/1000)+"s";
        }
        else
            date = "0m0s";
        return date;
    }
    
    private List groupList() {
        final List result = new List("MultiChat - Groups", List.IMPLICIT);
        for (int i = 0; i < groups.size(); i++) {
            Group g = (Group) groups.elementAt(i);
            result.append(g.name+" "+makeDate(g.lastmessage),null);
        }
        final Command backC = new Command("Back",Command.BACK,0);
        final Command addC = new Command("Add Group", Command.SCREEN, 0);
        final Command delC = new Command("Remove Group", Command.ITEM,0);
        final Command historyC = new Command("Dialog",Command.OK,0);
        result.addCommand(backC);
        result.addCommand(addC);
        result.addCommand(delC);
        result.addCommand(historyC);
        result.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                if (c==backC) {
                    reader.list = mainList();
                    reader.buddies = new Vector();
                    display.setCurrent(reader.list);
                }
                if ((c==historyC) | (c==List.SELECT_COMMAND)) {
                    if (result.getSelectedIndex()!=-1) {
                        final Group g = (Group) groups.elementAt(result.getSelectedIndex());
                        final List dialog = new List("Dialog for "+g.name,List.IMPLICIT);
                        Vector history = makeGroupDialog(g);
                        for (int i =history.size()-1; i >=0; i--)
                            dialog.append((String) history.elementAt(i),null);
                        final Command sendC = new Command("Send",Command.OK,0);
                        dialog.addCommand(sendC);
                        dialog.addCommand(backC);
                        dialog.setCommandListener(new CommandListener() {
                            public void commandAction(Command c, Displayable s) {
                                if (c==sendC) {
                                    final TextBox sendTB = new TextBox("Send to "+g.name,"",999,TextField.ANY);
                                    sendTB.addCommand(sendC);
                                    sendTB.addCommand(backC);
                                    sendTB.setCommandListener(new CommandListener() {
                                        public void commandAction(Command c, Displayable s) {
                                            if (c==sendC) {
                                                try {
                                                    dos.writeInt(g.buddies.size());
                                                    long[] to = new long[g.buddies.size()];
                                                    for (int i = 0; i < g.buddies.size(); i++) {
                                                        Buddy b = (Buddy) g.buddies.elementAt(i);
                                                        dos.writeLong(b.id);
                                                        to[i]=b.id;
                                                    }
                                                    dos.writeUTF(sendTB.getString());
                                                    outHistory.addElement(new OutMessage(to,sendTB.getString()));
                                                    dialog.insert(0, "<- "+sendTB.getString(),null);
                                                } catch (Exception e) {
                                                    dialog.insert(0, "<- "+e.toString(),null);
                                                }
                                            }
                                            display.setCurrent(dialog);
                                        }
                                    });
                                    display.setCurrent(sendTB);
                                }
                                else
                                    display.setCurrent(result);
                            }
                        });
                        display.setCurrent(dialog);
                        reader.list = dialog;
                        reader.buddies = g.buddies;
                    }
                }
                if (c==addC) {
                    final Form f = new Form("New group");
                    final TextField nameTF = new TextField("group name","new group",99,TextField.ANY);
                    final ChoiceGroup membersCG = new ChoiceGroup("members",Choice.MULTIPLE);
                    for (int i = 0 ; i < buddies.size(); i++) {
                        Buddy b = (Buddy) buddies.elementAt(i);
                        membersCG.append(b.name,null);
                    }
                    f.append(nameTF);
                    f.append(membersCG);
                    f.addCommand(backC);
                    f.addCommand(addC);
                    f.setCommandListener(new CommandListener() {
                        public void commandAction(Command c, Displayable s) {
                            if (c==addC) {
                                Group g = new Group(nameTF.getString());
                                boolean[] flags = new boolean[buddies.size()];
                                if (membersCG.getSelectedFlags(flags)>0) { //dont allow a group without members
                                    for (int i = 0; i < flags.length; i++)
                                        if (flags[i])
                                            g.buddies.addElement(buddies.elementAt(i));
                                    groups.addElement(g);
                                    result.append(g.name+" "+makeDate(g.lastmessage),null);
                                }
                            }
                            display.setCurrent(result);
                        }
                    });
                    display.setCurrent(f);
                }
                if (c==delC) {
                    if (result.getSelectedIndex()!=-1) {
                        groups.removeElementAt(result.getSelectedIndex());
                        result.delete(result.getSelectedIndex());
                    }
                }
            }
        });
        return result;
    }
    
    
    private List buddyList() {
        final List result = new List("MultiChat - Buddies", List.IMPLICIT);
        for (int i = 0; i < buddies.size(); i++) {
            Buddy b = (Buddy) buddies.elementAt(i);
            result.append(b.name+" "+makeDate(b.lastmessage),null);
        }
        final Command backC = new Command("Back",Command.BACK,0);
        final Command addC = new Command("Add Buddy",Command.SCREEN,0);
        final Command delC = new Command("Remove Buddy", Command.ITEM,0);
        final Command historyC = new Command("Dialog", Command.OK,0);
        result.addCommand(backC);
        result.addCommand(addC);
        result.addCommand(delC);
        result.addCommand(historyC);
        result.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                if (c==backC) {
                    reader.list = mainList();
                    display.setCurrent(reader.list);
                    reader.buddies = new Vector();
                }
                if ((c==historyC) | (c==List.SELECT_COMMAND)) {
                    if (result.getSelectedIndex()!=-1) {
                        final Buddy b = (Buddy) buddies.elementAt(result.getSelectedIndex());
                        final List dialog = new List("Dialog for "+b.name,List.IMPLICIT);
                        Vector history = makeDialog(b.id);
                        for (int i =history.size()-1; i >=0; i--)
                            dialog.append((String) history.elementAt(i),null);
                        final Command sendC = new Command("Send",Command.OK,0);
                        dialog.addCommand(sendC);
                        dialog.addCommand(backC);
                        dialog.setCommandListener(new CommandListener() {
                            public void commandAction(Command c, Displayable s) {
                                if (c==sendC) {
                                    final TextBox sendTB = new TextBox("Send to "+b.name,"",999,TextField.ANY);
                                    sendTB.addCommand(sendC);
                                    sendTB.addCommand(backC);
                                    sendTB.setCommandListener(new CommandListener() {
                                        public void commandAction(Command c, Displayable s) {
                                            if (c==sendC) {
                                                try {
                                                    dos.writeInt(1);
                                                    dos.writeLong(b.id);
                                                    dos.writeUTF(sendTB.getString());
                                                    long[] to = new long[1];
                                                    to[0]=b.id;
                                                    outHistory.addElement(new OutMessage(to,sendTB.getString()));
                                                    dialog.insert(0, "<- "+sendTB.getString(),null);
                                                } catch (Exception e) {
                                                    dialog.insert(0, "<- "+e.toString(),null);
                                                }
                                            }
                                            display.setCurrent(dialog);
                                        }
                                    });
                                    display.setCurrent(sendTB);
                                }
                                else
                                    display.setCurrent(result);
                            }
                        });
                        display.setCurrent(dialog);
                        reader.list = dialog;
                        reader.buddies = new Vector();
                        reader.buddies.addElement(b);
                    }
                }
                if (c==addC) {
                    final Form f = new Form("New buddy");
                    final TextField idTF = new TextField("ID","0",36,TextField.NUMERIC);
                    final TextField nameTF = new TextField("Name","new buddy",36,TextField.ANY);
                    f.append(idTF);
                    f.append(nameTF);
                    f.addCommand(backC);
                    f.addCommand(addC);
                    f.setCommandListener(new CommandListener() {
                        public void commandAction(Command c, Displayable s) {
                            if (c==addC) {
                                Buddy b = new Buddy(Long.parseLong(idTF.getString()), nameTF.getString());
                                buddies.addElement(b);
                                result.append(b.name+" "+makeDate(b.lastmessage),null);
                            }
                            display.setCurrent(result);
                        }
                    });
                    display.setCurrent(f);
                }
                if (c==delC) {
                    if (result.getSelectedIndex()!=-1) {
                        buddies.removeElementAt(result.getSelectedIndex());
                        result.delete(result.getSelectedIndex());
                    }
                }
            }
        });
        return result;
    }
    
    boolean buddyInGroup(long buddy, Group group) {
        for (int i = 0; i < group.buddies.size(); i++) {
            Buddy b = (Buddy) group.buddies.elementAt(i);
            if (b.id==buddy)
                return true;
        }
        return false;
    }
    
    boolean buddyIsGroup(long[] buddies, Group group) {
        if (buddies.length!=group.buddies.size())
            return false;
        for (int i = 0; i < buddies.length; i++)
            if (!buddyInGroup(buddies[i],group))
                return false;
        return true;
    }
    
    String getBuddyName(long buddy) {
        if (buddy==0)
            return "System";
        for (int i = 0; i < buddies.size(); i++) {
            Buddy b = (Buddy) buddies.elementAt(i);
            if (b.id==buddy)
                return b.name;
        }
        return Long.toString(buddy);
    }
    
    private Vector makeGroupDialog(Group g) {
        Vector result = new Vector();
        int inpos = 0;
        int outpos = 0;
        while ((inpos<inHistory.size())&(outpos<outHistory.size())) {
            InMessage im = (InMessage) inHistory.elementAt(inpos);
            OutMessage om = (OutMessage) outHistory.elementAt(outpos);
            if (im.time<om.time) {
                inpos++;
                if (!buddyInGroup(im.from,g))
                    continue;
                if (g.buddies.size()>1)
                    result.addElement("-> "+getBuddyName(im.from)+": "+im.content);
                else
                    result.addElement("-> "+im.content);
            }
            else {
                outpos++;
                if (!buddyIsGroup(om.to,g))//filter multicast?
                    continue;
                /*String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=om.to[i];
                    if (i<(om.to.length-1))
                        s+=",";
                }*/
                result.addElement("<- "+om.content);
            }
        }
        while ((inpos<inHistory.size())|(outpos<outHistory.size()))
            if (inpos<inHistory.size()) {
                InMessage im = (InMessage) inHistory.elementAt(inpos);
                inpos++;
                if (!buddyInGroup(im.from,g))
                    continue;
                if (g.buddies.size()>1)
                    result.addElement("-> "+getBuddyName(im.from)+": "+im.content);
                else
                    result.addElement("-> "+im.content);
            }
            else {
                OutMessage om = (OutMessage) outHistory.elementAt(outpos);
                outpos++;
                if (!buddyIsGroup(om.to,g))//filter multicast?
                    continue;
                /*String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=om.to[i];
                    if (i<(om.to.length-1))
                        s+=",";
                }*/
                result.addElement("<- "+om.content);
            }
        return result;
    }
    
    private Vector makeDialog(long buddy) {
        Vector result = new Vector();
        int inpos = 0;
        int outpos = 0;
        while ((inpos<inHistory.size())&(outpos<outHistory.size())) {
            InMessage im = (InMessage) inHistory.elementAt(inpos);
            OutMessage om = (OutMessage) outHistory.elementAt(outpos);
            if (im.time<om.time) {
                inpos++;
                if (im.from!=buddy)
                    continue;
                result.addElement("-> "+im.content);
            }
            else {
                outpos++;
                if ((om.to[0]!=buddy) | (om.to.length>1))//filter multicast?
                    continue;
                /*String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=om.to[i];
                    if (i<(om.to.length-1))
                        s+=",";
                }*/
                result.addElement("<- "+om.content);
            }
        }
        while ((inpos<inHistory.size())|(outpos<outHistory.size()))
            if (inpos<inHistory.size()) {
                InMessage im = (InMessage) inHistory.elementAt(inpos);
                inpos++;
                if (im.from!=buddy)
                    continue;
                result.addElement("-> "+im.content);
            }
            else {
                OutMessage om = (OutMessage) outHistory.elementAt(outpos);
                outpos++;
                if ((om.to[0]!=buddy) | (om.to.length>1))//filter multicast?
                    continue;
                /*String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=om.to[i];
                    if (i<(om.to.length-1))
                        s+=",";
                }*/
                result.addElement("<- "+om.content);
            }
        return result;
    }
    
    private Vector makeHistory() {
        Vector result = new Vector();
        int inpos = 0;
        int outpos = 0;
        while ((inpos<inHistory.size())&(outpos<outHistory.size())) {
            InMessage im = (InMessage) inHistory.elementAt(inpos);
            OutMessage om = (OutMessage) outHistory.elementAt(outpos);
            if (im.time<om.time) {
                result.addElement("-> "+getBuddyName(im.from)+": "+im.content);
                inpos++;
            }
            else {
                String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=getBuddyName(om.to[i]);
                    if (i<(om.to.length-1))
                        s+=",";
                }
                result.addElement("<- "+s+": "+om.content);
                outpos++;
            }
        }
        while ((inpos<inHistory.size())|(outpos<outHistory.size()))
            if (inpos<inHistory.size()) {
                InMessage im = (InMessage) inHistory.elementAt(inpos);
                result.addElement("-> "+getBuddyName(im.from)+": "+im.content);
                inpos++;
            }
            else {
                OutMessage om = (OutMessage) outHistory.elementAt(outpos);
                String s = new String();
                for (int i = 0; i < om.to.length; i++) {
                    s+=getBuddyName(om.to[i]);
                    if (i<(om.to.length-1))
                        s+=",";
                }
                result.addElement("<- "+s+": "+om.content);
                outpos++;
            }
        return result;
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
    public void commandAction(Command c, Displayable s) {
        if (c == exitCommand) {
            destroyApp(false);
            notifyDestroyed();
        }
    }
    
}
