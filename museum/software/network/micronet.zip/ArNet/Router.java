//should a message be stopped when a connection sends a message whose from is equal to the name of a client?

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.*;

public class Router  extends Thread {
    
    Vector log;
    Vector connections;
    Vector destinations;
    Vector clients;
    Vector history;
    boolean stop;
    
    public Router() {
        log = new Vector();
        connections = new Vector();
        destinations = new Vector();
        history = new Vector();
        clients = new Vector();
        stop=false;
        log.addElement("router created");
    }
    
    boolean findid(long id) { //id appears in history
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.elementAt(i);
            if (h.id==id)
                return true;
        }
        return false;
    }
    
    boolean findidto(long id,long to) { //id & to appars in history
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.elementAt(i);
            if (h.id==id)
                for (int j = 0; j < h.to.length; j++)
                    if (h.to[j]==to)
                        return true;
        }
        return false;
    }
    
    void addid(long id) { //add "id" and "to" history
        History h = new History();
        h.id=id;
        h.to = new long[0];
        history.addElement(h);
        while (history.size()>1000) //don't let it grow too large
            history.removeElementAt(0);
    }
    
    void addidto(long id, long to) { //add a "to" to an "id" in history
        for (int i = 0; i < history.size(); i++) {
            History h = (History) history.elementAt(i);
            if (h.id==id) {
                h.to=addto(h.to,to);
                return;
            }
        }
    }
    
    void addupdatedestination(long from, AConnection c) { //adds or updates a destination
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.elementAt(i);
            if (d.destination==from) {
                if (d.lastmessage!=0) { // never change permanent routes
                    d.connection = c;
                    d.lastmessage=System.currentTimeMillis();//does not support static destinations
                }
                return;
            }
        }
        Destination d = new Destination();
        d.destination=from;
        d.connection=c;
        d.lastmessage=System.currentTimeMillis();
        destinations.addElement(d);
    }
    
    void delDestination(long destination) { //deletes a destination
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.elementAt(i);
            if (d.destination==destination) {
                destinations.removeElementAt(i);
                return;
            }
        }
    }
    
    void delDestination(AConnection c) { //deletes all destinations for a connection
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.elementAt(i);
            if (d.connection==c) {
                destinations.removeElement(d);
                i--;
            }
        }
    }
    
    AConnection findDestination(long destination) { //finds connections for a destination
        for (int i = 0; i < destinations.size(); i++) {
            Destination d = (Destination) destinations.elementAt(i);
            if (d.destination==destination)
                return d.connection;
        }
        return null;
    }
    
    long[] addto(long[] to,long newto) { //add a long to an array of longs
        long[] result = new long[to.length+1];
        System.arraycopy(to, 0, result, 0, to.length);
        result[result.length-1] = newto;
        return result;
    }
    
    public void run() {
        log.addElement("router running");
        try {
            while (!stop) {
                sleep(100);
                for (int i = 0; i < destinations.size(); i++) { //check for outdated destinations
                    Destination d = (Destination) destinations.elementAt(i);
                    if (d.lastmessage==0) //its a static destination
                        continue;
                    if (d.lastmessage<System.currentTimeMillis()-600000) { //del dest after 10 min
                        destinations.removeElement(d);
                        log.addElement("destination to "+d.destination+" outdated");
                        i--;
                    }
                }
                for (int i =0; i < clients.size(); i++) { //check if all clients are still alive
                    Client c = (Client) clients.elementAt(i);
                    if (!c.isAlive()) {
                        clients.removeElement(c);
                        log.addElement("client "+c.getConnectionName()+" removed ");
                        i--;
                    }
                }
                for (int i = 0; i < connections.size(); i++) { //check if all connections are still alive
                    AConnection c = (AConnection) connections.elementAt(i);
                    if (!c.isAlive()) {
                        connections.removeElement(c);
                        delDestination(c); //remove all destinations behind this connection
                        log.addElement("connection "+c.getConnectionName()+" removed");
                        i--;
                    }
                }
                for (int i = 0; i < clients.size(); i++) { //get messages from clients
                    Client c = (Client) clients.elementAt(i);
                    if (c.hasMessage()) {
                        Message m = c.getMessage();
                        Random r = new Random();
                        do //move this to client.getmessage?
                            m.id = r.nextLong();
                        while (findid(m.id));
                        log.addElement("client "+c.getConnectionName()+" has sent message "+m.id);
                        send(m);
                    }
                }
                for (int i = 0; i < connections.size(); i++) { //get messages from connections
                    AConnection c = (AConnection) connections.elementAt(i);
                    if (c.hasMessage()) {
                        Message m = c.getMessage();
                        log.addElement("connection "+c.getConnectionName()+" has sent message "+m.id);
                        //check history for id = if not found: add it & add/update "from" in destinations
                        if (!findid(m.id)) {
                            addid(m.id);//dont process this id (and no to's yet) again
                            addupdatedestination(m.from, c);
                            log.addElement("destination to "+m.from+" added to connection "+c.getConnectionName());
                        }
                        else
                            log.addElement("message id known, checking receipiants");
                        //split message into all "to"'s and "connection"'s
                        Message[] mout = new Message[connections.size()];
                        for (int j = 0; j < mout.length; j++) {
                            mout[j] = new Message();
                            mout[j].from=m.from;
                            mout[j].id=m.id;
                            mout[j].to=new long[0];
                            mout[j].content=m.content;
                        }
                        for (int j = 0; j < m.to.length; j++) {
                            if (m.from==m.to[j]) //ignore messages where from==to
                                continue;
                            if (!findidto(m.id,m.to[j])) { //check history for id and to - if not found: add it
                                log.addElement("message has not yet been sent to "+m.to[j]);
                                addidto(m.id,m.to[j]); //dont process this message to this receipant again
                                boolean local=false; //check to==localaddress
                                for (int k = 0; k < clients.size(); k++) {
                                    Client client = (Client) clients.elementAt(k);
                                    if (client.address==m.to[j]) {
                                        client.putMessage(m);
                                        log.addElement("delivered to "+client.getConnectionName());
                                        local=true;
                                        break;
                                    }
                                }
                                if (local) //dont bother about this "to" anymore
                                    continue;
                                AConnection c2 = findDestination(m.to[j]);
                                if (c2!=null) { //rule 3 which connection to reach this "to"
                                    log.addElement("destination known..");
                                    if (c2==c) {//rule 4 delete destination & forward to all
                                        log.addElement("backloop detected! forwarding to all");
                                        delDestination(m.to[j]);
                                        for (int k = 0; k < mout.length; k++) //add current "to" to all connections
                                            if (k != i) //don't send it back to the sender
                                                mout[k].to=addto(mout[k].to,m.to[j]); //deepest point in router!
                                    }
                                    else { //add current "to" to message for proper connection
                                        log.addElement("forwarding to "+c2.getConnectionName());
                                        mout[connections.indexOf(c2)].to=addto(mout[connections.indexOf(c2)].to,m.to[j]);
                                    }
                                }
                                else { //rule 1 forward to all (except sender)
                                    log.addElement("unknown destination forwarding to all");
                                    for (int k = 0; k < mout.length; k++) //add current "to" to all connections
                                        if (k != i)//don't send it back to the sender
                                            mout[k].to=addto(mout[k].to,m.to[j]);
                                }
                            }
                            else
                                log.addElement("message has already been sent to "+m.to[j]);
                        }
                        for (int j = 0; j < mout.length; j++) //send message to connection where to>0
                            if (mout[j].to.length>0) {
                                AConnection cout = (AConnection) connections.elementAt(j);
                                cout.putMessage(mout[j]);
                            }
                    } // connection had message
                } // get messages from connections
            } // baby dont stop
            for (int i = 0; i < connections.size(); i++) {
                AConnection c = (AConnection) connections.elementAt(i);
                c.disconnect();
            }
            log.addElement("router stopped");
        } catch (Exception e) {
            log.addElement("router: "+e.toString());
        }
    }
    
    public void send(Message m) { //used for sending locally generated messages
        log.addElement("sending "+m.id);
        addid(m.id);
        Message[] mout = new Message[connections.size()];
        for (int j = 0; j < mout.length; j++) {
            mout[j] = new Message();
            mout[j].from=m.from;
            mout[j].id=m.id;
            mout[j].to=new long[0];
            mout[j].content=m.content;
        }
        for (int i = 0; i < m.to.length; i++) {
            if (m.from==m.to[i]) //ignore messages where from==to
                continue;
            addidto(m.id, m.to[i]);
            boolean local=false;
            for (int k = 0; k < clients.size(); k++) {
                Client client = (Client) clients.elementAt(k);
                if (client.address==m.to[i]) {
                    client.putMessage(m);
                    log.addElement("delivered to "+client.getConnectionName());
                    local=true;
                    break;
                }
            }
            if (local)
                continue;
            AConnection c2 = findDestination(m.to[i]);
            if (c2==null) {
                log.addElement("unknown destination forwarding to all");
                for (int k = 0; k < mout.length; k++)
                    mout[k].to=addto(mout[k].to,m.to[i]);
            }
            else {
                mout[connections.indexOf(c2)].to=addto(mout[connections.indexOf(c2)].to,m.to[i]);
                log.addElement("destination known forwarding to "+c2.getConnectionName());
            }
        }
        for (int j = 0; j < mout.length; j++)
            if (mout[j].to.length>0) {
                AConnection cout = (AConnection) connections.elementAt(j);
                cout.putMessage(mout[j]);
            }
    }
    
    public void addConnection(AConnection c) {
        connections.addElement(c);
        log.addElement("new connection added "+c.getConnectionName());
    }
    
    public void addClient(Client c) {
        clients.addElement(c);
        log.addElement("new client added "+c.getConnectionName());
    }
}
