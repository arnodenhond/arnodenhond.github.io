public class Message {
    
    long id;
    
    long[] to;
    
    long from;
    
    byte[] content;
    
    public Message() {
        id=0;
        to = new long[0];
        from=0;
        content = new byte[0];
    }
    
}
