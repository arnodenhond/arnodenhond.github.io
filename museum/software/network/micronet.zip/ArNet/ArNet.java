import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.util.*;


public class ArNet extends MIDlet implements CommandListener {
    
    private Command okCommand;
    private Command backCommand;
    private Command exitCommand;
    
    private Command sendCommand;
    
    private Command conCommand;
    private Command destCommand;
    private Command clientCommand;
    
    private Command addconCommand;
    private Command delconCommand;
    
    private Command deldestCommand;
    private Command adddestCommand;
    
    private Router router;
    private MIDlet midlet;
    
    public ArNet() {
        midlet = this;
        okCommand = new Command("Ok",Command.OK,0);
        backCommand = new Command("Back",Command.BACK,0);
        exitCommand = new Command("Exit", Command.EXIT, 0);
        sendCommand = new Command("Send message",Command.BACK,0);
        conCommand = new Command("Connections",Command.SCREEN,0);
        addconCommand = new Command("Open new",Command.SCREEN,0);
        delconCommand = new Command("Disconnect",Command.ITEM,0);
        adddestCommand = new Command("Add new",Command.SCREEN,0);
        deldestCommand = new Command("Remove",Command.ITEM,0);
        clientCommand = new Command("Clients", Command.SCREEN,0);
        destCommand = new Command("Destinations",Command.SCREEN,0);
    }
    
    public void startApp() {
        Form f = new Form("ArNet-welcome");
        f.append("Continue..");
        f.addCommand(exitCommand);
        f.addCommand(okCommand);
        f.setCommandListener(this);
        Display.getDisplay(this).setCurrent(f);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
        router.stop=true;
    }
    
    public void commandAction(Command c, Displayable s) {
        if (c == exitCommand) {
            destroyApp(false);
            notifyDestroyed();
        }
        if (c == okCommand) {
            if (router == null) {
                router = new Router();
                router.start();
            }
            Display.getDisplay(this).setCurrent(makeLog());
        }
        if (c==backCommand) {
            Display.getDisplay(this).setCurrent(makeLog());
        }
        if (c == destCommand) {
            Display.getDisplay(this).setCurrent(makeDest());
        }
        if (c==conCommand) {
            Display.getDisplay(this).setCurrent(makeCon());
        }
        if (c==clientCommand) {
            Display.getDisplay(this).setCurrent(makeClients());
        }
        if (c==sendCommand) {
            sendMessage();
        }
        if (c==addconCommand) {
            makeConnection();
        }
        if (c==delconCommand) {
            List list = (List) s;
            if (list.getSelectedIndex()!=-1) {
                AConnection dc = (AConnection) router.connections.elementAt(list.getSelectedIndex());
                dc.disconnect();
                //3 lines below should be done by router when it detects thread is dead (which it doesnt)
                router.connections.removeElement(dc);
                router.delDestination(dc);
                router.log.addElement("connection "+dc.getConnectionName()+" removed");
            }
            Display.getDisplay(this).setCurrent(makeCon());
        }
        if (c==adddestCommand) {
            addDestination();
        }
        if (c==deldestCommand) {
            List list = (List) s;
            if (list.getSelectedIndex()!=-1) {
                Destination d = (Destination) router.destinations.elementAt(list.getSelectedIndex());
                router.destinations.removeElement(d);
                router.log.addElement("destination to "+d.destination+" removed from connection "+d.connection.getConnectionName());
            }
            Display.getDisplay(this).setCurrent(makeDest());
        }
    }
    
    private void sendMessage() {
        final Form sendF = new Form("Send message");
        Random r = new Random();
        final TextField idTF = new TextField("ID",Long.toString(r.nextLong()),36,TextField.NUMERIC);
        final TextField fromTF = new TextField("From","",36,TextField.NUMERIC);
        final TextField toTF = new TextField("To","",36,TextField.ANY);
        final TextField msgTF = new TextField("Message","",100,TextField.ANY);
        sendF.append(idTF);
        sendF.append(fromTF);
        sendF.append(toTF);
        sendF.append(msgTF);
        sendF.addCommand(okCommand);
        sendF.addCommand(backCommand);
        Display.getDisplay(this).setCurrent(sendF);
        sendF.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                try {
                    if (c==okCommand) {
                        Message m = new Message();
                        m.id = Long.parseLong(idTF.getString());
                        m.from = Long.parseLong(fromTF.getString());
                        m.content = msgTF.getString().getBytes();
                        String tos = toTF.getString();
                        while (tos.indexOf(",")!=-1) {
                            String cto = tos.substring(0,tos.indexOf(","));
                            tos = tos.substring(tos.indexOf(",")+1,tos.length());
                            m.to=router.addto(m.to,Long.parseLong(cto));
                        }
                        m.to=router.addto(m.to,Long.parseLong(tos));
                        router.send(m);
                    }
                    Display.getDisplay(midlet).setCurrent(makeLog());
                }
                catch (Exception e) {
                    Display.getDisplay(midlet).setCurrent(new Alert("error","check fields",null,AlertType.ERROR));
                }
            }
        } );
    }
    
    private void makeConnection() {
        final TextBox addressTB = new TextBox("Address","145.53.64.97",15,TextField.ANY);
        addressTB.addCommand(okCommand);
        addressTB.addCommand(backCommand);
        Display.getDisplay(this).setCurrent(addressTB);
        addressTB.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                if (c==okCommand) {
                    String address = addressTB.getString();
                    try {
                        SocketAConnection sac = new SocketAConnection(address);//145.53.64.97
                        sac.start();
                        router.addConnection(sac);
                    } catch (Exception e)
                    {router.log.addElement("unable to open");}
                }
                Display.getDisplay(midlet).setCurrent(makeCon());
            }
        });
    }
    
    private void addDestination() {
        final Form destF = new Form("Add destination");
        final ChoiceGroup conCG = new ChoiceGroup("Connection",Choice.EXCLUSIVE);
        for (int i = 0; i < router.connections.size(); i++) {
            AConnection c = (AConnection) router.connections.elementAt(i);
            conCG.append(c.getConnectionName(),null);
        }
        final TextField destTF = new TextField("Destination","",36,TextField.NUMERIC);
        final ChoiceGroup permCG = new ChoiceGroup("",Choice.MULTIPLE);
        permCG.append("Permanent",null);
        boolean[] flags = {true};
        permCG.setSelectedFlags(flags);
        
        destF.append(conCG);
        destF.append(destTF);
        destF.append(permCG);
        destF.addCommand(okCommand);
        destF.addCommand(backCommand);
        Display.getDisplay(this).setCurrent(destF);
        destF.setCommandListener(new CommandListener() {
            public void commandAction(Command c, Displayable s) {
                try {
                    if (c==okCommand) {
                        Destination d2 = new Destination();
                        AConnection ac = (AConnection) router.connections.elementAt(conCG.getSelectedIndex());
                        d2.connection = ac;
                        d2.destination = Long.parseLong(destTF.getString());
                        if (permCG.isSelected(0))
                            d2.lastmessage=0;
                        else
                            d2.lastmessage=System.currentTimeMillis();
                        //use router.addupdatedestination?
                        router.destinations.addElement(d2);
                        router.log.addElement("destination to "+d2.destination+" added to connection "+d2.connection.getConnectionName());
                    }
                    Display.getDisplay(midlet).setCurrent(makeDest());
                }
                catch (Exception e) {
                    Display.getDisplay(midlet).setCurrent(new Alert("error","check fields",null,AlertType.ERROR));
                }
            }
        });
    }
    
    private Form makeLog() {
        Form result = new Form("ArNet-log");
        while (router.log.size()>25)
            router.log.removeElementAt(0);
        for (int i = router.log.size()-1; i >= 0; i--) {
            result.append((String)router.log.elementAt(i)+"\r\n");
        }
        result.addCommand(sendCommand);
        result.addCommand(okCommand);
        result.addCommand(conCommand);
        result.addCommand(destCommand);
        result.addCommand(clientCommand);
        result.addCommand(exitCommand);
        result.setCommandListener(this);
        return result;
    }
    
    private List makeDest() {
        List result = new List("ArNet-destinations",List.IMPLICIT);
        for (int i = 0; i < router.destinations.size(); i++) {
            Destination d = (Destination) router.destinations.elementAt(i);
            String date;
            if (d.lastmessage!=0)
            {
                long diff = System.currentTimeMillis()-d.lastmessage;
                long rem = diff % 60000;
                date = (diff/60000)+"m"+(rem/1000)+"s";
            }
            else
                date="permanent";
            result.append(d.destination+" - "+d.connection.getConnectionName()+" - "+date,null);
        }//add time elapsed
        result.addCommand(adddestCommand);
        result.addCommand(deldestCommand);
        result.addCommand(backCommand);
        result.setCommandListener(this);
        return result;
    }
    
    private List makeCon() {
        List result = new List("ArNet-connections",Choice.IMPLICIT);
        for (int i = 0; i < router.connections.size(); i++) {
            AConnection c = (AConnection) router.connections.elementAt(i);
            result.append(c.getConnectionName(),null);
        }
        result.addCommand(delconCommand);
        result.addCommand(addconCommand);
        result.addCommand(backCommand);
        result.setCommandListener(this);
        return result;
    }
    
    private Form makeClients() {
        Form result = new Form("ArNet-clients");
        for (int i = 0; i < router.clients.size(); i++) {
            Client c = (Client) router.clients.elementAt(i);
            result.append(c.getConnectionName()+"\r\n");
        }
        result.addCommand(backCommand);
        result.setCommandListener(this);
        return result;
    }
    
}
