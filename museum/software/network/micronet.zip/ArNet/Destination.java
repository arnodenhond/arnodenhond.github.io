import javax.microedition.midlet.*;

public class Destination {
    
    long destination;
    
    AConnection connection;
    
    long lastmessage;
    
}
