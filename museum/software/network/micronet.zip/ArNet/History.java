import javax.microedition.midlet.*;

public class History {
    
    long id;
    
    long[] to;
    
}
