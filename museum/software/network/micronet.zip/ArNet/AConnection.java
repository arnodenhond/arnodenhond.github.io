interface AConnection {
    
    Message getMessage();
    
    void putMessage(Message m);
    
    boolean hasMessage();
    
    boolean isAlive();
    
    String getConnectionName();
    
    void disconnect();
    
}
