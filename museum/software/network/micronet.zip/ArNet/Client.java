import javax.microedition.midlet.*;

public class Client extends Thread {

    long address;
    
    public void putMessage(Message m) {
    }
    
    public boolean hasMessage() {
        return (false);
    }
    
    public String getConnectionName() {
        return "client";
    }

    public Message getMessage() {
        return null;
    }
    
}

