import javax.microedition.midlet.*;

class IRAConnection implements AConnection {
    
    public Message getMessage() {
        return null;
    }
    
    public void putMessage(Message m) {
        
    }
    
    public boolean hasMessage() {
        return false;
    }
    
    public boolean isAlive() {
        return false;
    }
    
    public String getName() {
        return null;
    }
        
    public String getConnectionName() {
        return "infra-red";
    }
    
    public void disconnect() {
    }
    
}
