import javax.microedition.midlet.*;
import javax.microedition.io.*;
import java.io.*;

class SocketAConnection extends Thread implements AConnection {
    
    SocketConnection sc;
    Message message;
    DataOutputStream dos;
    DataInputStream dis;
    String ipaddress;
    boolean stop;
    
    public SocketAConnection(String ipaddress) throws Exception {
        this.ipaddress=ipaddress;
        message = null;
        stop=false;
        sc = (SocketConnection) Connector.open("socket://"+ipaddress+":2766");
        //145.53.64.97
        dos = sc.openDataOutputStream();
        dis = sc.openDataInputStream();
        dos.writeUTF("LocalAccess v1.0 server");
        String str = dis.readUTF();
        if (!str.equals("LocalAccess v1.0 server"))
            throw new Exception("failed handshake");
    }
    
    public void run() {
        try {
            while (!stop) {
                while (message!=null) //message hasnt been picked up by router yet
                    sleep(500);
                Message m = new Message();
                m.id=dis.readLong();
                m.to = new long[dis.readInt()];
                for (int i = 0; i < m.to.length; i++)
                    m.to[i]=dis.readLong();
                m.from=dis.readLong();
                /*m.content = new byte[dis.readInt()];
                for (int i = 0; i < m.content.length; i++)
                    m.content[i]=dis.readByte();*/
                m.content=dis.readUTF().getBytes();//replace this by above when updated localaccess
                message=m;
            }
        } catch (Exception e) {
            //System.out.println("socketconnection.run:"+e.toString());
        }
    }
    
    public Message getMessage() {
        Message m = message;
        message=null;
        return m;
    }
    
    public void putMessage(Message m) {
        try {
            dos.writeLong(m.id);
            dos.writeInt(m.to.length);
            for (int i = 0; i < m.to.length; i++)
                dos.writeLong(m.to[i]);
            dos.writeLong(m.from);
/*            dos.writeInt(m.content.length);
            for (int i = 0; i < m.content.length; i++)
                dos.writeByte(m.content[i]);*/
            dos.writeUTF(new String(m.content));//replace this by above when updated localaccess
        } catch (Exception e) {
            //System.out.println("putmessage:"+e.toString());
        }
    }
    
    public void disconnect() {
        try {
            dos.close();
            dis.close();
            sc.close();
        } catch (Exception e) {
            //couldnt disconnect!
        }
        stop=true;
    }
    
    public boolean hasMessage() {
        return (message!=null);
    }
    
    public String getConnectionName() {
        try {//use sc.getAddress() instead of ipaddress
            return ipaddress;
        }
        catch (Exception e) {
            return "IP/Socket "+ipaddress+" "+e.toString();
        }
    }
}