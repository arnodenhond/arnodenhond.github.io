import java.net.*;
import java.io.*;
import java.math.*;
import java.util.*;
import java.lang.*;

public class MultiPing {
    
    static boolean inArray(long[] a, long v) {
        for (int i = 0; i < a.length; i++)
            if (a[i]==v)
                return true;
        return false;
    }
    
    public static void main(String[] args) throws Exception {
        System.out.println("MultiPing v1.0");
        if (args.length<4)
            System.out.println("parameters: <your id> <id(,id,id) to ping> <server hostname> <server portnumber>");
        long address = Long.parseLong(args[0]);
        //long pingaddress = Long.parseLong(args[1]);
        StringTokenizer st = new StringTokenizer(args[1],",");
        long[] pingaddress = new long[st.countTokens()];
        for (int i = 0; st.hasMoreTokens(); i++) //st.countTokens == pingaddress.length
            pingaddress[i]=Long.parseLong(st.nextToken());
        long pingpong = new Random().nextLong();
        Socket socket = new Socket(args[2],Integer.parseInt(args[3]));
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("LocalAccess v1.0 client");
        String string = dis.readUTF();
        if (string.equalsIgnoreCase("LocalAccess v1.0 client"))
            System.out.println("CONNECTED");
        else
            System.out.println("BAD SERVER");
        dos.writeLong(address);
        System.out.print("sending ping to ("+pingaddress.length+") ");
        dos.writeInt(pingaddress.length);
        for (int i = 0; i < pingaddress.length; i++) {
            dos.writeLong(pingaddress[i]);
            System.out.print(pingaddress[i]);
            if ((i+1)<pingaddress.length)
                System.out.print(", ");
            else
                System.out.println();
        }
        dos.writeUTF("PING "+Long.toString(pingpong));
        System.out.println("waiting for reply");
        int replies = 0;
        while (replies < pingaddress.length) {
            long from = dis.readLong();
            String content = dis.readUTF();
            if (!inArray(pingaddress,from))
                continue;
            replies++;
            if (content.toUpperCase().startsWith("PONG")) {
                System.out.print("("+replies+") receiving PONG from "+from+".. ");
                long pingpongreply = Long.parseLong(content.substring(5,content.length()));
                if (pingpong==pingpongreply)
                    System.out.println("pingpong complete");
                else
                    System.out.println("error! pingpongcode incorrect!");
            }
        }
        
/*        
        long from=0;
        String content="";
        do {
            from = dis.readLong();
            content = dis.readUTF();
        } while ((from!=pingaddress) && (content.toUpperCase().startsWith("PONG")));
        System.out.println(" received");
        if (content.toUpperCase().startsWith("PONG")) {
            long pingpongreply = Long.parseLong(content.substring(5,content.length()));
            if (pingpong==pingpongreply)
                System.out.println("pingpong complete");
            else
                System.out.println("error! pingpongcode incorrect!");
        }
 */
    }
}