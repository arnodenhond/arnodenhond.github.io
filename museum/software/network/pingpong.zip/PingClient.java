import java.net.*;
import java.io.*;
import java.math.*;
import java.util.*;
import java.lang.*;

public class PingClient {
    
    public PingClient() {
    }
    
    public static void main(String[] args) throws Exception {
        System.out.println("PingClient v1.0");
        if (args.length<4)
            System.out.println("parameters: <your id> <id to ping> <server hostname> <server portnumber>");
        long address = Long.parseLong(args[0]);
        long pingaddress = Long.parseLong(args[1]);
        long pingpong = new Random().nextLong();
        Socket socket = new Socket(args[2],Integer.parseInt(args[3]));
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("LocalAccess v1.0 client");
        String string = dis.readUTF();
        if (string.equalsIgnoreCase("LocalAccess v1.0 client"))
            System.out.println("CONNECTED");
        else
            System.out.println("BAD SERVER");
        dos.writeLong(address);
        System.out.println("sending ping to "+pingaddress);
        dos.writeInt(1);
        dos.writeLong(pingaddress);
        dos.writeUTF("PING "+Long.toString(pingpong));
        System.out.print("waiting for PONG from "+pingaddress+"...");
        long from=0;
        String content="";
        do {
            from = dis.readLong();
            content = dis.readUTF();
        } while ((from!=pingaddress) && (content.toUpperCase().startsWith("PONG")));
        System.out.println(" received");
        if (content.toUpperCase().startsWith("PONG")) {
            long pingpongreply = Long.parseLong(content.substring(5,content.length()));
            if (pingpong==pingpongreply)
                System.out.println("pingpong complete");
            else
                System.out.println("error! pingpongcode incorrect!");
        }
    }
}