import java.net.*;
import java.io.*;

public class PingServer {
    
    public PingServer() {
    }

    public static void main(String[] args) throws Exception {
        System.out.println("PingServer v1.0");
        if (args.length<3) 
            System.out.println("parameters: <your id> <server hostname> <server portnumber>");
        long address = Long.parseLong(args[0]);
        Socket socket = new Socket(args[1],Integer.parseInt(args[2]));
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("LocalAccess v1.0 client");
        String string = dis.readUTF();
        if (string.equalsIgnoreCase("LocalAccess v1.0 client"))
            System.out.println("CONNECTED");
        else
            System.out.println("BAD SERVER");
        dos.writeLong(address);
        while (true) {
            long from = dis.readLong();
            String content = dis.readUTF();
            if (content.toUpperCase().startsWith("PING")) {
                long pingpong = Long.parseLong(content.substring(5,content.length()));
                System.out.println("ping received from "+from+", sending pong");
                dos.writeInt(1);
                dos.writeLong(from);
                dos.writeUTF("PONG "+Long.toString(pingpong));
            }
        }
    }
    
}
